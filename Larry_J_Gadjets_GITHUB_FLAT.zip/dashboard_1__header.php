<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/conn.php';

if (isset($_SESSION['image'])) {
    $savedImage = trim((string)$_SESSION['image']);
    $savedImage = str_replace('\\', '/', $savedImage);
    $savedImage = urldecode($savedImage);
    $savedImage = explode('?', $savedImage, 2)[0];
    $savedImage = explode('#', $savedImage, 2)[0];
    $_SESSION['image'] = basename($savedImage);
}

/* Find the project root so this header works on root pages and dashboard pages. */
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
$scriptDir = rtrim($scriptDir, '/');
if (preg_match('#/(?:dashboard|dashboard%201|dashboard 1)$#i', $scriptDir)) {
    $siteRoot = dirname($scriptDir);
} else {
    $siteRoot = $scriptDir;
}
if ($siteRoot === '' || $siteRoot === '\\' || $siteRoot === '.') {
    $siteRoot = '/';
} else {
    $siteRoot .= '/';
}
$siteRoot = str_replace('//', '/', $siteRoot);
?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($siteRoot . 'bootstrap.min.css', ENT_QUOTES, 'UTF-8'); ?>">
<script src="<?php echo htmlspecialchars($siteRoot . 'bootstrap.bundle.min.js', ENT_QUOTES, 'UTF-8'); ?>"></script>
<style id="ljg-preloader-style">
body::before{content:"";position:fixed;inset:0;z-index:2147483647;background:#0b0b0b url("<?php echo htmlspecialchars($siteRoot . 'images/main-logo.png', ENT_QUOTES, 'UTF-8'); ?>") center 45%/min(360px,72vw) auto no-repeat;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:all}body::after{content:"";position:fixed;z-index:2147483647;left:50%;top:60%;width:180px;height:4px;transform:translateX(-50%);border-radius:20px;background:linear-gradient(90deg,transparent,#e10600,transparent);animation:ljgLoad 1.05s ease-in-out infinite;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:none}@keyframes ljgLoad{0%{clip-path:inset(0 100% 0 0)}50%{clip-path:inset(0 0 0 0)}100%{clip-path:inset(0 0 0 100%)}}body.ljg-ready::before,body.ljg-ready::after{opacity:0;visibility:hidden;pointer-events:none}
</style>
<script id="ljg-preloader-script">window.addEventListener('load',function(){if(document.body){document.body.classList.add('ljg-ready');}});</script>

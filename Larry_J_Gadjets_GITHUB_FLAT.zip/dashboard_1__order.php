<?php
require_once 'header.php';
require_once 'auth.php';

$message = '';

/* Admin clicks Approve. */
if (isset($_GET['approve']) && $isAdmin) {
    $id = (int) $_GET['approve'];

    if ($id > 0) {
        $stmt = mysqli_prepare($conn, "UPDATE orders SET status = 'approved' WHERE id = ?");

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $id);
            $ok = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            $message = $ok ? 'Order approved.' : 'Order could not be approved.';
        }
    }
}

/* Admin can delete an order. */
if (isset($_GET['delete']) && $isAdmin) {
    $id = (int) $_GET['delete'];

    if ($id > 0) {
        $stmt = mysqli_prepare($conn, 'DELETE FROM orders WHERE id = ?');

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $id);
            $ok = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            $message = $ok ? 'Order deleted.' : 'Order could not be deleted.';
        }
    }
}

/* Admin sees every order. Customer sees only their own orders. */
if ($isAdmin) {
    $orders = mysqli_query($conn, 'SELECT * FROM orders ORDER BY id DESC');
} else {
    $userId = (int) $_SESSION['id'];
    $email = (string) ($_SESSION['email'] ?? '');

    $stmt = mysqli_prepare(
        $conn,
        'SELECT * FROM orders WHERE user_id = ? OR LOWER(email) = LOWER(?) ORDER BY id DESC'
    );

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'is', $userId, $email);
        mysqli_stmt_execute($stmt);
        $orders = mysqli_stmt_get_result($stmt);
        mysqli_stmt_close($stmt);
    } else {
        $orders = false;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders - Larry J Gadjets</title>
<link href="../bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body{margin:0;background:#f4f7fb;overflow-x:hidden}.content{width:100%;min-width:0}.card-box{border:0;border-radius:18px;overflow:hidden}.table th{background:#f8fafc;color:#687385;font-size:12px;text-transform:uppercase}.table td,.table th{padding:14px;vertical-align:middle}.items{min-width:260px}.total{font-weight:800;color:#0d6efd;white-space:nowrap}.pending{color:#856404;background:#fff3cd;border:1px solid #ffecb5}.approved{color:#146c43;background:#d1e7dd;border:1px solid #badbcc}.status{display:inline-flex;align-items:center;gap:6px;border-radius:20px;padding:6px 10px;font-size:12px;font-weight:700;white-space:nowrap}
.mobile-menu{display:none}
@media(max-width:768px){.mobile-menu{display:inline-flex;align-items:center;justify-content:center}}
</style>
</head>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

<div class="d-flex">
<?php require_once 'sidebar.php'; ?>
<div class="content flex-grow-1">
<nav class="navbar bg-white shadow-sm px-3 px-md-4 py-3 d-flex align-items-center gap-3">
<button type="button" class="mobile-menu btn btn-primary btn-sm" onclick="toggleSidebar()" aria-label="Open menu"><i class="bi bi-list"></i></button><h4 class="mb-0"><?php echo $isAdmin ? 'All Orders' : 'My Orders'; ?></h4></nav>
<main class="container-fluid py-4">
<?php if ($message !== ''): ?>
<div class="alert alert-info"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
<?php endif; ?>

<div class="card card-box shadow-sm">
<div class="card-body p-4">
<h5 class="fw-bold mb-1">Orders</h5>
<p class="text-muted">Pending orders stay pending until the admin approves them.</p>

<div class="table-responsive">
<table class="table mb-0">
<thead>
<tr>
<th>Order</th>
<?php if ($isAdmin): ?><th>User</th><?php endif; ?>
<th>Customer</th>
<th>Email</th>
<th>Items Bought</th>
<th>Total</th>
<th>Payment</th>
<th>Status</th>
<th>Date</th>
<?php if ($isAdmin): ?><th>Action</th><?php endif; ?>
</tr>
</thead>
<tbody>

<?php if ($orders): ?>
    <?php while ($row = mysqli_fetch_assoc($orders)): ?>
        <?php $status = strtolower((string)($row['status'] ?? 'pending')); ?>
        <tr>
            <td>#<?php echo (int)($row['id'] ?? 0); ?></td>

            <?php if ($isAdmin): ?>
                <td><?php echo (int)($row['user_id'] ?? 0); ?></td>
            <?php endif; ?>

            <td><?php echo htmlspecialchars((string)($row['name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars((string)($row['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>

            <td class="items">
                <?php echo nl2br(htmlspecialchars((string)($row['order_items'] ?? 'No items saved'), ENT_QUOTES, 'UTF-8')); ?>
            </td>

            <td class="total">
                ₦<?php echo number_format((float)($row['total'] ?? 0), 2); ?>
            </td>

            <td><?php echo htmlspecialchars(strtoupper((string)($row['payment_method'] ?? 'N/A')), ENT_QUOTES, 'UTF-8'); ?></td>

            <td>
                <?php if ($status === 'pending'): ?>
                    <span class="status pending">
                        <i class="bi bi-hourglass-split"></i> Pending
                    </span>
                <?php else: ?>
                    <span class="status approved">
                        <i class="bi bi-check-circle"></i> Approved
                    </span>
                <?php endif; ?>
            </td>

            <td><?php echo htmlspecialchars((string)($row['date_created'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>

            <?php if ($isAdmin): ?>
                <td class="text-nowrap">
                    <?php if ($status === 'pending'): ?>
                        <a href="order.php?approve=<?php echo (int)$row['id']; ?>" class="btn btn-sm btn-success">
                            <i class="bi bi-check-lg"></i> Approve
                        </a>
                    <?php endif; ?>

                    <a href="order.php?delete=<?php echo (int)$row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this order?');">
                        Delete
                    </a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr>
        <td colspan="<?php echo $isAdmin ? '10' : '8'; ?>" class="text-center py-5 text-muted">
            No orders found.
        </td>
    </tr>
<?php endif; ?>

</tbody>
</table>
</div>
</div>
</div>
</main>
</div>
</div>

<script>
function toggleSidebar(){
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('show');
}
</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

<?php
require_once "header.php";

if (!isset($_SESSION['id']) || strtolower(trim((string)($_SESSION['role'] ?? ''))) !== 'admin') {
    header("Location: login.php");
    exit();
}

require_once "shop_data.php";

$msg = '';
$editProduct = null;

function adminShopUploadImages($fieldName)
{
    $saved = [];
    if (!isset($_FILES[$fieldName]) || !isset($_FILES[$fieldName]['name'])) return $saved;

    $folder = __DIR__ . '/../assets/image/';
    if (!is_dir($folder)) return $saved;

    $names = $_FILES[$fieldName]['name'];
    $tmpNames = $_FILES[$fieldName]['tmp_name'];
    $errors = $_FILES[$fieldName]['error'];

    if (!is_array($names)) {
        $names = [$names]; $tmpNames = [$tmpNames]; $errors = [$errors];
    }

    foreach ($names as $index => $oldName) {
        if (($errors[$index] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
        $tmp = $tmpNames[$index] ?? '';
        if ($tmp === '' || !is_uploaded_file($tmp)) continue;

        $mime = function_exists('mime_content_type') ? mime_content_type($tmp) : '';
        if ($mime === false || strpos((string)$mime, 'image/') !== 0) continue;

        $extension = strtolower(pathinfo((string)$oldName, PATHINFO_EXTENSION));
        if (!in_array($extension, ['jpg','jpeg','png','gif','webp','bmp','avif'], true)) continue;

        $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename((string)$oldName));
        if ($safeName === '') $safeName = 'product.' . $extension;
        $newName = time() . '_' . bin2hex(random_bytes(6)) . '_' . $safeName;
        if (move_uploaded_file($tmp, $folder . $newName)) $saved[] = 'assets/image/' . $newName;
    }

    return $saved;
}

function adminShopDeleteImage($path)
{
    $path = str_replace('\\', '/', (string)$path);
    if (strpos($path, 'assets/image/') !== 0) return;
    $file = __DIR__ . '/../' . ltrim($path, '/');
    if (is_file($file)) @unlink($file);
}

function adminShopValidateProduct($name, $category, $price, $description)
{
    if ($name === '') return 'Please enter the product name.';
    if ($category === '') return 'Please enter the product category.';
    if ($description === '') return 'Please enter the product description.';
    if ($price === '' || !is_numeric($price) || (float)$price < 0) return 'Please enter a valid price.';
    return '';
}

if (isset($_POST['create_product'])) {
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $oldPrice = trim($_POST['old_price'] ?? '');
    $badge = trim($_POST['badge'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $error = adminShopValidateProduct($name, $category, $price, $description);

    if ($error === '' && $oldPrice !== '' && (!is_numeric($oldPrice) || (float)$oldPrice < 0)) $error = 'Please enter a valid old price.';

    $allImages = $error === '' ? adminShopUploadImages('images') : [];
    $front = $allImages[0] ?? '';
    $back = $allImages[1] ?? '';
    $right = $allImages[2] ?? '';
    $left = $allImages[3] ?? '';
    if ($error === '' && count($allImages) < 2) $error = 'Please choose at least two pictures. Picture 1 is Front and picture 2 is Back.';

    if ($error !== '') {
        foreach ($allImages as $image) adminShopDeleteImage($image);
        foreach ([$front, $back, $right, $left] as $image) if ($image && !in_array($image, $allImages, true)) adminShopDeleteImage($image);
        $msg = "<div class='alert alert-danger'>" . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . "</div>";
    } else {
        $priceValue = (float)$price;
        $oldValue = $oldPrice === '' ? null : (float)$oldPrice;
        $primary = $front ?: ($allImages[0] ?? '');
        if (!$back && isset($allImages[1])) $back = $allImages[1];
        $imagesJson = json_encode(array_values(array_unique(array_merge([$front, $back, $right, $left], $allImages))), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $ok = shopCreateProduct($conn, [
            'name' => $name,
            'category' => $category,
            'price' => $priceValue,
            'old_price' => $oldValue,
            'description' => $description,
            'badge' => $badge,
            'image' => $primary,
            'front_image' => $front,
            'back_image' => $back,
            'right_image' => $right,
            'left_image' => $left,
            'images' => $imagesJson
        ]);

        if ($ok) $msg = "<div class='alert alert-success'>Product added to the shop successfully.</div>";
        else {
            foreach (array_unique(array_merge([$front, $back, $right, $left], $allImages)) as $image) adminShopDeleteImage($image);
            $msg = "<div class='alert alert-danger'>The product could not be saved.</div>";
        }
    }
}

if (isset($_POST['update_product'])) {
    $id = (int)($_POST['edit_id'] ?? 0);
    $name = trim($_POST['edit_name'] ?? '');
    $category = trim($_POST['edit_category'] ?? '');
    $price = trim($_POST['edit_price'] ?? '');
    $oldPrice = trim($_POST['edit_old_price'] ?? '');
    $badge = trim($_POST['edit_badge'] ?? '');
    $description = trim($_POST['edit_description'] ?? '');
    $error = adminShopValidateProduct($name, $category, $price, $description);
    if ($error === '' && $id <= 0) $error = 'Invalid product.';
    if ($error === '' && $oldPrice !== '' && (!is_numeric($oldPrice) || (float)$oldPrice < 0)) $error = 'Please enter a valid old price.';

    $oldRow = $error === '' ? shopGetProduct($conn, $id) : null;
    if (!$oldRow) $error = 'Product not found.';

    $newImages = $error === '' ? adminShopUploadImages('edit_images') : [];
    $keepImages = $_POST['keep_images'] ?? [];
    if (!is_array($keepImages)) $keepImages = [];
    $oldImages = $oldRow ? shopAllImages($oldRow) : [];
    $finalImages = [];
    foreach ($oldImages as $image) {
        if (in_array($image, $keepImages, true)) $finalImages[] = $image;
    }
    foreach ($newImages as $image) $finalImages[] = $image;
    $finalImages = array_values(array_unique($finalImages));

    $front = $finalImages[0] ?? '';
    $back = $finalImages[1] ?? '';
    $right = $finalImages[2] ?? '';
    $left = $finalImages[3] ?? '';

    if ($error === '' && count($finalImages) < 2) {
        $error = 'A shop product needs at least 2 images. Keep two images or upload more images.';
    }

    if ($error !== '') {
        foreach ($newImages as $image) adminShopDeleteImage($image);
        $msg = "<div class='alert alert-danger'>" . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . "</div>";
    } else {
        $priceValue = (float)$price;
        $oldValue = $oldPrice === '' ? null : (float)$oldPrice;
        $primary = $front ?: ($finalImages[0] ?? '');
        $imagesJson = json_encode(array_values(array_unique(array_merge([$front, $back, $right, $left], $finalImages))), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $ok = shopUpdateProduct($conn, $id, [
            'name' => $name,
            'category' => $category,
            'price' => $priceValue,
            'old_price' => $oldValue,
            'description' => $description,
            'badge' => $badge,
            'image' => $primary,
            'front_image' => $front,
            'back_image' => $back,
            'right_image' => $right,
            'left_image' => $left,
            'images' => $imagesJson
        ]);

        if ($ok) {
            foreach ($oldImages as $oldImage) {
                if (!in_array($oldImage, $finalImages, true) && !in_array($oldImage, [$front, $back, $right, $left], true)) adminShopDeleteImage($oldImage);
            }
            $msg = "<div class='alert alert-success'>Product updated successfully.</div>";
        } else {
            foreach ($newImages as $image) adminShopDeleteImage($image);
            $msg = "<div class='alert alert-danger'>The product could not be updated.</div>";
        }
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $row = $id > 0 ? shopGetProduct($conn, $id) : null;

    if ($row) {
        $ok = shopDeleteProduct($conn, $id);
        if ($ok) {
            foreach (shopAllImages($row) as $image) adminShopDeleteImage($image);
            $msg = "<div class='alert alert-success'>Product deleted successfully.</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Product could not be deleted.</div>";
        }
    } elseif ($id > 0) {
        $msg = "<div class='alert alert-danger'>Product not found.</div>";
    }
}

if (isset($_GET['edit'])) {
    $editProduct = shopGetProduct($conn, (int)$_GET['edit']);
}

$products = shopGetAdminProducts($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Shop Products - Larry J Gadjets</title>
<link rel="stylesheet" href="style.css">
<link href="../bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body{background:#f4f7fb}.content{width:100%}.topbar{border-bottom:1px solid #e8edf3}.box{border:0;border-radius:20px}.box-head{background:linear-gradient(135deg,#0d6efd,#174ea6);color:#fff;border-radius:20px 20px 0 0}.form-control,.form-select{min-height:48px}textarea.form-control{min-height:150px}.image-grid{display:flex;flex-wrap:wrap;gap:10px}.image-choice{position:relative;width:100px}.image-choice img{width:100px;height:100px;object-fit:cover;border-radius:10px;border:1px solid #ddd}.product-image{width:70px;height:70px;object-fit:cover;border-radius:12px;border:1px solid #e5e7eb}.description-cell{min-width:220px;max-width:360px;white-space:normal;word-break:break-word}
</style>
</head>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

<div class="d-flex">
<?php require_once "sidebar.php"; ?>
<div class="content flex-grow-1">
<nav class="navbar bg-white px-4 py-3 topbar"><div class="d-flex align-items-center gap-3"><button type="button" class="btn btn-primary d-md-none" onclick="toggleSidebar()"><i class="bi bi-list"></i></button><div><h4 class="mb-1">Manage Shop Products</h4><div class="small text-muted">Add, edit and delete products that appear in Shop.</div></div></div></nav>
<main class="container-fluid py-4">
<?= $msg ?>

<div class="card box shadow-sm mb-4">
<div class="box-head p-4"><h3 class="fw-bold mb-1"><?php echo $editProduct ? 'Edit Shop Product' : 'Post Product to Shop'; ?></h3><div class="text-white-50">Fill the same details that are stored in the shop table.</div></div>
<div class="card-body p-4">
<form method="post" enctype="multipart/form-data">
<?php if ($editProduct): ?><input type="hidden" name="edit_id" value="<?= (int)$editProduct['id'] ?>"><?php endif; ?>
<div class="row g-4">
<div class="col-md-6"><label class="form-label fw-semibold">Product Name</label><input type="text" class="form-control" name="<?php echo $editProduct ? 'edit_name' : 'name'; ?>" maxlength="150" required value="<?= htmlspecialchars($editProduct['name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
<div class="col-md-6"><label class="form-label fw-semibold">Category</label><input type="text" class="form-control" name="<?php echo $editProduct ? 'edit_category' : 'category'; ?>" maxlength="100" required value="<?= htmlspecialchars($editProduct['category'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Mobile Phones"></div>
<div class="col-md-6"><label class="form-label fw-semibold">Price (₦)</label><input type="number" class="form-control" name="<?php echo $editProduct ? 'edit_price' : 'price'; ?>" min="0" step="0.01" required value="<?= htmlspecialchars($editProduct['price'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
<div class="col-md-6"><label class="form-label fw-semibold">Old Price (₦)</label><input type="number" class="form-control" name="<?php echo $editProduct ? 'edit_old_price' : 'old_price'; ?>" min="0" step="0.01" value="<?= htmlspecialchars($editProduct['old_price'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Leave empty when not on sale"></div>
<div class="col-md-6"><label class="form-label fw-semibold">Badge</label><select class="form-select" name="<?php echo $editProduct ? 'edit_badge' : 'badge'; ?>"><option value="">No badge</option><option value="New" <?= (($editProduct['badge'] ?? '') === 'New') ? 'selected' : '' ?>>New</option><option value="Sale" <?= (($editProduct['badge'] ?? '') === 'Sale') ? 'selected' : '' ?>>Sale</option></select></div>
<div class="col-12"><label class="form-label fw-semibold">Description</label><textarea class="form-control" name="<?php echo $editProduct ? 'edit_description' : 'description'; ?>" required><?php echo htmlspecialchars($editProduct['description'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea></div>
<div class="col-12">
<label class="form-label fw-semibold">Pictures</label>
<div class="image-picker-box">
<input type="file" id="shopImages" class="form-control" name="<?php echo $editProduct ? 'edit_images[]' : 'images[]'; ?>" accept="image/*" multiple>
<div id="shopImageList" class="small text-muted mt-2">Choose pictures. Open this box again to add more pictures.</div>
</div>
<?php if ($editProduct): ?>
<div class="image-grid mt-3">
<?php foreach (shopAllImages($editProduct) as $imageIndex => $image): ?>
<div class="image-choice"><img src="<?= htmlspecialchars(shopImageUrl($image), ENT_QUOTES, 'UTF-8') ?>" alt="Product image"><label class="d-block small mt-1"><input type="checkbox" name="keep_images[]" value="<?= htmlspecialchars($image, ENT_QUOTES, 'UTF-8') ?>" checked> Keep #<?= $imageIndex + 1 ?></label></div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
</div>
<div class="mt-4 d-flex flex-wrap gap-2">
<button type="submit" class="btn btn-primary" name="<?php echo $editProduct ? 'update_product' : 'create_product'; ?>"><i class="bi bi-check2-circle me-1"></i><?php echo $editProduct ? 'Save Changes' : 'Post to Shop'; ?></button>
<?php if ($editProduct): ?><a href="admin_shop.php" class="btn btn-outline-secondary">Cancel Edit</a><?php endif; ?>
</div>
</form>
</div>
</div>

<div class="card box shadow-sm">
<div class="card-body p-4"><div class="d-flex justify-content-between align-items-center mb-3"><h4 class="mb-0">Shop Products</h4><span class="text-muted small"><?= count($products) ?> products</span></div>
<div class="table-responsive"><table class="table align-middle"><thead><tr><th>ID</th><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Old Price</th><th>Badge</th><th>Description</th><th>Pictures</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($products as $product): ?>
<tr>
<td><?= (int)$product['id'] ?></td>
<td><img class="product-image" src="<?= htmlspecialchars(shopImageUrl($product['image']), ENT_QUOTES, 'UTF-8') ?>" alt="Product"></td>
<td class="fw-semibold"><?= htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8') ?></td>
<td><?= htmlspecialchars($product['category'], ENT_QUOTES, 'UTF-8') ?></td>
<td>₦<?= number_format((float)$product['price'], 2) ?></td>
<td><?= $product['old_price'] !== null && $product['old_price'] !== '' ? '₦' . number_format((float)$product['old_price'], 2) : '-' ?></td>
<td><?= htmlspecialchars($product['badge'] ?? '', ENT_QUOTES, 'UTF-8') ?: '-' ?></td>
<td class="description-cell"><?= htmlspecialchars($product['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
<td><?= count($product['all_images']) ?></td>
<td><div class="d-flex flex-wrap gap-2"><a href="admin_shop.php?edit=<?= (int)$product['id'] ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil"></i> Edit</a><a href="admin_shop.php?delete=<?= (int)$product['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this shop product?');"><i class="bi bi-trash"></i> Delete</a></div></td>
</tr>
<?php endforeach; ?>
<?php if (!$products): ?><tr><td colspan="10" class="text-center text-muted py-4">No shop products yet.</td></tr><?php endif; ?>
</tbody></table></div>
</div></div>
</main>
</div></div>

<script>
const sidebar = document.querySelector('.sidebar');
if (sidebar) {
    window.toggleSidebar = function () {
        sidebar.classList.toggle('show');
    };
}

const imageBox = document.getElementById('shopImages');
const imageList = document.getElementById('shopImageList');
let chosenImages = new DataTransfer();

if (imageBox) {
    imageBox.addEventListener('click', function () {
        this.value = '';
    });

    imageBox.addEventListener('change', function () {
        for (const image of this.files) {
            const alreadyAdded = Array.from(chosenImages.files).some(function (oldImage) {
                return oldImage.name === image.name && oldImage.size === image.size && oldImage.lastModified === image.lastModified;
            });

            if (!alreadyAdded) chosenImages.items.add(image);
        }

        this.files = chosenImages.files;

        if (imageList) {
            imageList.textContent = chosenImages.files.length + ' picture(s) selected.';
        }
    });
}
</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

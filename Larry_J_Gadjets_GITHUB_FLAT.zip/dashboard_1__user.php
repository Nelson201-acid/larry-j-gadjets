<?php
require_once 'header.php';
require_once 'auth.php';
requireAdmin();

$message = '';

/* Delete a customer. */
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];

    if ($id > 0) {
        $stmt = mysqli_prepare($conn, 'DELETE FROM client WHERE id = ?');
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $id);
            $ok = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $message = $ok ? 'User deleted successfully.' : 'Could not delete the user.';
        }
    }
}

/* Update a customer. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
    $id = (int) ($_POST['id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($id <= 0 || $username === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Enter a valid username and email.';
    } else {
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, 'UPDATE client SET username = ?, email = ?, phone = ?, password = ? WHERE id = ?');
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, 'ssssi', $username, $email, $phone, $hash, $id);
                $ok = mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            } else {
                $ok = false;
            }
        } else {
            $stmt = mysqli_prepare($conn, 'UPDATE client SET username = ?, email = ?, phone = ? WHERE id = ?');
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, 'sssi', $username, $email, $phone, $id);
                $ok = mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            } else {
                $ok = false;
            }
        }

        $message = $ok ? 'User information updated.' : 'Could not update the user.';
    }
}

$clients = mysqli_query($conn, 'SELECT id, username, email, phone, date_created FROM client ORDER BY id DESC');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customers - Larry J Gadjets</title>
<link href="../bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body{margin:0;background:#f4f7fb;overflow-x:hidden}.content{width:100%;min-width:0}.card-box{border:0;border-radius:18px;overflow:hidden}.table th{background:#f8fafc;color:#687385;font-size:12px;text-transform:uppercase}.table td,.table th{padding:14px;vertical-align:middle}
.mobile-menu{display:none}
@media(max-width:768px){.mobile-menu{display:inline-flex;align-items:center;justify-content:center}}
</style>
</head>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

<div class="d-flex">
<?php require_once 'sidebar.php'; ?>
<div class="content flex-grow-1">
<nav class="navbar bg-white shadow-sm px-3 px-md-4 py-3 d-flex align-items-center gap-3">
<button type="button" class="mobile-menu btn btn-primary btn-sm" onclick="toggleSidebar()" aria-label="Open menu"><i class="bi bi-list"></i></button><h4 class="mb-0">Customers</h4></nav>
<main class="container-fluid py-4">
<div class="card card-box shadow-sm">
<div class="card-body p-4">
<h5 class="fw-bold">Customer Accounts</h5>
<p class="text-muted">The admin can edit or delete customer information.</p>
<?php if ($message !== ''): ?><div class="alert alert-info"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
<div class="table-responsive">
<table class="table mb-0">
<thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Phone</th><th>Date</th><th>Action</th></tr></thead>
<tbody>
<?php if ($clients): while ($row = mysqli_fetch_assoc($clients)): ?>
<tr>
<td><?php echo (int)$row['id']; ?></td>
<td><?php echo htmlspecialchars((string)$row['username'], ENT_QUOTES, 'UTF-8'); ?></td>
<td><?php echo htmlspecialchars((string)$row['email'], ENT_QUOTES, 'UTF-8'); ?></td>
<td><?php echo htmlspecialchars((string)($row['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
<td><?php echo htmlspecialchars((string)($row['date_created'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
<td class="text-nowrap">
<button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editUser<?php echo (int)$row['id']; ?>">Edit</button>
<a class="btn btn-sm btn-outline-danger" href="user.php?delete=<?php echo (int)$row['id']; ?>" onclick="return confirm('Delete this user?');">Delete</a>
</td>
</tr>
<div class="modal fade" id="editUser<?php echo (int)$row['id']; ?>" tabindex="-1" aria-hidden="true">
<div class="modal-dialog"><div class="modal-content">
<div class="modal-header"><h5 class="modal-title">Edit User</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
<form method="post">
<div class="modal-body">
<input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>">
<div class="mb-3"><label class="form-label">Username</label><input name="username" class="form-control" value="<?php echo htmlspecialchars((string)$row['username'], ENT_QUOTES, 'UTF-8'); ?>" required></div>
<div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars((string)$row['email'], ENT_QUOTES, 'UTF-8'); ?>" required></div>
<div class="mb-3"><label class="form-label">Phone</label><input name="phone" class="form-control" value="<?php echo htmlspecialchars((string)($row['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
<div><label class="form-label">New Password</label><input type="password" name="password" class="form-control" placeholder="Leave empty to keep it"></div>
</div>
<div class="modal-footer"><button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button><button class="btn btn-primary" name="save_user" value="1">Save</button></div>
</form></div></div></div>
<?php endwhile; else: ?>
<tr><td colspan="6" class="text-center py-5 text-muted">No customers found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div></div>
</main>
</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>function toggleSidebar(){const s=document.querySelector('.sidebar');if(s)s.classList.toggle('show');}</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

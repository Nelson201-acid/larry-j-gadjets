<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us — Larry J Gadjets</title>
<meta name="description" content="Learn about Larry J Gadjets — everyday tech chosen carefully, delivered fast, backed by a real warranty.">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="shop-cart.css">

<style>
  .about-hero-img{ border-radius:var(--radius); overflow:hidden; box-shadow:var(--shadow-lg); }
  .about-hero-img img{ width:100%; height:100%; object-fit:cover; display:block; }
  .stat-card{ text-align:center; padding:1.5rem 1rem; }
  .stat-card .num{ font-family:'Jost',sans-serif; font-weight:700; font-size:2.1rem; color:var(--ink); }
  .stat-card .label{ font-size:.82rem; color:var(--muted); text-transform:uppercase; letter-spacing:.06em; }
  .icon-box-round{
    width:52px; height:52px; border-radius:50%; background:var(--accent-tint); color:var(--accent);
    display:flex; align-items:center; justify-content:center; font-size:1.3rem; flex-shrink:0;
  }
  .team-card{ text-align:center; }
  .team-card .avatar{
    width:120px; height:120px; border-radius:50%; margin:0 auto 1rem; object-fit:cover;
    border:1px solid var(--line);
  }
  .cta-band{ background:var(--ink); color:#fff; border-radius:var(--radius); padding:3rem 2rem; }
</style>

<style id="ljg-preloader-style">
body::before{content:"";position:fixed;inset:0;z-index:2147483647;background:#0b0b0b url("images/main-logo.png") center 45%/min(360px,72vw) auto no-repeat;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:all}body::after{content:"";position:fixed;z-index:2147483647;left:50%;top:60%;width:180px;height:4px;transform:translateX(-50%);border-radius:20px;background:linear-gradient(90deg,transparent,#e10600,transparent);animation:ljgLoad 1.05s ease-in-out infinite;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:none}@keyframes ljgLoad{0%{clip-path:inset(0 100% 0 0)}50%{clip-path:inset(0 0 0 0)}100%{clip-path:inset(0 0 0 100%)}}body.ljg-ready::before,body.ljg-ready::after{opacity:0;visibility:hidden;pointer-events:none}
</style>
<!-- loader-script --><script id="ljg-preloader-script">window.addEventListener('load',function(){if(document.body){document.body.classList.add('ljg-ready');}});</script>
</head>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>


<!-- ============ HEADER ============ -->
<header class="site-header">
  <nav class="navbar navbar-expand-lg py-3">
    <div class="container">
      <a class="brand-mark d-flex align-items-center" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>

      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
        <i class="bi bi-list fs-2"></i>
      </button>

      <div class="collapse navbar-collapse" id="navMain">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="shop.php">Shop</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom active" href="./about.php">About</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#company-services">Services</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="./blog.php">Blog</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="about.php#contact">Contact</a></li>
        </ul>
      </div>

      <div class="d-flex align-items-center gap-1">
        <a href="#" class="icon-btn d-none d-sm-inline-flex"><i class="bi bi-search fs-5"></i></a>
        <a href="#" class="icon-btn d-none d-sm-inline-flex"><i class="bi bi-person fs-5"></i></a>
        <a href="cart.php" class="icon-btn">
          <i class="bi bi-bag fs-5"></i>
          <span class="cart-count">0</span>
        </a>
      </div>
    </div>
  </nav>
</header>

<!-- ============ PAGE BANNER ============ -->
<section class="page-banner">
  <div class="container">
    <div class="eyebrow mb-2">Our Story</div>
    <h1 class="display-5 mb-2">About Larry J Gadjets</h1>
    <div class="breadcrumb-custom small">
      <a href="index.php">Home</a><span class="sep">/</span><span>About</span>
    </div>
  </div>
</section>

<!-- ============ INTRO ============ -->
<section class="py-5">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <div class="eyebrow mb-2">Who we are</div>
        <h2 class="display-6 mb-3">Everyday tech, chosen carefully.</h2>
        <p class="text-muted mb-3">
          Larry J Gadjets started with a simple idea: buying a phone, a watch, or a pair of
          headphones shouldn't mean wading through hundreds of near-identical listings.
          We hand-pick a tight, honest lineup of phones, wearables, audio and accessories —
          test them ourselves, price them fairly, and stand behind every order with a real
          warranty and a real person to talk to if something goes wrong.
        </p>
        <p class="text-muted mb-4">
          No filler catalog, no dropshipping guesswork — just the devices we'd actually
          recommend to a friend, shipped fast and backed properly.
        </p>
        <a href="shop.php" class="btn btn-accent px-4 py-2">Shop All Products</a>
      </div>
      <div class="col-lg-6">
        <div class="about-hero-img" style="aspect-ratio:4/3;">
          <img src="images/iphone 13 f.jpg" alt="Featured Larry J Gadjets device">
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ STATS ============ -->
<section class="py-4 bg-white border-top border-bottom">
  <div class="container">
    <div class="row">
      <div class="col-6 col-lg-3 stat-card">
        <div class="num">12k+</div>
        <div class="label">Orders shipped</div>
      </div>
      <div class="col-6 col-lg-3 stat-card">
        <div class="num">4.8/5</div>
        <div class="label">Average rating</div>
      </div>
      <div class="col-6 col-lg-3 stat-card">
        <div class="num">30-day</div>
        <div class="label">Returns window</div>
      </div>
      <div class="col-6 col-lg-3 stat-card">
        <div class="num">5 yrs</div>
        <div class="label">In business</div>
      </div>
    </div>
  </div>
</section>

<!-- ============ WHY SHOP WITH US ============ -->
<section class="py-5">
  <div class="container">
    <div class="text-center mb-5">
      <div class="eyebrow mb-2">Why shop with us</div>
      <h2 class="display-6">What you get with every order</h2>
    </div>
    <div class="row g-4">
      <div class="col-md-6 col-lg-3">
        <div class="d-flex gap-3">
          <div class="icon-box-round"><i class="bi bi-truck"></i></div>
          <div>
            <h3 class="h6 text-uppercase mb-1">Free delivery</h3>
            <p class="text-muted small mb-0">Free standard shipping on every order over $75, no code needed.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="d-flex gap-3">
          <div class="icon-box-round"><i class="bi bi-patch-check"></i></div>
          <div>
            <h3 class="h6 text-uppercase mb-1">Quality guarantee</h3>
            <p class="text-muted small mb-0">Every device is checked and backed by a genuine manufacturer warranty.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="d-flex gap-3">
          <div class="icon-box-round"><i class="bi bi-tag"></i></div>
          <div>
            <h3 class="h6 text-uppercase mb-1">Daily offers</h3>
            <p class="text-muted small mb-0">Fresh deals on phones and wearables refreshed regularly — no gimmicks.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="d-flex gap-3">
          <div class="icon-box-round"><i class="bi bi-shield-check"></i></div>
          <div>
            <h3 class="h6 text-uppercase mb-1">100% secure payment</h3>
            <p class="text-muted small mb-0">Encrypted checkout with Visa, Mastercard and PayPal support.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ TEAM ============ -->
<section class="py-5 bg-white border-top">
  <div class="container">
    <div class="text-center mb-5">
      <div class="eyebrow mb-2">The people behind it</div>
      <h2 class="display-6">Meet the team</h2>
    </div>
    <div class="row g-4 justify-content-center">
      <div class="col-6 col-md-3 team-card">
        <img class="avatar" src="https://placehold.co/240x240/eef0f5/12141c?text=A" alt="Team member">
        <h3 class="h6 mb-0">Ava Chen</h3>
        <p class="text-muted small">Founder &amp; Buyer</p>
      </div>
      <div class="col-6 col-md-3 team-card">
        <img class="avatar" src="https://placehold.co/240x240/eef0f5/12141c?text=M" alt="Team member">
        <h3 class="h6 mb-0">Marcus Reyes</h3>
        <p class="text-muted small">Operations</p>
      </div>
      <div class="col-6 col-md-3 team-card">
        <img class="avatar" src="https://placehold.co/240x240/eef0f5/12141c?text=S" alt="Team member">
        <h3 class="h6 mb-0">Sofia Novak</h3>
        <p class="text-muted small">Customer Care</p>
      </div>
      <div class="col-6 col-md-3 team-card">
        <img class="avatar" src="https://placehold.co/240x240/eef0f5/12141c?text=J" alt="Team member">
        <h3 class="h6 mb-0">Jamal Whitfield</h3>
        <p class="text-muted small">Product &amp; QA</p>
      </div>
    </div>
  </div>
</section>

<!-- ============ CTA ============ -->
<section class="py-5">
  <div class="container">
    <div class="cta-band d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-4">
      <div>
        <h2 class="h3 mb-2">Ready to upgrade your tech?</h2>
        <p class="mb-0 text-white-50">Browse phones, watches, headphones and accessories — all in one place.</p>
      </div>
      <a href="shop.php" class="btn btn-accent px-4 py-2 flex-shrink-0">Shop Now</a>
    </div>
  </div>
</section>

<!-- ============ FOOTER ============ -->
<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <a class="brand-mark text-white d-inline-block mb-3" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>
        <p class="small">Everyday tech, chosen carefully. Phones, wearables, audio and accessories — delivered fast, backed by a real warranty.</p>
      </div>
      <div class="col-lg-2 col-6">
        <h6>Shop</h6>
        <ul class="list-unstyled small">
          <li class="mb-2"><a href="shop.php">All Products</a></li>
          <li class="mb-2"><a href="cart.php">Cart</a></li>
          <li class="mb-2"><a href="checkout.php">Checkout</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-6">
        <h6>Company</h6>
        <ul class="list-unstyled small">
          <li class="mb-2"><a href="about.php">About Us</a></li>
          <li class="mb-2"><a href="blog.php">Blog</a></li>
          <li class="mb-2"><a href="about.php#contact">Contact</a></li>
        </ul>
      </div>
      <div class="col-lg-4">
        <h6 id="contact">Contact</h6>
        <p class="small mb-1">Questions? <a href="mailto:hello@Larry J Gadjets.example">ugwuanyinelson46@gmail.com</a></p>
        <p class="small">Support line: <a href="tel:+15551234567">+2349043855373</a></p>
      </div>
    </div>
    <div class="fine-print d-flex flex-wrap justify-content-between">
      <span>© 2026 Larry J Gadjets. All rights reserved.</span>
      <span>Secure checkout · Visa · Mastercard · PayPal</span>
    </div>
  </div>
</footer>

<script src="bootstrap.min.js"></script>
<script>
/* =========================================================
   Larry J Gadjets -- cart.js (inlined)
   Inlined directly on the page (instead of an external cart.js
   file) so the cart helpers (getCart, wireAddToCartButtons,
   etc.) are always defined even if an external script fails to
   fetch in this environment. This page has no add-to-cart
   buttons of its own, but keeps the header cart-count badge
   in sync with the rest of the site.
   ========================================================= */

const SHIPPING_FLAT = 6.99;
const FREE_SHIPPING_THRESHOLD = 75;
const TAX_RATE = 0.075;

function getCart() {
  try {
    return JSON.parse(localStorage.getItem("cart")) || [];
  } catch (e) {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}

function addToCart(product, quantity = 1) {
  const cart = getCart();
  const existing = cart.find((item) => item.id === product.id);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ ...product, quantity });
  }
  saveCart(cart);
  return cart;
}

function updateQty(id, quantity) {
  const cart = getCart();
  const item = cart.find((i) => i.id === id);
  if (!item) return cart;
  item.quantity = Math.max(1, Math.min(99, quantity));
  saveCart(cart);
  return cart;
}

function removeFromCart(id) {
  const cart = getCart().filter((i) => i.id !== id);
  saveCart(cart);
  return cart;
}

function clearCart() {
  saveCart([]);
}

function getCartCount() {
  return getCart().reduce((sum, i) => sum + i.quantity, 0);
}

function getCartSubtotal() {
  return getCart().reduce((sum, i) => sum + i.price * i.quantity, 0);
}

function getShippingCost(subtotal) {
  if (subtotal === 0) return 0;
  return subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FLAT;
}

function getTax(subtotal) {
  return subtotal * TAX_RATE;
}

function getCartTotal() {
  const subtotal = getCartSubtotal();
  return subtotal + getShippingCost(subtotal) + getTax(subtotal);
}

function formatCurrency(amount) {
  return "$" + amount.toFixed(2);
}

function updateCartCount() {
  const total = getCartCount();
  const byId = document.getElementById("cart-count");
  if (byId) byId.textContent = total;
  document.querySelectorAll(".cart-count").forEach((el) => {
    el.textContent = total;
    el.style.display = total > 0 ? "flex" : "none";
  });
}

function wireAddToCartButtons() {
  document.querySelectorAll(".add-cart").forEach((button) => {
    if (button.dataset.wired) return;
    button.dataset.wired = "true";

    button.addEventListener("click", function (e) {
      e.preventDefault();

      const id = this.dataset.id;
      const name = this.dataset.name;
      const price = Number(this.dataset.price);
      const image = this.dataset.image;
      const category = this.dataset.category || "";

      if (!id) {
        console.warn("Add to Cart button is missing data-id/data-name/data-price attributes.");
        return;
      }

      addToCart({ id, name, price, image, category });

      document.dispatchEvent(
        new CustomEvent("cart:item-added", { detail: { id, name, price, image, category } })
      );
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  wireAddToCartButtons();
  updateCartCount();
});
</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

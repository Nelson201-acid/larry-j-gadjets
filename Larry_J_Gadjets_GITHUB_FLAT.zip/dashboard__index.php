<?php
require_once 'header.php';
require_once 'auth.php';

if ($isAdmin) {
    header('Location: ../dashboard%201/index.php');
    exit();
}

$userId = (int) $_SESSION['id'];
$username = (string) ($_SESSION['username'] ?? 'Customer');
$email = (string) ($_SESSION['email'] ?? '');
$image = getProfileImage();
$imageFile = profileImageFile($image);
$imageUrl = profileImageUrl($image);

$stmt = mysqli_prepare($conn, 'SELECT username, email FROM client WHERE id = ? LIMIT 1');
if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        $username = (string)($row['username'] ?? $username);
        $email = (string)($row['email'] ?? $email);
    }
    mysqli_stmt_close($stmt);
}

$orders = false;
$stmt = mysqli_prepare($conn, 'SELECT * FROM orders WHERE user_id = ? OR LOWER(email) = LOWER(?) ORDER BY id DESC');
if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'is', $userId, $email);
    mysqli_stmt_execute($stmt);
    $orders = mysqli_stmt_get_result($stmt);
    mysqli_stmt_close($stmt);
}
$totalOrders = $orders ? mysqli_num_rows($orders) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Dashboard - Larry J Gadjets</title>
<link href="../bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body{margin:0;background:#f4f7fb;color:#172033;overflow-x:hidden}.content{width:100%;min-width:0}.hero{background:linear-gradient(135deg,#0d6efd,#174ea6);color:#fff;border-radius:20px}.card-box{border:0;border-radius:18px}.table th{background:#f8fafc;color:#687385;font-size:12px;text-transform:uppercase}.table td,.table th{padding:14px;vertical-align:middle}
.top-profile{width:44px;height:44px;border-radius:50%;object-fit:cover}.profile-fallback{background:#0d6efd;color:#fff;align-items:center;justify-content:center;font-weight:700}.mobile-menu{display:none}
@media(max-width:768px){.mobile-menu{display:inline-flex;align-items:center;justify-content:center}.content{min-width:0}.table-responsive{max-width:100%;overflow-x:auto}.hero{border-radius:14px}.card-body{padding:16px!important}}
</style>
<style>
.ljg-preloader{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:#fff;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease}.ljg-preloader.is-hidden{opacity:0;visibility:hidden;pointer-events:none}.ljg-preloader-box{text-align:center;width:min(90vw,360px);padding:28px}.ljg-preloader-logo{width:min(72vw,220px);height:auto;display:block;margin:0 auto 22px}.ljg-preloader-track{width:190px;height:4px;margin:0 auto 12px;background:#ececec;border-radius:10px;overflow:hidden}.ljg-preloader-track span{display:block;width:42%;height:100%;background:#dc1927;border-radius:10px;animation:ljgLoader 1.05s ease-in-out infinite}.ljg-preloader-text{margin:0;font:500 13px/1.4 Arial,sans-serif;color:#555;letter-spacing:.4px}@keyframes ljgLoader{0%{transform:translateX(-120%)}50%{transform:translateX(130%)}100%{transform:translateX(270%)}}
</style>
</head>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

<div class="d-flex">
<?php require_once 'sidebar.php'; ?>
<div class="content flex-grow-1">
<nav class="navbar bg-white shadow-sm px-3 px-md-4 py-3 d-flex align-items-center gap-3">
<button type="button" class="mobile-menu btn btn-primary btn-sm" onclick="toggleSidebar()" aria-label="Open menu"><i class="bi bi-list"></i></button>
<h4 class="mb-0">My Dashboard</h4>
<div class="ms-auto">
<?php if ($image !== '' && is_file($imageFile)): ?>
<img src="<?php echo htmlspecialchars($imageUrl, ENT_QUOTES, 'UTF-8'); ?>" class="top-profile" alt="Profile" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
<div class="top-profile profile-fallback" style="display:none"><?php echo strtoupper(substr($username,0,1)); ?></div>
<?php else: ?>
<div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold" style="width:44px;height:44px"><?php echo strtoupper(substr($username,0,1)); ?></div>
<?php endif; ?>
</div>
</nav>
<main class="container-fluid py-4">
<div class="hero p-4 mb-4"><div class="fs-5">Welcome back, <?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></div><div class="mt-1">You are logged in. Use the sidebar to move around without logging in again.</div></div>
<div class="card card-box shadow-sm">
<div class="card-body p-4">
<h5 class="fw-bold">My Orders (<?php echo $totalOrders; ?>)</h5>
<div class="table-responsive">
<table class="table mb-0"><thead><tr><th>Order</th><th>Items Bought</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead><tbody>
<?php if ($orders): while ($row = mysqli_fetch_assoc($orders)): ?>
<tr><td>#<?php echo (int)$row['id']; ?></td><td><?php echo htmlspecialchars((string)($row['order_items'] ?? 'No items saved'), ENT_QUOTES, 'UTF-8'); ?></td><td class="fw-bold">₦<?php echo number_format((float)($row['total'] ?? 0),2); ?></td><td><?php echo htmlspecialchars(strtoupper((string)($row['payment_method'] ?? 'N/A')), ENT_QUOTES, 'UTF-8'); ?></td><td><?php echo strtolower((string)($row['status'] ?? 'pending')) === 'pending' ? '<span class="badge text-bg-warning">Pending</span>' : '<span class="badge text-bg-success">Approved</span>'; ?></td><td><?php echo htmlspecialchars((string)($row['date_created'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td></tr>
<?php endwhile; else: ?><tr><td colspan="6" class="text-center py-5 text-muted">No orders yet.</td></tr><?php endif; ?>
</tbody></table>
</div></div></div>
</main></div></div>
<script>function toggleSidebar(){const s=document.querySelector('.sidebar');if(s)s.classList.toggle('show');}</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body></html>

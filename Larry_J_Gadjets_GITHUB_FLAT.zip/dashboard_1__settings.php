<?php
require_once 'header.php';
require_once 'auth.php';

$userId = (int) $_SESSION['id'];
$message = '';
$messageType = 'info';

/* Save account changes. */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $imageName = getProfileImage();

    if ($username === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a username and a correct email.';
        $messageType = 'danger';
    } else {
        /* A new picture is optional. It stays inside the existing image folder. */
        if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $imageInfo = @getimagesize($_FILES['image']['tmp_name']);

            if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                $message = 'The picture could not be uploaded.';
                $messageType = 'danger';
            } elseif (!in_array($extension, $allowed, true) || $imageInfo === false) {
                $message = 'Please choose a real JPG, PNG, GIF or WEBP image.';
                $messageType = 'danger';
            } else {
                $folder = __DIR__ . '/../assets/image/';

                $imageName = 'profile_' . $userId . '_' . time() . '.' . $extension;

                if (!move_uploaded_file($_FILES['image']['tmp_name'], $folder . $imageName)) {
                    $message = 'The picture could not be saved.';
                    $messageType = 'danger';
                }
            }
        }

        if ($message === '') {
            if ($password !== '') {
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = mysqli_prepare(
                    $conn,
                    'UPDATE client SET username = ?, email = ?, phone = ?, password = ?, image = ? WHERE id = ?'
                );

                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, 'sssssi', $username, $email, $phone, $passwordHash, $imageName, $userId);
                    $ok = mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    $ok = false;
                }
            } else {
                $stmt = mysqli_prepare(
                    $conn,
                    'UPDATE client SET username = ?, email = ?, phone = ?, image = ? WHERE id = ?'
                );

                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, 'ssssi', $username, $email, $phone, $imageName, $userId);
                    $ok = mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    $ok = false;
                }
            }

            if ($ok) {
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $email;
                $_SESSION['image'] = pictureName($imageName);
                $message = 'Your settings were saved successfully.';
                $messageType = 'success';
            } else {
                $message = 'The settings could not be saved.';
                $messageType = 'danger';
            }
        }
    }
}

/* Always read the newest information from the database. */
$username = (string) ($_SESSION['username'] ?? '');
$email = (string) ($_SESSION['email'] ?? '');
$phone = '';
$image = getProfileImage();

$stmt = mysqli_prepare($conn, 'SELECT username, email, phone, image FROM client WHERE id = ? LIMIT 1');
if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $username = (string) ($row['username'] ?? $username);
        $email = (string) ($row['email'] ?? $email);
        $phone = (string) ($row['phone'] ?? '');

        if (trim((string) ($row['image'] ?? '')) !== '') {
            $image = pictureName((string) $row['image']);
            $_SESSION['image'] = $image;
        }
    }

    mysqli_stmt_close($stmt);
}

$imageFile = profileImageFile($image);
$imageUrl = profileImageUrl($image);
$firstLetter = strtoupper(substr($username !== '' ? $username : 'U', 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Settings - Larry J Gadjets</title>
<link href="../bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
*{box-sizing:border-box}
body{margin:0;background:#f4f7fb;color:#172033;overflow-x:hidden}
.content{width:100%;min-width:0}
.card-box{border:0;border-radius:18px}
.profile-picture{width:110px;height:110px;border-radius:50%;object-fit:cover;border:4px solid #fff;box-shadow:0 4px 15px rgba(0,0,0,.12)}
.profile-letter{display:flex;align-items:center;justify-content:center;background:#0d6efd;color:#fff;font-size:36px;font-weight:800;margin:auto}
.form-control{min-height:46px}
@media(max-width:576px){.navbar h4{font-size:18px}.card-body{padding:20px!important}.profile-picture{width:90px;height:90px}.form-control{min-height:44px}.btn{width:100%}}
.mobile-menu{display:none}
@media(max-width:768px){.mobile-menu{display:inline-flex;align-items:center;justify-content:center}}
</style>
</head>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

<div class="d-flex">
<?php require_once 'sidebar.php'; ?>
<div class="content flex-grow-1">
<nav class="navbar bg-white shadow-sm px-3 px-md-4 py-3 d-flex align-items-center gap-3">
<button type="button" class="mobile-menu btn btn-primary btn-sm" onclick="toggleSidebar()" aria-label="Open menu"><i class="bi bi-list"></i></button>
<h4 class="mb-0">Settings</h4>
</nav>

<main class="container-fluid py-4">
<div class="card card-box shadow-sm mx-auto" style="max-width:700px">
<div class="card-body p-4 p-md-5">
<h5 class="fw-bold">My Account</h5>
<p class="text-muted mb-4">Update your details and profile picture.</p>

<?php if ($message !== ''): ?>
<div class="alert alert-<?php echo $messageType; ?>" role="alert">
<?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
</div>
<?php endif; ?>

<div class="text-center mb-4">
<?php if ($image !== '' && is_file($imageFile)): ?>
<img src="<?php echo htmlspecialchars($imageUrl, ENT_QUOTES, 'UTF-8'); ?>" class="profile-picture" alt="Profile picture" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
<div class="profile-picture profile-letter" style="display:none"><?php echo htmlspecialchars($firstLetter, ENT_QUOTES, 'UTF-8'); ?></div>
<?php else: ?>
<div class="profile-picture profile-letter"><?php echo htmlspecialchars($firstLetter, ENT_QUOTES, 'UTF-8'); ?></div>
<?php endif; ?>
</div>

<form method="post" enctype="multipart/form-data">
<div class="mb-3">
<label class="form-label fw-semibold">Username</label>
<input name="username" class="form-control" value="<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>" required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Email</label>
<input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>" required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Phone</label>
<input name="phone" class="form-control" value="<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>">
</div>

<div class="mb-3">
<label class="form-label fw-semibold">Profile Picture</label>
<input type="file" name="image" class="form-control" accept=".jpg,.jpeg,.png,.gif,.webp,image/*">
<div class="form-text">The picture is saved in ../assets/image/.</div>
</div>

<div class="mb-4">
<label class="form-label fw-semibold">New Password</label>
<input type="password" name="password" class="form-control" placeholder="Leave empty to keep the current password" autocomplete="new-password">
</div>

<button type="submit" class="btn btn-primary px-4">
<i class="bi bi-check2-circle me-1"></i> Save Settings
</button>
</form>
</div>
</div>
</main>
</div>
</div>

<script>
function toggleSidebar(){
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('show');
}
</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

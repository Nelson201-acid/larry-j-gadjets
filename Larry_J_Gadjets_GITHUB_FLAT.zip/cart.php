<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isLoggedIn = isset($_SESSION['id']);

$dashboard = ($isLoggedIn && strtolower((string)($_SESSION['role'] ?? 'customer')) === 'admin')
    ? 'dashboard%201/index.php'
    : 'dashboard/index.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Your Cart — Larry J Gadjets</title>

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="bootstrap.min.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

<link rel="stylesheet" href="shop-cart.css">


<style id="ljg-preloader-style">
body::before{content:"";position:fixed;inset:0;z-index:2147483647;background:#0b0b0b url("images/main-logo.png") center 45%/min(360px,72vw) auto no-repeat;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:all}body::after{content:"";position:fixed;z-index:2147483647;left:50%;top:60%;width:180px;height:4px;transform:translateX(-50%);border-radius:20px;background:linear-gradient(90deg,transparent,#e10600,transparent);animation:ljgLoad 1.05s ease-in-out infinite;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:none}@keyframes ljgLoad{0%{clip-path:inset(0 100% 0 0)}50%{clip-path:inset(0 0 0 0)}100%{clip-path:inset(0 0 0 100%)}}body.ljg-ready::before,body.ljg-ready::after{opacity:0;visibility:hidden;pointer-events:none}
</style>
<!-- loader-script --><script id="ljg-preloader-script">window.addEventListener('load',function(){if(document.body){document.body.classList.add('ljg-ready');}});</script>
</head>

<body data-user-id="<?php echo $isLoggedIn ? (int) $_SESSION['id'] : 0; ?>">
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>


<!-- ============ HEADER ============ -->

<header class="site-header">

  <nav class="navbar navbar-expand-lg py-3">

    <div class="container">

      <a class="brand-mark d-flex align-items-center" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>

      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">

        <i class="bi bi-list fs-2"></i>

      </button>

      <div class="collapse navbar-collapse" id="navMain">

        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">

          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php">Home</a></li>

          <li class="nav-item"><a class="nav-link nav-link-custom" href="shop.php">Shop</a></li>

          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#company-services">Services</a></li>

          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#latest-blog">Blog</a></li>

          <li class="nav-item"><a class="nav-link nav-link-custom" href="about.php#contact">Contact</a></li>

        </ul>

      </div>

      <div class="d-flex align-items-center gap-1">

        <a href="#" class="icon-btn d-none d-sm-inline-flex">
          <i class="bi bi-search fs-5"></i>
        </a>

        <a href="<?php echo $isLoggedIn ? $dashboard : 'dashboard/login.php'; ?>" class="icon-btn d-none d-sm-inline-flex" title="Dashboard">
          <i class="bi bi-speedometer2 fs-5"></i>
        </a>

        <a href="cart.php" class="icon-btn">
          <i class="bi bi-bag fs-5"></i>
          <span id="cart-count" class="cart-count">0</span>
        </a>

      </div>

    </div>

  </nav>

</header>

<!-- ============ PAGE BANNER ============ -->

<div class="page-banner">

  <div class="container-fluid">

    <div class="eyebrow mb-2">Step 1 of 2</div>

    <h1 class="display-5 mb-2">Your Cart</h1>

    <div class="breadcrumb-custom small">
      <a href="index.php">Home</a>
      <span class="sep">/</span>
      <a href="shop.php">Shop</a>
      <span class="sep">/</span>
      <span>Cart</span>
    </div>

  </div>

</div>

<section class="py-5">

  <div class="container-fluid">

    <!-- ============ CART WITH ITEMS ============ -->

    <div class="row g-4" id="cartLoaded">

      <div class="col-lg-8">

        <div class="d-flex justify-content-between align-items-center mb-3">

          <h2 class="h5 mb-0">
            <span id="itemCount">0</span> item(s) in your cart
          </h2>

          <button id="clearCartBtn" class="btn btn-ghost btn-sm">
            <i class="bi bi-trash3 me-1"></i> Empty Cart
          </button>

        </div>

        <div class="form-card p-0">
          <div id="cartLines" class="px-4"></div>
        </div>

        <a href="shop.php" class="btn btn-outline-ink mt-4">
          <i class="bi bi-arrow-left me-1"></i> Continue Shopping
        </a>

      </div>

      <div class="col-lg-4">

        <div class="summary-card">

          <h3 class="h6 text-uppercase mb-3" style="letter-spacing:.06em;">Order Summary</h3>

          <div class="summary-row">
            <span>Subtotal</span>
            <span id="sumSubtotal">₦0.00</span>
          </div>

          <div class="summary-row">
            <span>Estimated Shipping</span>
            <span id="sumShipping">₦0.00</span>
          </div>

          <div class="summary-row">
            <span>Estimated Tax</span>
            <span id="sumTax">₦0.00</span>
          </div>

          <div class="summary-row total">
            <span>Total</span>
            <span id="sumTotal">₦0.00</span>
          </div>

          <p class="small text-muted mt-2 mb-4" id="freeShipMsg"></p>

          <a href="<?php echo $isLoggedIn ? 'checkout.php' : 'dashboard/login.php'; ?>" class="btn btn-accent w-100 py-2">
            Proceed to Checkout <i class="bi bi-arrow-right ms-1"></i>
          </a>

          <div class="d-flex align-items-center justify-content-center gap-2 mt-3 text-muted small">
            <i class="bi bi-shield-check"></i> Secure checkout
          </div>

        </div>

      </div>

    </div>

    <!-- ============ EMPTY STATE ============ -->

    <div class="empty-state d-none" id="cartEmpty">

      <i class="bi bi-bag-x fs-1 text-muted"></i>

      <h3 class="mt-3">Your cart is empty</h3>

      <p class="text-muted">Looks like you haven't added anything yet.</p>

      <a href="shop.php" class="btn btn-ink mt-2">Start Shopping</a>

    </div>

  </div>

</section>

<!-- ============ FOOTER ============ -->

<footer class="site-footer">

  <div class="container">

    <div class="row g-4">

      <div class="col-lg-4">

        <a class="brand-mark text-white d-inline-block mb-3" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>

        <p class="small">Everyday tech, chosen carefully. Phones, wearables, audio and accessories — delivered fast, backed by a real warranty.</p>

      </div>

      <div class="col-lg-2 col-6">

        <h6>Shop</h6>

        <ul class="list-unstyled small">

          <li class="mb-2"><a href="shop.php">All Products</a></li>

          <li class="mb-2"><a href="cart.php">Cart</a></li>

          <li class="mb-2"><a href="<?php echo $isLoggedIn ? 'checkout.php' : 'dashboard/login.php'; ?>">Checkout</a></li>

        </ul>

      </div>

      <div class="col-lg-2 col-6">

        <h6>Company</h6>

        <ul class="list-unstyled small">

          <li class="mb-2"><a href="about.php">About Us</a></li>

          <li class="mb-2"><a href="blog.php">Blog</a></li>

          <li class="mb-2"><a href="about.php#contact">Contact</a></li>

        </ul>

      </div>

      <div class="col-lg-4">

        <h6>Contact</h6>

        <p class="small mb-1">Questions? <a href="mailto:hello@Larry J Gadjets.example">ugwuanyinelson46@gmail.com</a></p>

        <p class="small">Support line: <a href="tel:+15551234567">+2349043855373</a></p>

      </div>

    </div>

    <div class="fine-print d-flex flex-wrap justify-content-between">

      <span>© 2026 Larry J Gadjets. All rights reserved.</span>

      <span>Secure checkout · Visa · Mastercard · PayPal</span>

    </div>

  </div>

</footer>

<script src="bootstrap.min.js"></script>
<script src="cart.js"></script>

<script>

const cartLoaded = document.getElementById('cartLoaded');
const cartEmpty = document.getElementById('cartEmpty');
const cartLines = document.getElementById('cartLines');
const itemCount = document.getElementById('itemCount');
const clearCartBtn = document.getElementById('clearCartBtn');
const sumSubtotal = document.getElementById('sumSubtotal');
const sumShipping = document.getElementById('sumShipping');
const sumTax = document.getElementById('sumTax');
const sumTotal = document.getElementById('sumTotal');
const freeShipMsg = document.getElementById('freeShipMsg');

function renderCart() {
    const cart = getCart();

    if (!cart.length) {
        cartLoaded.classList.add('d-none');
        cartEmpty.classList.remove('d-none');
        return;
    }

    cartLoaded.classList.remove('d-none');
    cartEmpty.classList.add('d-none');

    itemCount.textContent = cart.reduce(function(total, item) {
        return total + Number(item.quantity || 0);
    }, 0);

    cartLines.innerHTML = cart.map(function(item) {
        const price = Number(item.price) || 0;
        const quantity = Number(item.quantity) || 1;
        const lineTotal = price * quantity;
        const image = item.image || '';

        return `
            <div class="py-4 border-bottom">
                <div class="row align-items-center g-3">
                    <div class="col-3 col-sm-2">
                        ${image ? `<img src="${image}" alt="${item.name}" class="img-fluid rounded">` : ''}
                    </div>
                    <div class="col-9 col-sm-5">
                        <h3 class="h6 mb-1">${item.name}</h3>
                        <div class="small text-muted">${formatCurrency(price)} each</div>
                    </div>
                    <div class="col-6 col-sm-2">
                        <input
                            type="number"
                            min="1"
                            value="${quantity}"
                            class="form-control cart-quantity"
                            data-id="${item.id}"
                        >
                    </div>
                    <div class="col-6 col-sm-2 text-end">
                        <div class="fw-semibold">${formatCurrency(lineTotal)}</div>
                        <button class="btn btn-link text-danger p-0 remove-cart" data-id="${item.id}">Remove</button>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    const subtotal = getCartSubtotal();
    const shipping = getShippingCost(subtotal);
    const tax = getTax(subtotal);
    const total = subtotal + shipping + tax;

    sumSubtotal.textContent = formatCurrency(subtotal);
    sumShipping.textContent = shipping ? formatCurrency(shipping) : 'Free';
    sumTax.textContent = formatCurrency(tax);
    sumTotal.textContent = formatCurrency(total);

    if (shipping > 0) {
        freeShipMsg.textContent = 'Free shipping on orders of ' + formatCurrency(FREE_SHIPPING_THRESHOLD) + ' or more.';
    } else {
        freeShipMsg.textContent = 'You have free shipping.';
    }
}

document.addEventListener('change', function(event) {
    if (!event.target.classList.contains('cart-quantity')) {
        return;
    }

    updateCartQuantity(
        event.target.getAttribute('data-id'),
        event.target.value
    );

    renderCart();
});

document.addEventListener('click', function(event) {
    const removeButton = event.target.closest('.remove-cart');

    if (removeButton) {
        removeFromCart(removeButton.getAttribute('data-id'));
        renderCart();
        return;
    }
});

clearCartBtn.addEventListener('click', function() {
    clearCart();
    renderCart();
});

document.addEventListener('DOMContentLoaded', function() {
    renderCart();
    updateCartCount();
});

</script>


<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

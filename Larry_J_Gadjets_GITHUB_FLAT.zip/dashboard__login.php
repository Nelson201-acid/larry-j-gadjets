<?php

session_start();

require_once "header.php";

/* Send an already-logged-in person to the home page. */

if (isset($_SESSION['id'], $_SESSION['role'])) {

    $role = strtolower(trim((string) $_SESSION['role']));

    if ($role === 'admin') {

        header('Location: ../dashboard%201/index.php');
        exit();

    }

    if ($role === 'customer' || $role === 'user') {

        header('Location: ../dashboard/index.php');
        exit();

    }
}

$message = '';
$login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $login = trim((string) ($_POST['login'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if ($login === '' || $password === '') {

        $message = 'Please enter your username or email and password.';

    } else {

        /* Find the account by username or email. */

        $sql = "SELECT id, username, email, password, role, image
                FROM client
                WHERE LOWER(email) = LOWER(?)
                   OR LOWER(username) = LOWER(?)
                LIMIT 1";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {

            $message = 'Login could not be completed.';

        } else {

            mysqli_stmt_bind_param(
                $stmt,
                'ss',
                $login,
                $login
            );

            if (!mysqli_stmt_execute($stmt)) {

                $message = 'Login could not be completed.';

            } else {

                mysqli_stmt_bind_result(
                    $stmt,
                    $id,
                    $username,
                    $email,
                    $savedPassword,
                    $role,
                    $image
                );

                if (mysqli_stmt_fetch($stmt)) {

                    $savedPassword = (string) $savedPassword;
                    $role = strtolower(trim((string) $role));

                    /*
                        Check the password exactly as it is stored.
                        Modern hashes use password_verify().
                        Older projects may have plain, MD5, SHA1 or SHA256 values.
                    */

                    $passwordOK = false;

                    if (
                        $savedPassword !== '' &&
                        password_verify(
                            $password,
                            $savedPassword
                        )
                    ) {

                        $passwordOK = true;

                    }

                    if (
                        !$passwordOK &&
                        $savedPassword !== '' &&
                        hash_equals(
                            $savedPassword,
                            $password
                        )
                    ) {

                        $passwordOK = true;

                    }

                    if (
                        !$passwordOK &&
                        strlen($savedPassword) === 32 &&
                        hash_equals(
                            $savedPassword,
                            md5($password)
                        )
                    ) {

                        $passwordOK = true;

                    }

                    if (
                        !$passwordOK &&
                        strlen($savedPassword) === 40 &&
                        hash_equals(
                            $savedPassword,
                            sha1($password)
                        )
                    ) {

                        $passwordOK = true;

                    }

                    if (
                        !$passwordOK &&
                        strlen($savedPassword) === 64 &&
                        hash_equals(
                            $savedPassword,
                            hash('sha256', $password)
                        )
                    ) {

                        $passwordOK = true;

                    }

                    /* Accept the old "user" role as a customer dashboard. */

                    if (
                        $role === 'user' ||
                        $role === 'client'
                    ) {

                        $role = 'customer';

                    }

                    if (
                        $passwordOK &&
                        (
                            $role === 'admin' ||
                            $role === 'customer'
                        )
                    ) {

                        session_regenerate_id(true);

                        $_SESSION['id'] =
                            (int) $id;

                        $_SESSION['username'] =
                            (string) $username;

                        $_SESSION['email'] =
                            (string) $email;

                        $_SESSION['role'] =
                            $role;

                        $image =
                            str_replace(
                                '\\',
                                '/',
                                (string) $image
                            );

                        $image =
                            urldecode($image);

                        $image =
                            explode(
                                '?',
                                $image,
                                2
                            )[0];

                        $image =
                            explode(
                                '#',
                                $image,
                                2
                            )[0];

                        $_SESSION['image'] =
                            basename($image);

                        mysqli_stmt_close($stmt);

                        /*
                           Send each valid role to its own dashboard.
                        */

                        if ($role === 'admin') {

                            header('Location: ../dashboard%201/index.php');

                        } else {

                            header('Location: ../dashboard/index.php');

                        }

                        exit();

                    }

                }

                if ($message === '') {

                    $message =
                        'The username/email or password is not correct.';

                }

            }

            if (
                isset($stmt) &&
                $stmt instanceof mysqli_stmt
            ) {

                mysqli_stmt_close($stmt);

            }

        }

    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login - Larry J Gadjets</title>

    <link
        href="../bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {

            margin: 0;
            min-height: 100vh;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f4f7fb;

        }

        .login-box {

            width: 100%;
            max-width: 430px;
            border: 0;
            border-radius: 20px;
            overflow: hidden;

        }

        .form-control {

            min-height: 48px;

        }

        .login-button {

            min-height: 48px;
            font-weight: 600;

        }

        .register-link {

            color: #0d6efd;
            font-weight: 700;
            text-decoration: none;

        }

        .register-link:hover {

            text-decoration: underline;

        }

        @media (max-width: 576px) {

            body {
                padding: 12px;
            }

            .card-body {
                padding: 24px !important;
            }

        }

    </style>

<style>
.ljg-preloader{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:#fff;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease}.ljg-preloader.is-hidden{opacity:0;visibility:hidden;pointer-events:none}.ljg-preloader-box{text-align:center;width:min(90vw,360px);padding:28px}.ljg-preloader-logo{width:min(72vw,220px);height:auto;display:block;margin:0 auto 22px}.ljg-preloader-track{width:190px;height:4px;margin:0 auto 12px;background:#ececec;border-radius:10px;overflow:hidden}.ljg-preloader-track span{display:block;width:42%;height:100%;background:#dc1927;border-radius:10px;animation:ljgLoader 1.05s ease-in-out infinite}.ljg-preloader-text{margin:0;font:500 13px/1.4 Arial,sans-serif;color:#555;letter-spacing:.4px}@keyframes ljgLoader{0%{transform:translateX(-120%)}50%{transform:translateX(130%)}100%{transform:translateX(270%)}}
</style>
</head>

<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>


<div class="card login-box shadow-sm">

    <div class="card-body p-4 p-md-5">

        <h2 class="fw-bold mb-1">
            Larry J Gadjets
        </h2>

        <p class="text-muted mb-4">
            Login to continue to your dashboard.
        </p>

        <?php if ($message !== ''): ?>

            <div
                class="alert alert-danger"
                role="alert"
            >

                <?php
                echo htmlspecialchars(
                    $message,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>

            </div>

        <?php endif; ?>

        <form method="post" action="">

            <div class="mb-3">

                <label
                    for="login"
                    class="form-label"
                >
                    Username or Email
                </label>

                <input
                    type="text"
                    id="login"
                    name="login"
                    class="form-control"
                    value="<?php echo htmlspecialchars($login, ENT_QUOTES, 'UTF-8'); ?>"
                    autocomplete="username"
                    required
                >

            </div>

            <div class="mb-4">

                <label
                    for="password"
                    class="form-label"
                >
                    Password
                </label>

                <div class="input-group">

                    <input
                        type="password"
                        id="password"
                        name="password"
                        class="form-control"
                        autocomplete="current-password"
                        required
                    >

                    <button
                        type="button"
                        class="btn btn-outline-secondary"
                        onclick="togglePassword()"
                        aria-label="Show or hide password"
                    >

                        <i
                            class="bi bi-eye"
                            id="eyeIcon"
                        ></i>

                    </button>

                </div>

            </div>

            <button
                type="submit"
                class="btn btn-primary w-100 login-button"
            >

                <i class="bi bi-box-arrow-in-right me-1"></i>

                Login

            </button>

        </form>

        <div class="text-center mt-4 pt-3 border-top">

            <p class="text-muted small mb-2">
                Don't have an account yet?
            </p>

            <a
                href="register.php"
                class="register-link"
            >
                Register here
            </a>

        </div>

        <a
            href="../index.php"
            class="d-block text-center mt-3 text-decoration-none text-muted small"
        >
            Back to Store
        </a>

    </div>

</div>

<script>

function togglePassword() {

    const password =
        document.getElementById(
            'password'
        );

    const eyeIcon =
        document.getElementById(
            'eyeIcon'
        );

    if (
        password.type ===
        'password'
    ) {

        password.type =
            'text';

        eyeIcon.classList.remove(
            'bi-eye'
        );

        eyeIcon.classList.add(
            'bi-eye-slash'
        );

    } else {

        password.type =
            'password';

        eyeIcon.classList.remove(
            'bi-eye-slash'
        );

        eyeIcon.classList.add(
            'bi-eye'
        );

    }

}

</script>


<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>
-- Larry J Gadjets uses ONE account table: client
-- Run this once in phpMyAdmin if role or image is missing.

USE ecommerce;

ALTER TABLE client
ADD COLUMN IF NOT EXISTS role VARCHAR(20) NOT NULL DEFAULT 'customer';

ALTER TABLE client
ADD COLUMN IF NOT EXISTS image VARCHAR(255) NULL;

-- After you know the admin email, make that account the admin.
-- Example:
-- UPDATE client SET role = 'admin' WHERE email = 'your-admin-email@example.com';

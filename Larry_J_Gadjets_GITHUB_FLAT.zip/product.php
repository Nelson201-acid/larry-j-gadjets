<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once "dashboard/header.php";
require_once "shop_data.php";

$isLoggedIn = isset($_SESSION['id']);
$source = strtolower(trim((string)($_GET['source'] ?? 'shop')));
$currentId = (int)($_GET['id'] ?? 0);
$currentImage = max(0, (int)($_GET['image'] ?? 0));
$currentView = strtolower(trim((string)($_GET['view'] ?? '')));
$product = null;
$related = [];
$carouselProducts = [];
$currentIndex = 0;

function productSafe($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$shopProducts = shopGetProducts($conn, '', 'featured');
$latestPost = shopLatestPost($conn);

if ($latestPost) {
    $latestPost['name'] = (string)($latestPost['title'] ?? 'Latest Product');
    $latestPost['category'] = 'Latest Product';
    $latestPost['old_price'] = null;
    $latestPost['badge'] = 'New';
    $latestPost['all_images'] = shopPostImages($latestPost);
    $latestPost['cart_id'] = 'post-' . (int)$latestPost['id'];
    $latestPost['_source'] = 'post';
    $latestPost['_id'] = (int)$latestPost['id'];
    $carouselProducts[] = $latestPost;
}

foreach ($shopProducts as $shopProduct) {
    $shopProduct['_source'] = 'shop';
    $shopProduct['_id'] = (int)$shopProduct['id'];
    $shopProduct['cart_id'] = 'shop-' . (int)$shopProduct['id'];
    $carouselProducts[] = $shopProduct;
}

if ($source === 'post') {
    $source = 'post';
    if ($latestPost) {
        $product = $latestPost;
    }
} else {
    $source = 'shop';
    $product = shopGetProduct($conn, $currentId);
    if ($product) {
        $product['_source'] = 'shop';
        $product['_id'] = (int)$product['id'];
        $product['cart_id'] = 'shop-' . (int)$product['id'];
    }
}

if ($product) {
    foreach ($carouselProducts as $index => $item) {
        if ($item['_source'] === $source && (int)$item['_id'] === (int)$product['id']) {
            $currentIndex = $index;
            break;
        }
    }
}

$totalProducts = count($carouselProducts);
$previousIndex = $totalProducts > 0 ? (($currentIndex - 1 + $totalProducts) % $totalProducts) : 0;
$nextIndex = $totalProducts > 0 ? (($currentIndex + 1) % $totalProducts) : 0;

$images = $product ? ($product['all_images'] ?? shopImages($product)) : [];
$viewImages = [
    'front' => $product ? trim(str_replace('\\', '/', (string)($product['front_image'] ?? ''))) : '',
    'back' => $product ? trim(str_replace('\\', '/', (string)($product['back_image'] ?? ''))) : '',
    'right' => $product ? trim(str_replace('\\', '/', (string)($product['right_image'] ?? ''))) : '',
    'left' => $product ? trim(str_replace('\\', '/', (string)($product['left_image'] ?? ''))) : ''
];
if ($viewImages['front'] === '' && isset($images[0])) $viewImages['front'] = $images[0];
if ($viewImages['back'] === '' && isset($images[1])) $viewImages['back'] = $images[1];
if ($viewImages['right'] === '' && isset($images[2])) $viewImages['right'] = $images[2];
if ($viewImages['left'] === '' && isset($images[3])) $viewImages['left'] = $images[3];

if ($currentView !== '' && !empty($viewImages[$currentView])) {
    $found = array_search($viewImages[$currentView], $images, true);
    if ($found !== false) $currentImage = $found;
}
if ($currentImage >= count($images)) $currentImage = 0;
$imageToShow = $images[$currentImage] ?? ($viewImages['front'] ?: '');
$imageToShowUrl = shopImageUrl($imageToShow);

$viewLabel = 'Product Image';
foreach ($viewImages as $viewName => $viewImage) {
    if ($viewImage !== '' && $imageToShow === $viewImage) {
        $viewLabel = ucfirst($viewName) . ' View';
        break;
    }
}

if ($product && $source === 'shop') {
    $related = shopGetProducts($conn, (string)$product['category'], 'featured');
    $related = array_values(array_filter($related, function ($row) use ($product) {
        return (int)$row['id'] !== (int)$product['id'];
    }));
    $related = array_slice($related, 0, 4);
}

$pageName = $product ? (string)$product['name'] : 'Product Not Found';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= productSafe($pageName) ?> — Larry J Gadjets</title>
<meta name="description" content="View full product details at Larry J Gadjets.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="shop-cart.css">
<style>
#cartToast.show { display:block !important; opacity:1; }

#productGallery{background:var(--paper-alt);border:1px solid var(--line);border-radius:var(--radius);overflow:hidden}
.pd-media{position:relative;aspect-ratio:1/1;background:var(--paper);border-radius:var(--radius);overflow:hidden;border:1px solid var(--line);max-width:520px;margin:0 auto}
.pd-media img{width:100%;height:100%;object-fit:cover}
.pd-price{font-family:'Jost',sans-serif;font-weight:700;font-size:1.7rem;color:var(--ink)}
.pd-price .was{font-size:1rem;color:var(--muted);text-decoration:line-through;margin-left:.5rem;font-family:'Inter',sans-serif;font-weight:400}
.pd-specs{list-style:none;padding:0;margin:0}
.pd-specs li{display:flex;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid var(--line);font-size:.9rem;gap:20px}
.pd-specs li span:first-child{color:var(--muted)}
.pd-specs li:last-child{border-bottom:none}
.pd-viewer{max-width:520px;margin:0 auto}
.pd-view-buttons{display:flex;flex-wrap:wrap;justify-content:center;gap:.65rem;margin-top:1rem}
.pd-view-btn{display:inline-flex;align-items:center;justify-content:center;border:1px solid transparent;color:#fff!important;text-decoration:none;border-radius:999px;padding:.55rem 1.15rem;font-size:.85rem;font-weight:600;transition:.2s}
.pd-view-btn.front{background:#0d6efd;border-color:#0d6efd}
.pd-view-btn.back{background:#dc3545;border-color:#dc3545}
.pd-view-btn.right{background:#fd7e14;border-color:#fd7e14}
.pd-view-btn.left{background:#6f42c1;border-color:#6f42c1}
.pd-view-btn.front:hover,.pd-view-btn.front.active{background:#0b5ed7}
.pd-view-btn.back:hover,.pd-view-btn.back.active{background:#bb2d3b}
.pd-view-btn.right:hover,.pd-view-btn.right.active{background:#d96508}
.pd-view-btn.left:hover,.pd-view-btn.left.active{background:#59359c}
.pd-view-label{text-align:center;font-family:'Jost',sans-serif;font-weight:600;margin-top:.75rem;color:var(--muted);font-size:.85rem;text-transform:uppercase;letter-spacing:.06em}
.pd-thumbs{display:flex;gap:.55rem;overflow-x:auto;justify-content:center;margin-top:1rem;padding:.2rem;scrollbar-width:thin}
.pd-thumb{width:66px;height:66px;flex:0 0 66px;border:2px solid transparent;border-radius:10px;background:#fff;padding:0;overflow:hidden;display:block}
.pd-thumb img{width:100%;height:100%;object-fit:cover;border-radius:8px}
.pd-thumb{cursor:pointer}.pd-view-btn,.gallery-change{cursor:pointer}.pd-media{touch-action:pan-y}.image-side-arrow{border:0}
.pd-thumb.active{border-color:#198754}
.gallery-count{text-align:center;color:var(--muted);font-size:.8rem;margin-top:.65rem}
.gallery-arrow{border:0;background:#198754;color:#fff;width:42px;height:42px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;text-decoration:none;transition:.2s}
.gallery-arrow:hover{background:#146c43;color:#fff}
.gallery-arrows{display:flex;justify-content:center;gap:.7rem;margin-top:1rem} .image-side-arrow{position:absolute;top:50%;transform:translateY(-50%);width:46px;height:46px;border-radius:50%;background:#198754;color:#fff;display:flex;align-items:center;justify-content:center;text-decoration:none;z-index:5;box-shadow:0 3px 10px rgba(0,0,0,.18)}
.image-side-arrow:hover{background:#146c43;color:#fff}
.image-side-arrow-left{left:12px}.image-side-arrow-right{right:12px}
.product-carousel-controls{display:flex;justify-content:space-between;gap:1rem;margin-bottom:1rem}
.product-carousel-controls a{border-radius:999px;background:#198754;border-color:#198754;color:#fff}.product-carousel-controls a:hover{background:#146c43;border-color:#146c43;color:#fff}
.related-strip .product-card{height:100%}
</style>
</head>
<body data-user-id="<?= isset($_SESSION['id']) ? (int)$_SESSION['id'] : 0 ?>" data-authenticated="<?= isset($_SESSION['id']) ? '1' : '0' ?>">
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>
" data-authenticated="<?= isset($_SESSION['id']) ? '1' : '0' ?>">
<header class="site-header">
  <nav class="navbar navbar-expand-lg py-3">
    <div class="container">
      <a class="brand-mark d-flex align-items-center" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>
      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"><i class="bi bi-list fs-2"></i></button>
      <div class="collapse navbar-collapse" id="navMain">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom active" href="shop.php">Shop</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#company-services">Services</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#latest-blog">Blog</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="about.php#contact">Contact</a></li>
        </ul>
      </div>
      <div class="d-flex align-items-center gap-1">
        <a href="<?php echo $isLoggedIn ? (strtolower((string)($_SESSION['role'] ?? 'customer')) === 'admin' ? 'dashboard%201/index.php' : 'dashboard/index.php') : 'dashboard/login.php'; ?>" class="icon-btn d-none d-sm-inline-flex"><i class="bi bi-person fs-5"></i></a>
        <a href="cart.php" class="icon-btn"><i class="bi bi-bag fs-5"></i><span class="cart-count">0</span></a>
      </div>
    </div>
  </nav>
</header>

<section class="page-banner">
  <div class="container">
    <div class="eyebrow mb-2">Product Details</div>
    <h1 id="productPageTitle" class="display-6 mb-2"><?= productSafe($pageName) ?></h1>
    <div class="breadcrumb-custom small"><a href="index.php">Home</a><span class="sep">/</span><a href="shop.php">Shop</a><span class="sep">/</span><span id="productBreadcrumbName"><?= productSafe($pageName) ?></span></div>
  </div>
</section>

<?php if (!$product): ?>
<section class="py-5"><div class="container"><div class="alert alert-warning">This product could not be found.</div><a href="shop.php" class="btn btn-dark">Back to Shop</a></div></section>
<?php else: ?>
<section id="productMain" class="py-5">
  <div class="container">
    <div class="product-carousel-controls">
      <?php $prev = $carouselProducts[$previousIndex] ?? null; $next = $carouselProducts[$nextIndex] ?? null; ?>
      <?php if ($prev): ?>
        <a class="btn btn-outline-dark product-nav" href="product.php?source=<?= productSafe($prev['_source']) ?>&id=<?= (int)$prev['_id'] ?>"><i class="bi bi-chevron-left me-1"></i> Previous Product</a>
      <?php else: ?><span></span><?php endif; ?>
      <span class="small text-muted align-self-center">Product <?= $currentIndex + 1 ?> of <?= max(1, $totalProducts) ?></span>
      <?php if ($next): ?>
        <a class="btn btn-outline-dark product-nav" href="product.php?source=<?= productSafe($next['_source']) ?>&id=<?= (int)$next['_id'] ?>">Next Product <i class="bi bi-chevron-right ms-1"></i></a>
      <?php endif; ?>
    </div>

    <div id="productGallery">
      <div class="p-3 p-md-4">
        <div class="row g-4 align-items-center">
          <div class="col-lg-6">
            <div class="pd-viewer">
              <div class="pd-media">
                <?php if ($imageToShow !== ''): ?>
                  <img src="<?= productSafe($imageToShowUrl) ?>" alt="<?= productSafe($product['name']) ?>" loading="eager">
                <?php else: ?>
                  <div class="w-100 h-100 d-flex align-items-center justify-content-center text-muted">No image available</div>
                <?php endif; ?>
                <?php if (count($images) > 1): ?>
                  <button type="button" class="image-side-arrow image-side-arrow-left gallery-change" data-image="<?= (($currentImage - 1 + count($images)) % count($images)) ?>" aria-label="Previous picture"><i class="bi bi-chevron-left"></i></button>
                  <button type="button" class="image-side-arrow image-side-arrow-right gallery-change" data-image="<?= (($currentImage + 1) % count($images)) ?>" aria-label="Next picture"><i class="bi bi-chevron-right"></i></button>
                <?php endif; ?>
              </div>
              <div class="pd-view-label"><?= productSafe($viewLabel) ?></div>
              <div class="pd-view-buttons" role="group" aria-label="Product views">
                <?php foreach (['front' => 'Front View', 'back' => 'Back View', 'right' => 'Right View', 'left' => 'Left View'] as $viewName => $viewText): ?>
                  <?php if (!empty($viewImages[$viewName])): ?>
                    <?php $viewIndex = array_search($viewImages[$viewName], $images, true); ?>
                    <button type="button" class="pd-view-btn <?= $viewName ?> <?= $viewLabel === $viewText ? 'active' : '' ?> gallery-change" data-image="<?= $viewIndex === false ? 0 : $viewIndex ?>" data-view="<?= $viewName ?>" aria-label="<?= $viewText ?>"><?= $viewText ?></button>
                  <?php endif; ?>
                <?php endforeach; ?>
              </div>

              <?php if (count($images) > 1): ?>
              <div class="gallery-count">Image <?= $currentImage + 1 ?> of <?= count($images) ?></div>
              <?php endif; ?>

              <?php if ($images): ?>
              <div class="pd-thumbs">
                <?php foreach ($images as $index => $image): ?>
                  <button type="button" class="pd-thumb <?= $index === $currentImage ? 'active' : '' ?> gallery-change" data-image="<?= $index ?>" aria-label="Show product image <?= $index + 1 ?>">
                    <img src="<?= productSafe(shopImageUrl($image)) ?>" alt="">
                  </button>
                <?php endforeach; ?>
              </div>
              <div class="gallery-count">Image <?= $currentImage + 1 ?> of <?= count($images) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="col-lg-6">
            <?php if (!empty($product['badge'])): ?><span class="badge bg-dark mb-2"><?= productSafe($product['badge']) ?></span><?php endif; ?>
            <div class="product-cat mb-2"><?= productSafe($product['category']) ?></div>
            <h2 class="mb-2"><?= productSafe($product['name']) ?></h2>
            <div class="pd-price mb-3">₦<?= number_format((float)$product['price'], 2) ?><?php if ($product['old_price'] !== null && $product['old_price'] !== ''): ?><span class="was">₦<?= number_format((float)$product['old_price'], 2) ?></span><?php endif; ?></div>
            <p class="text-muted mb-4"><?= nl2br(productSafe($product['description'])) ?></p>
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="qty-stepper"><span class="px-3 py-2 border rounded">1</span></div>
              <button type="button" class="btn btn-ink add-cart flex-grow-1" data-id="<?= productSafe($product['cart_id']) ?>" data-name="<?= productSafe($product['name']) ?>" data-price="<?= (float)$product['price'] ?>" data-image="<?= productSafe(shopImageUrl($viewImages['front'] ?: $imageToShow)) ?>" data-category="<?= productSafe($product['category']) ?>"><i class="bi bi-bag-plus me-1"></i> Add to Cart</button>
            </div>
            <ul class="pd-specs">
              <li><span>SKU</span><span>MS-<?= strtoupper(productSafe((string)$product['id'])) ?></span></li>
              <li><span>Category</span><span><?= productSafe($product['category']) ?></span></li>
              <li><span>Images</span><span><?= count($images) ?></span></li>
              <li><span>Availability</span><span>In stock</span></li>
            </ul>
            <div class="mt-3"><a href="shop.php" class="btn btn-outline-ink btn-sm">Back to Shop</a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="relatedProducts" class="py-5 bg-white border-top">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4"><h2 class="h4 mb-0">You may also like</h2><a href="shop.php" class="btn btn-outline-ink btn-sm">View All Products</a></div>
    <div class="row g-4 related-strip">
      <?php foreach ($related as $row): ?>
        <?php $relatedImages = $row['all_images'] ?? shopImages($row); $relatedImage = shopImageUrl($relatedImages[0] ?? ''); ?>
        <div class="col-6 col-md-3">
          <a href="product.php?source=shop&id=<?= (int)$row['id'] ?>" class="text-decoration-none product-nav">
            <div class="product-card">
              <div class="product-media">
                <?php if ($row['badge']): ?><span class="product-badge <?= $row['badge'] === 'Sale' ? 'sale' : '' ?>"><?= productSafe($row['badge']) ?></span><?php endif; ?>
                <img src="<?= productSafe($relatedImage) ?>" alt="<?= productSafe($row['name']) ?>" loading="lazy">
              </div>
              <div class="product-body"><div class="product-cat"><?= productSafe($row['category']) ?></div><h3 class="product-name"><?= productSafe($row['name']) ?></h3><span class="product-price">₦<?= number_format((float)$row['price'], 2) ?></span></div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
      <?php if (!$related): ?><p class="text-muted">No other products in this category yet.</p><?php endif; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<div class="position-fixed bottom-0 end-0 p-3" style="z-index:1100;"><div id="cartToast" class="toast align-items-center text-white bg-dark border-0" role="alert"><div class="d-flex"><div class="toast-body"><i class="bi bi-check-circle me-2 text-accent"></i><span id="toastMsg">Added to cart</span></div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>

<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4"><a class="brand-mark text-white d-inline-block mb-3" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a><p class="small">Everyday tech, chosen carefully. Phones, wearables, audio and accessories — delivered fast, backed by a real warranty.</p></div>
      <div class="col-lg-2 col-6"><h6>Shop</h6><ul class="list-unstyled small"><li class="mb-2"><a href="shop.php">All Products</a></li><li class="mb-2"><a href="cart.php">Cart</a></li></ul></div>
      <div class="col-lg-2 col-6"><h6>Company</h6><ul class="list-unstyled small"><li class="mb-2"><a href="about.php">About Us</a></li><li class="mb-2"><a href="blog.php">Blog</a></li><li class="mb-2"><a href="about.php#contact">Contact</a></li></ul></div>
      <div class="col-lg-4"><h6>Contact</h6><p class="small mb-1">Questions? <a href="mailto:hello@Larry J Gadjets.example">ugwuanyinelson46@gmail.com</a></p><p class="small">Support line: <a href="tel:+15551234567">+2349043855373</a></p></div>
    </div>
    <div class="fine-print d-flex flex-wrap justify-content-between"><span>© 2026 Larry J Gadjets. All rights reserved.</span><span>Secure checkout · Visa · Mastercard · PayPal</span></div>
  </div>
</footer>

<script src="bootstrap.min.js"></script>
<script>
(function () {
    function galleryShow(index, view) {
        const gallery = document.getElementById('productGallery');
        if (!gallery) return;

        const thumbs = Array.from(gallery.querySelectorAll('.pd-thumb'));
        const image = gallery.querySelector('.pd-media img');
        if (!thumbs.length || !image) return;

        const total = thumbs.length;
        index = (index + total) % total;

        const thumb = thumbs[index];
        const thumbImage = thumb.querySelector('img');
        if (!thumbImage) return;

        image.src = thumbImage.src;
        thumbs.forEach(function (item, number) {
            item.classList.toggle('active', number === index);
        });

        gallery.querySelectorAll('.gallery-count').forEach(function (item) {
            item.textContent = 'Image ' + (index + 1) + ' of ' + total;
        });

        gallery.querySelectorAll('.pd-view-btn').forEach(function (item) {
            item.classList.toggle('active', Number(item.dataset.image) === index);
        });

        const label = gallery.querySelector('.pd-view-label');
        if (label) {
            label.textContent = view
                ? view.charAt(0).toUpperCase() + view.slice(1) + ' View'
                : 'Product Image';
        }

        const previous = gallery.querySelector('.image-side-arrow-left');
        const next = gallery.querySelector('.image-side-arrow-right');

        if (previous) previous.dataset.image = (index - 1 + total) % total;
        if (next) next.dataset.image = (index + 1) % total;
    }

    document.addEventListener('click', function (event) {
        const imageButton = event.target.closest('.gallery-change');

        if (imageButton) {
            event.preventDefault();
            galleryShow(
                Number(imageButton.dataset.image || 0),
                imageButton.dataset.view || ''
            );
            return;
        }

        const productLink = event.target.closest('.product-nav');

        if (!productLink) return;

        event.preventDefault();
        loadProduct(productLink.href, true);
    });

    let startX = 0;
    let startY = 0;

    document.addEventListener('touchstart', function (event) {
        const media = event.target.closest('.pd-media');
        if (!media || !event.touches.length) return;

        startX = event.touches[0].clientX;
        startY = event.touches[0].clientY;
    }, { passive: true });

    document.addEventListener('touchend', function (event) {
        const media = event.target.closest('.pd-media');
        if (!media || !event.changedTouches.length) return;

        const dx = event.changedTouches[0].clientX - startX;
        const dy = event.changedTouches[0].clientY - startY;

        if (Math.abs(dx) < 45 || Math.abs(dx) < Math.abs(dy)) return;

        const gallery = media.closest('#productGallery');
        const thumbs = gallery ? gallery.querySelectorAll('.pd-thumb') : [];
        const active = gallery ? gallery.querySelector('.pd-thumb.active') : null;

        if (!thumbs.length || !active) return;

        const current = Number(active.dataset.image || 0);
        galleryShow(current + (dx < 0 ? 1 : -1), '');
    }, { passive: true });

    /* Change products without reloading the whole page. */
    let productIsLoading = false;

    function loadProduct(url, changeHistory) {
        // Stop a second click from starting another request.
        if (productIsLoading) return;
        productIsLoading = true;

        // Remember where the user is.
        // We will stay in the same place after the product changes.
        const oldScrollY = window.scrollY;

        fetch(url, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(function (response) {
            if (!response.ok) {
                throw new Error('Product could not be loaded.');
            }
            return response.text();
        })
        .then(function (html) {
            // Read the new product page without leaving this page.
            const page = new DOMParser().parseFromString(html, 'text/html');
            const newMain = page.getElementById('productMain');
            const main = document.getElementById('productMain');

            if (!newMain || !main) {
                throw new Error('Product could not be loaded.');
            }

            // Put only the new product content inside the current page.
            main.innerHTML = newMain.innerHTML;

            // Also change the small product list below it.
            const related = document.getElementById('relatedProducts');
            const newRelated = page.getElementById('relatedProducts');
            if (related && newRelated) {
                related.replaceWith(newRelated);
            }

            // Change the title at the top of the page.
            const title = page.getElementById('productPageTitle');
            const breadcrumb = page.getElementById('productBreadcrumbName');

            if (title) {
                document.getElementById('productPageTitle').textContent = title.textContent;
            }

            if (breadcrumb) {
                document.getElementById('productBreadcrumbName').textContent = breadcrumb.textContent;
            }

            // Change the browser tab title too.
            document.title = page.title;

            // Change the address bar, but do NOT reload the page.
            if (changeHistory) {
                history.pushState({}, '', url);
            }

            // Stay exactly where the user was.
            // This makes changing products feel like changing an image.
            window.scrollTo(0, oldScrollY);
        })
        .catch(function (error) {
            console.error(error);
        })
        .finally(function () {
            // Allow the next product button to work again.
            productIsLoading = false;
        });
    }

    window.addEventListener('popstate', function () {
        loadProduct(window.location.href, false);
    });
})();
</script>
<script src="cart.js"></script>


<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

<?php
/**
 * Larry J Gadjets database connection.
 *
 * Change these four values when you upload the site to your host.
 * You can also set DB_HOST, DB_USER, DB_PASS and DB_NAME as
 * environment variables on your server.
 */
$dbHost = getenv('DB_HOST') ?: 'localhost';
$dbUser = getenv('DB_USER') ?: 'root';
$dbPass = getenv('DB_PASS') ?: '';
$dbName = getenv('DB_NAME') ?: 'ecommerce';

if (!extension_loaded('mysqli')) {
    die('Database error: PHP mysqli is not enabled. Enable mysqli in your hosting PHP settings.');
}

mysqli_report(MYSQLI_REPORT_OFF);
$conn = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);

if (!$conn) {
    error_log('Larry J Gadjets database connection failed: ' . mysqli_connect_error());
    die('Database connection failed. Check DB_HOST, DB_USER, DB_PASS and DB_NAME in conn.php.');
}

mysqli_set_charset($conn, 'utf8mb4');
?>

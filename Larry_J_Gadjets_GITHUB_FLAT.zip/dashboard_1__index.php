<?php
require_once 'header.php';
require_once 'auth.php';
requireAdmin();

/* Admin can approve a pending order. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve'])) {
    $orderId = (int)($_POST['order_id'] ?? 0);

    if ($orderId > 0) {
        $stmt = mysqli_prepare($conn, "UPDATE orders SET status = 'approved' WHERE id = ?");

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $orderId);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }
}

$username = (string) ($_SESSION['username'] ?? 'Admin');
$image = getProfileImage();
$imageFile = profileImageFile($image);
$imageUrl = profileImageUrl($image);

$result = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM client');
$row = $result ? mysqli_fetch_assoc($result) : null;
$totalClients = (int)($row['total'] ?? 0);

$result = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM orders');
$row = $result ? mysqli_fetch_assoc($result) : null;
$totalOrders = (int)($row['total'] ?? 0);

$result = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM post');
$row = $result ? mysqli_fetch_assoc($result) : null;
$totalPosts = (int)($row['total'] ?? 0);

$orders = mysqli_query($conn, 'SELECT * FROM orders ORDER BY id DESC LIMIT 10');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - Larry J Gadjets</title>
<link href="../bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body{margin:0;background:#f4f7fb;color:#172033;overflow-x:hidden}.content{width:100%;min-width:0}.hero{background:linear-gradient(135deg,#0d6efd,#174ea6);color:#fff;border-radius:20px}.stat{border:0;border-radius:18px}.table th{background:#f8fafc;color:#687385;font-size:12px;text-transform:uppercase}.table td,.table th{padding:14px;vertical-align:middle}.items{min-width:220px;white-space:pre-line}.total{font-weight:800;color:#0d6efd;white-space:nowrap}.pending{color:#856404;background:#fff3cd}.approved{color:#146c43;background:#d1e7dd}.status{display:inline-flex;align-items:center;gap:5px;border-radius:20px;padding:6px 10px;font-size:12px;font-weight:700;white-space:nowrap}
.top-profile{width:44px;height:44px;border-radius:50%;object-fit:cover}.profile-fallback{background:#0d6efd;color:#fff;align-items:center;justify-content:center;font-weight:700}.mobile-menu{display:none}
@media(max-width:768px){.mobile-menu{display:inline-flex;align-items:center;justify-content:center}.content{min-width:0}.table-responsive{max-width:100%;overflow-x:auto}.hero{border-radius:14px}.card-body{padding:16px!important}}
</style>
</head>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

<div class="d-flex">
<?php require_once 'sidebar.php'; ?>
<div class="content flex-grow-1">
<nav class="navbar bg-white shadow-sm px-3 px-md-4 py-3 d-flex align-items-center gap-3">
<button type="button" class="mobile-menu btn btn-primary btn-sm" onclick="toggleSidebar()" aria-label="Open menu"><i class="bi bi-list"></i></button>
<h4 class="mb-0">Admin Dashboard</h4>
<div class="ms-auto">
<?php if ($image !== '' && is_file($imageFile)): ?>
<img src="<?php echo htmlspecialchars($imageUrl, ENT_QUOTES, 'UTF-8'); ?>" class="top-profile" alt="Profile" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
<div class="top-profile profile-fallback" style="display:none"><?php echo strtoupper(substr($username,0,1)); ?></div>
<?php else: ?>
<div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold" style="width:44px;height:44px"><?php echo strtoupper(substr($username,0,1)); ?></div>
<?php endif; ?>
</div>
</nav>
<main class="container-fluid py-4">
<div class="hero p-4 mb-4"><h2 class="fw-bold mb-1">Welcome, <?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></h2><div>You are the admin of Larry J Gadjets.</div></div>

<div class="row g-4 mb-4">
<div class="col-md-4"><div class="card stat shadow-sm"><div class="card-body p-4"><div class="text-muted">CUSTOMERS</div><div class="display-6 fw-bold"><?php echo $totalClients; ?></div></div></div></div>
<div class="col-md-4"><div class="card stat shadow-sm"><div class="card-body p-4"><div class="text-muted">ORDERS</div><div class="display-6 fw-bold"><?php echo $totalOrders; ?></div></div></div></div>
<div class="col-md-4"><div class="card stat shadow-sm"><div class="card-body p-4"><div class="text-muted">POSTS</div><div class="display-6 fw-bold"><?php echo $totalPosts; ?></div></div></div></div>
</div>

<div class="card shadow-sm border-0 rounded-4">
<div class="card-body p-4">
<div class="d-flex justify-content-between align-items-center mb-3">
<div><h5 class="fw-bold mb-1">Latest Orders</h5><div class="text-muted small">Every order shows the products, prices, total and status.</div></div>
<a href="order.php" class="btn btn-primary btn-sm">All Orders</a>
</div>

<div class="table-responsive">
<table class="table mb-0">
<thead><tr><th>Order</th><th>Customer</th><th>Email</th><th>Items Bought</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
<tbody>
<?php if ($orders): ?>
    <?php while ($row = mysqli_fetch_assoc($orders)): ?>
        <?php $status = strtolower((string)($row['status'] ?? 'pending')); ?>
        <tr>
            <td>#<?php echo (int)($row['id'] ?? 0); ?></td>
            <td><?php echo htmlspecialchars((string)($row['name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars((string)($row['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
            <td class="items"><?php echo nl2br(htmlspecialchars((string)($row['order_items'] ?? 'No items saved'), ENT_QUOTES, 'UTF-8')); ?></td>
            <td class="total">₦<?php echo number_format((float)($row['total'] ?? 0), 2); ?></td>
            <td>
                <?php if ($status === 'pending'): ?>
                    <span class="status pending"><i class="bi bi-hourglass-split"></i> Pending</span>
                <?php else: ?>
                    <span class="status approved"><i class="bi bi-check-circle"></i> Approved</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($status === 'pending'): ?>
                    <form method="post" class="d-inline">
                        <input type="hidden" name="order_id" value="<?php echo (int)$row['id']; ?>">
                        <button type="submit" name="approve" class="btn btn-sm btn-success">
                            <i class="bi bi-check-lg"></i> Approve
                        </button>
                    </form>
                <?php else: ?>
                    <span class="text-muted small">Done</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr><td colspan="7" class="text-center py-5 text-muted">No orders found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>
</main>
</div>
</div>
<script>function toggleSidebar(){const s=document.querySelector('.sidebar');if(s)s.classList.toggle('show');}</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

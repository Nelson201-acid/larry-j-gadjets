<?php

header("Content-Type: application/json");


/*
 * DATABASE
 */

require_once __DIR__ . "/dashboard/conn.php";

if (!isset($conn) || !$conn) {
    echo json_encode([
        "status" => false,
        "message" => "Database connection failed."
    ]);
    exit;
}


/*
 * YOUR PAYSTACK SECRET KEY
 *
 * Replace this with your TEST secret key.
 *
 * DO NOT put the secret key in checkout.php.
 */

$secretKey =
    "sk_test_2ffc0ef831ca6fe08861cf9fdbb543bfb04388ec";


/*
 * GET DATA
 */

$reference =
    $_POST["reference"] ?? "";

$name =
    trim($_POST["name"] ?? "");

$email =
    trim($_POST["email"] ?? "");

$city =
    trim($_POST["city"] ?? "");

$state =
    trim($_POST["state"] ?? "");

$zipcode =
    trim($_POST["zipcode"] ?? "");


/*
 * CHECK REFERENCE
 */

if ($reference === "") {

    echo json_encode([
        "status" => false,
        "message" => "Payment reference is missing."
    ]);

    exit;
}


/*
 * ASK PAYSTACK TO VERIFY
 */

$url =
    "https://api.paystack.co/transaction/verify/" .
    urlencode($reference);


if (!function_exists('curl_init')) {
    echo json_encode([
        "status" => false,
        "message" => "PHP cURL is not enabled on this server."
    ]);
    exit;
}

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt(
    $ch,
    CURLOPT_HTTPHEADER,
    [
        "Authorization: Bearer " . $secretKey,
        "Content-Type: application/json"
    ]
);


$response =
    curl_exec($ch);


if ($response === false) {

    echo json_encode([
        "status" => false,
        "message" => "Could not connect to Paystack."
    ]);

    curl_close($ch);

    exit;
}


curl_close($ch);


/*
 * CONVERT PAYSTACK RESPONSE
 */

$result =
    json_decode(
        $response,
        true
    );


/*
 * CHECK PAYSTACK STATUS
 */

if (
    empty($result["status"]) ||
    empty($result["data"])
) {

    echo json_encode([
        "status" => false,
        "message" => "Payment verification failed."
    ]);

    exit;
}


$payment =
    $result["data"];


/*
 * PAYMENT MUST BE SUCCESSFUL
 */

if (
    ($payment["status"] ?? "") !==
    "success"
) {

    echo json_encode([
        "status" => false,
        "message" => "Payment was not successful."
    ]);

    exit;
}


/*
 * CHECK AMOUNT
 */

$amountPaid =
    (int)($payment["amount"] ?? 0);


$customerEmail =
    $payment["customer"]["email"] ?? "";


/*
 * Make sure Paystack returned
 * the same customer email.
 */

if (
    strtolower($customerEmail) !==
    strtolower($email)
) {

    echo json_encode([
        "status" => false,
        "message" => "Customer email does not match."
    ]);

    exit;
}


/*
 * SAVE ORDER
 *
 * These are the columns that actually exist
 * in your orders table.
 */

$sql =
    "INSERT INTO orders
    (name, email, city, state, zipcode)
    VALUES (?, ?, ?, ?, ?)";


$stmt =
    mysqli_prepare(
        $conn,
        $sql
    );


if (!$stmt) {

    echo json_encode([
        "status" => false,
        "message" => "Could not prepare order."
    ]);

    exit;
}


mysqli_stmt_bind_param(
    $stmt,
    "sssss",
    $name,
    $email,
    $city,
    $state,
    $zipcode
);


if (
    mysqli_stmt_execute($stmt)
) {

    echo json_encode([
        "status" => true,
        "message" => "Payment verified and order saved.",
        "reference" => $reference
    ]);

} else {

    echo json_encode([
        "status" => false,
        "message" => "Could not save the order."
    ]);
}


mysqli_stmt_close($stmt);

mysqli_close($conn);

?>wcd
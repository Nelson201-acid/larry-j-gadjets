const SHIPPING_FLAT = 6.99;
const FREE_SHIPPING_THRESHOLD = 75;
const TAX_RATE = 0.075;

function userId() {
    return document.body ? document.body.getAttribute('data-user-id') || '0' : '0';
}

function cartKey() {
    const id = userId();
    return id !== '0' && id !== '' ? 'cart_user_' + id : 'cart_guest';
}

function isLoggedIn() {
    const id = userId();
    return id !== '0' && id !== '';
}

// Remember which account was last logged in.
// We use this only to notice when the user has logged out.
const LAST_USER_KEY = 'cart_last_logged_in_user';

function handleLoginState() {
    const id = userId();

    if (isLoggedIn()) {
        // Keep the account's saved cart.
        localStorage.setItem(LAST_USER_KEY, id);
        return;
    }

    // The user is logged out.
    // Remove any old guest cart so the cart starts EMPTY after logout.
    if (localStorage.getItem(LAST_USER_KEY)) {
        sessionStorage.removeItem('cart_guest');
        localStorage.removeItem(LAST_USER_KEY);
    }
}

// Logged-in users keep their cart. Guests get a temporary cart.
function cartStorage() {
    return isLoggedIn() ? localStorage : sessionStorage;
}

function getCart() {
    const key = cartKey();

    try {
        return JSON.parse(cartStorage().getItem(key)) || [];
    } catch (error) {
        return [];
    }
}

function saveCart(cart) {
    const key = cartKey();

    try {
        cartStorage().setItem(key, JSON.stringify(cart));

        // Remove old guest data from the previous version of the cart.
        if (!isLoggedIn()) {
            localStorage.removeItem('cart_guest');
        }

        localStorage.removeItem('cart');
        updateCartCount();
        return true;
    } catch (error) {
        return false;
    }
}

function getCartCount() {
    return getCart().reduce(function (total, item) {
        return total + Number(item.quantity || 0);
    }, 0);
}

function getCartSubtotal() {
    return getCart().reduce(function (total, item) {
        return total + Number(item.price || 0) * Number(item.quantity || 0);
    }, 0);
}

function getShippingCost(subtotal) {
    if (!subtotal) return 0;
    return subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FLAT;
}

function getTax(subtotal) {
    return subtotal * TAX_RATE;
}

function getCartTotal() {
    const subtotal = getCartSubtotal();
    return subtotal + getShippingCost(subtotal) + getTax(subtotal);
}

function formatCurrency(amount) {
    return '₦' + Number(amount || 0).toLocaleString('en-NG', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function updateCartCount() {
    const total = getCartCount();

    document.querySelectorAll('.cart-count, #cart-count').forEach(function (item) {
        item.textContent = total;
    });
}

function showCartMessage(message) {
    let toast = document.getElementById('cartToast');
    let text = document.getElementById('toastMsg');

    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'cartToast';
        toast.style.cssText = 'position:fixed;right:20px;bottom:20px;z-index:9999;background:#222;color:#fff;padding:14px 18px;border-radius:8px;box-shadow:0 4px 15px rgba(0,0,0,.2)';
        document.body.appendChild(toast);
    }

    if (!text) {
        text = document.createElement('span');
        text.id = 'toastMsg';
        toast.appendChild(text);
    }

    text.textContent = message;
    toast.style.display = 'block';
    toast.classList.add('show');

    clearTimeout(window.cartMessageTimer);
    window.cartMessageTimer = setTimeout(function () {
        toast.classList.remove('show');
        toast.style.display = 'none';
    }, 2200);
}

function addToCart(button) {
    const name = button.getAttribute('data-name') || 'Product';
    const id = button.getAttribute('data-id');
    const price = Number(button.getAttribute('data-price') || 0);
    const image = button.getAttribute('data-image') || '';
    const category = button.getAttribute('data-category') || '';
    const cart = getCart();
    const oldItem = cart.find(function (item) {
        return String(item.id) === String(id);
    });

    if (oldItem) {
        oldItem.quantity = Number(oldItem.quantity || 1) + 1;
    } else {
        cart.push({
            id: id,
            name: name,
            price: price,
            image: image,
            category: category,
            quantity: 1
        });
    }

    if (!saveCart(cart)) return false;

    updateCartCount();
    showCartMessage(name + ' has been added to cart.');
    return true;
}

function updateCartQuantity(id, quantity) {
    const cart = getCart();
    const item = cart.find(function (row) {
        return String(row.id) === String(id);
    });

    if (!item) return cart;

    item.quantity = Math.max(1, Math.min(99, Number(quantity) || 1));
    saveCart(cart);
    return cart;
}

function updateQty(id, quantity) {
    return updateCartQuantity(id, quantity);
}

function removeFromCart(id) {
    const cart = getCart().filter(function (item) {
        return String(item.id) !== String(id);
    });

    saveCart(cart);
    return cart;
}

function clearCart() {
    const key = cartKey();

    if (!key) return;

    cartStorage().removeItem(key);
    updateCartCount();
}

function renderCart() {
    const cartLoaded = document.getElementById('cartLoaded');
    const cartEmpty = document.getElementById('cartEmpty');
    const cartLines = document.getElementById('cartLines');

    if (!cartLoaded || !cartEmpty || !cartLines) return;

    if (!getCart().length) {
        cartLoaded.classList.add('d-none');
        cartEmpty.classList.remove('d-none');
        return;
    }

    cartLoaded.classList.remove('d-none');
    cartEmpty.classList.add('d-none');

    const cart = getCart();
    const itemCount = document.getElementById('itemCount');

    if (itemCount) {
        itemCount.textContent = cart.reduce(function (total, item) {
            return total + Number(item.quantity || 0);
        }, 0);
    }

    cartLines.innerHTML = cart.map(function (item) {
        const price = Number(item.price) || 0;
        const quantity = Number(item.quantity) || 1;
        const image = item.image || '';
        const lineTotal = price * quantity;

        return '<div class="py-4 border-bottom">' +
            '<div class="row align-items-center g-3">' +
            '<div class="col-3 col-sm-2">' +
            (image ? '<img src="' + image + '" alt="' + item.name + '" class="img-fluid rounded">' : '') +
            '</div>' +
            '<div class="col-9 col-sm-5"><h3 class="h6 mb-1">' + item.name + '</h3>' +
            '<div class="small text-muted">' + formatCurrency(price) + ' each</div></div>' +
            '<div class="col-6 col-sm-2"><input type="number" min="1" value="' + quantity + '" class="form-control cart-quantity" data-id="' + item.id + '"></div>' +
            '<div class="col-6 col-sm-2 text-end"><div class="fw-semibold">' + formatCurrency(lineTotal) + '</div>' +
            '<button class="btn btn-link text-danger p-0 remove-cart" data-id="' + item.id + '">Remove</button></div>' +
            '</div></div>';
    }).join('');

    const subtotal = getCartSubtotal();
    const shipping = getShippingCost(subtotal);
    const tax = getTax(subtotal);
    const total = subtotal + shipping + tax;

    const sumSubtotal = document.getElementById('sumSubtotal');
    const sumShipping = document.getElementById('sumShipping');
    const sumTax = document.getElementById('sumTax');
    const sumTotal = document.getElementById('sumTotal');
    const freeShipMsg = document.getElementById('freeShipMsg');

    if (sumSubtotal) sumSubtotal.textContent = formatCurrency(subtotal);
    if (sumShipping) sumShipping.textContent = shipping ? formatCurrency(shipping) : 'Free';
    if (sumTax) sumTax.textContent = formatCurrency(tax);
    if (sumTotal) sumTotal.textContent = formatCurrency(total);

    if (freeShipMsg) {
        freeShipMsg.textContent = shipping > 0
            ? 'Free shipping on orders of ' + formatCurrency(FREE_SHIPPING_THRESHOLD) + ' or more.'
            : 'You have free shipping.';
    }
}


document.addEventListener('click', function (event) {
    const button = event.target.closest('.add-cart, .add-cart-btn');
    const removeButton = event.target.closest('.remove-cart');

    if (button) {
        event.preventDefault();
        addToCart(button);
        return;
    }

    if (removeButton) {
        removeFromCart(removeButton.getAttribute('data-id'));
        renderCart();
    }
});

document.addEventListener('change', function (event) {
    if (!event.target.classList.contains('cart-quantity')) return;

    updateCartQuantity(
        event.target.getAttribute('data-id'),
        event.target.value
    );

    renderCart();
});

document.addEventListener('DOMContentLoaded', function () {
    handleLoginState();
    updateCartCount();
    renderCart();

    const clearButton = document.getElementById('clearCartBtn');

    if (clearButton) {
        clearButton.addEventListener('click', function () {
            clearCart();
            renderCart();
        });
    }
});

window.addToCart = addToCart;
window.getCart = getCart;
window.saveCart = saveCart;
window.updateCartQuantity = updateCartQuantity;
window.updateQty = updateQty;
window.removeFromCart = removeFromCart;
window.clearCart = clearCart;
window.getCartCount = getCartCount;
window.getCartSubtotal = getCartSubtotal;
window.getShippingCost = getShippingCost;
window.getTax = getTax;
window.getCartTotal = getCartTotal;
window.formatCurrency = formatCurrency;
window.updateCartCount = updateCartCount;
window.showCartMessage = showCartMessage;
window.renderCart = renderCart;
window.FREE_SHIPPING_THRESHOLD = FREE_SHIPPING_THRESHOLD;

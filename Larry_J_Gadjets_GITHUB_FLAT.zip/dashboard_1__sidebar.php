<?php
require_once 'auth.php';

$name = htmlspecialchars((string) ($_SESSION['username'] ?? 'User'), ENT_QUOTES, 'UTF-8');
$image = getProfileImage();
$imageFile = profileImageFile($image);
$imageUrl = profileImageUrl($image);
?>

<div class="sidebar bg-dark text-white p-3">
    <div class="sidebar-top text-center mb-4">
        <?php if ($image !== '' && is_file($imageFile)): ?>
            <img src="<?php echo htmlspecialchars($imageUrl, ENT_QUOTES, 'UTF-8'); ?>" class="sidebar-picture mb-2" alt="Profile picture" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
            <div class="sidebar-picture sidebar-letter mb-2" style="display:none"><?php echo strtoupper(substr($name, 0, 1)); ?></div>
        <?php else: ?>
            <div class="sidebar-picture sidebar-letter mb-2"><?php echo strtoupper(substr($name, 0, 1)); ?></div>
        <?php endif; ?>

        <div class="mb-2"><img src="../images/main-logo.png" alt="Larry J Gadjets" style="width:175px;max-width:100%;height:auto;"></div>
        <small class="text-white-50"><?php echo $isAdmin ? 'ADMIN' : 'CUSTOMER'; ?></small>
    </div>

    <nav>
        <a href="../index.php" class="sidebar-link"><i class="bi bi-house me-2"></i> Home</a>
        <a href="index.php" class="sidebar-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a href="post.php" class="sidebar-link"><i class="bi bi-box-seam me-2"></i> Latest Product</a>
        <a href="admin_shop.php" class="sidebar-link"><i class="bi bi-shop-window me-2"></i> Shop Products</a>
        <a href="user.php" class="sidebar-link"><i class="bi bi-people me-2"></i> Customers</a>
        <a href="order.php" class="sidebar-link"><i class="bi bi-bag-check me-2"></i> Orders</a>

        <a href="../shop.php" class="sidebar-link"><i class="bi bi-shop me-2"></i> Shop</a>
        <a href="../cart.php" class="sidebar-link"><i class="bi bi-cart3 me-2"></i> Cart</a>
        <a href="../checkout.php" class="sidebar-link"><i class="bi bi-credit-card me-2"></i> Checkout</a>
        <a href="settings.php" class="sidebar-link"><i class="bi bi-gear me-2"></i> Settings</a>
        <a href="logout.php" class="sidebar-link"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
    </nav>
</div>

<style>
.sidebar{width:250px;min-height:100vh;flex:0 0 250px;overflow-y:auto;overflow-x:hidden;box-sizing:border-box}
.sidebar-top{min-width:0}
.sidebar-picture,.sidebar-letter{width:55px;height:55px;border-radius:50%}
.sidebar-picture{object-fit:cover;border:2px solid #fff;display:inline-block}
.sidebar-letter{display:flex;align-items:center;justify-content:center;background:#0d6efd;color:#fff;margin-left:auto;margin-right:auto;font-weight:800;font-size:22px}
.sidebar-link{display:block;color:#fff;text-decoration:none;padding:10px 12px;border-radius:8px;margin-bottom:4px;white-space:nowrap}
.sidebar-link:hover{background:#0d6efd;color:#fff}
@media(max-width:768px){.sidebar{position:fixed;left:-260px;top:0;z-index:2000;height:100vh;transition:.2s}.sidebar.show{left:0}.sidebar-link{padding:11px 10px}}
</style>

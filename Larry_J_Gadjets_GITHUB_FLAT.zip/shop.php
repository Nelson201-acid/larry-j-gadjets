<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once "dashboard/header.php";
require_once "shop_data.php";

$isLoggedIn = isset($_SESSION['id']);
$dashboard = ($isLoggedIn && strtolower((string)($_SESSION['role'] ?? 'customer')) === 'admin') ? 'dashboard%201/index.php' : 'dashboard/index.php';

$chosenCategory = trim((string)($_GET['category'] ?? ''));
$chosenSort = trim((string)($_GET['sort'] ?? 'featured'));
if (!in_array($chosenSort, ['featured', 'price-asc', 'price-desc', 'name-asc'], true)) {
    $chosenSort = 'featured';
}

$categories = shopGetCategories($conn);
$products = shopGetProducts($conn, $chosenCategory, $chosenSort);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Shop All Products — Larry J Gadjets</title>
<meta name="description" content="Browse phones, watches, headphones and accessories at Larry J Gadjets.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="shop-cart.css">
<style>
#cartToast.show { display:block !important; opacity:1; }

  .product-body .d-flex.gap-2 > .add-cart-btn{ width:auto; }
  .sort-select{width:190px;max-width:100%;}
  @media(max-width:576px){.sort-select{width:100%;}.d-flex.align-items-center.gap-2{width:100%;}.d-flex.align-items-center.gap-2 .form-label{flex:0 0 auto;}.d-flex.align-items-center.gap-2 .sort-select{flex:1;}}
  .product-description{line-height:1.55;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;}
  #productGrid .product-item{display:flex;}
  #productGrid .product-card{width:100%;height:100%;display:flex;flex-direction:column;}
  #productGrid .product-media{height:230px;flex-shrink:0;overflow:hidden;}
  #productGrid .product-media img{width:100%;height:100%;object-fit:cover;}
  #productGrid .product-body{display:flex;flex-direction:column;flex:1;}
  #productGrid .product-name{min-height:48px;}
  #productGrid .product-description{min-height:70px;}
  #productGrid .product-price{min-height:30px;}
  #productGrid .product-body > .d-flex:last-child{margin-top:auto;}
</style>
</head>
<body data-user-id="<?php echo $isLoggedIn ? (int) $_SESSION['id'] : 0; ?>" data-authenticated="<?php echo $isLoggedIn ? '1' : '0'; ?>">
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

<header class="site-header">
  <nav class="navbar navbar-expand-lg py-3">
    <div class="container">
      <a class="brand-mark d-flex align-items-center" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>
      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"><i class="bi bi-list fs-2"></i></button>
      <div class="collapse navbar-collapse" id="navMain">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom active" href="shop.php">Shop</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#company-services">Services</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#latest-blog">Blog</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="about.php#contact">Contact</a></li>
        </ul>
      </div>
      <div class="d-flex align-items-center gap-1">
        <a href="#" class="icon-btn d-none d-sm-inline-flex"><i class="bi bi-search fs-5"></i></a>
        <a href="<?php echo $isLoggedIn ? $dashboard : 'dashboard/login.php'; ?>" class="icon-btn d-none d-sm-inline-flex"><i class="bi bi-person fs-5"></i></a>
        <a href="cart.php" class="icon-btn"><i class="bi bi-bag fs-5"></i><span class="cart-count">0</span></a>
      </div>
    </div>
  </nav>
</header>

<section class="page-banner">
  <div class="container">
    <div class="eyebrow mb-2">Catalog</div>
    <h1 class="display-5 mb-2">Shop All Products</h1>
    <div class="breadcrumb-custom small"><a href="index.php">Home</a><span class="sep">/</span><span>Shop</span></div>
  </div>
</section>

<section class="py-4 border-bottom bg-white">
  <div class="container">
    <div class="d-flex flex-column flex-lg-row gap-3 align-items-lg-center justify-content-between">
      <div class="d-flex flex-wrap gap-2" id="categoryChips">
        <a class="chip <?php echo $chosenCategory === '' ? 'active' : ''; ?>" href="shop.php?sort=<?php echo urlencode($chosenSort); ?>">All Products</a>
        <?php foreach ($categories as $category): ?>
          <a class="chip <?php echo $chosenCategory === $category ? 'active' : ''; ?>" href="shop.php?category=<?php echo urlencode($category); ?>&sort=<?php echo urlencode($chosenSort); ?>"><?php echo htmlspecialchars($category, ENT_QUOTES, 'UTF-8'); ?></a>
        <?php endforeach; ?>
      </div>
      <form method="get" class="d-flex align-items-center gap-2">
        <?php if ($chosenCategory !== ''): ?><input type="hidden" name="category" value="<?php echo htmlspecialchars($chosenCategory, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
        <label for="sortSelect" class="form-label mb-0 small text-nowrap">Sort by</label>
        <select id="sortSelect" name="sort" class="form-select form-select-sm sort-select">
          <option value="featured" <?php echo $chosenSort === 'featured' ? 'selected' : ''; ?>>Featured</option>
          <option value="price-asc" <?php echo $chosenSort === 'price-asc' ? 'selected' : ''; ?>>Price: Low to High</option>
          <option value="price-desc" <?php echo $chosenSort === 'price-desc' ? 'selected' : ''; ?>>Price: High to Low</option>
          <option value="name-asc" <?php echo $chosenSort === 'name-asc' ? 'selected' : ''; ?>>Name: A–Z</option>
        </select>
        <button type="submit" class="btn btn-sm btn-dark">Go</button>
      </form>
    </div>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <p class="text-muted small mb-0"><?php echo count($products); ?> products</p>
    </div>

    <?php if ($products): ?>
    <div class="row g-4" id="productGrid">
      <?php foreach ($products as $p): ?>
        <?php
          $pid = (int)$p['id'];
          $name = (string)$p['name'];
          $category = (string)$p['category'];
          $images = $p['all_images'] ?? shopImages($p);
          $image = shopImageUrl($images[0] ?? (string)$p['image']);
          $desc = (string)($p['description'] ?? '');
        ?>
        <div class="col-6 col-md-4 col-lg-3 product-item">
          <div class="product-card">
            <div class="product-media">
              <?php if (!empty($p['badge'])): ?><span class="product-badge <?php echo $p['badge'] === 'Sale' ? 'sale' : ''; ?>"><?php echo htmlspecialchars($p['badge'], ENT_QUOTES, 'UTF-8'); ?></span><?php endif; ?>
              <a href="product.php?source=shop&id=<?php echo $pid; ?>"><img src="<?php echo htmlspecialchars($image, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy"></a>
            </div>
            <div class="product-body">
              <div class="product-cat"><?php echo htmlspecialchars($category, ENT_QUOTES, 'UTF-8'); ?></div>
              <h3 class="product-name"><a href="product.php?source=shop&id=<?php echo $pid; ?>" class="text-dark text-decoration-none"><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></a></h3>
              <p class="product-description text-muted small mb-3"><?php echo htmlspecialchars($desc, ENT_QUOTES, 'UTF-8'); ?></p>
              <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="product-price">₦<?php echo number_format((float)$p['price'], 2); ?><?php if ($p['old_price'] !== null && $p['old_price'] !== ''): ?><span class="was">₦<?php echo number_format((float)$p['old_price'], 2); ?></span><?php endif; ?></span>
              </div>
              <div class="d-flex gap-2">
                <button type="button" class="btn btn-ink add-cart-btn add-cart flex-grow-1" data-id="shop-<?php echo $pid; ?>" data-name="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>" data-price="<?php echo (float)$p['price']; ?>" data-image="<?php echo htmlspecialchars($image, ENT_QUOTES, 'UTF-8'); ?>" data-category="<?php echo htmlspecialchars($category, ENT_QUOTES, 'UTF-8'); ?>"><i class="bi bi-bag-plus me-1"></i> Add to Cart</button>
                <a href="product.php?source=shop&id=<?php echo $pid; ?>" class="btn btn-ghost" title="Read More — view product details" aria-label="Read more about <?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>"><i class="bi bi-eye"></i></a>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
      <div class="empty-state text-center py-5"><i class="bi bi-search fs-1 text-muted"></i><h4 class="mt-3">No products match this filter</h4><p class="text-muted">Try a different category.</p></div>
    <?php endif; ?>
  </div>
</section>

<div class="position-fixed bottom-0 end-0 p-3" style="z-index:1100;"><div id="cartToast" class="toast align-items-center text-white bg-dark border-0" role="alert"><div class="d-flex"><div class="toast-body"><i class="bi bi-check-circle me-2 text-accent"></i><span id="toastMsg">Added to cart</span></div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>

<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4"><a class="brand-mark text-white d-inline-block mb-3" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a><p class="small">Everyday tech, chosen carefully. Phones, wearables, audio and accessories — delivered fast, backed by a real warranty.</p></div>
      <div class="col-lg-2 col-6"><h6>Shop</h6><ul class="list-unstyled small"><li class="mb-2"><a href="shop.php">All Products</a></li><li class="mb-2"><a href="cart.php">Cart</a></li><li class="mb-2"><a href="<?php echo $isLoggedIn ? 'checkout.php' : 'dashboard/login.php?redirect=checkout.php'; ?>">Checkout</a></li></ul></div>
      <div class="col-lg-2 col-6"><h6>Company</h6><ul class="list-unstyled small"><li class="mb-2"><a href="about.php">About Us</a></li><li class="mb-2"><a href="blog.php">Blog</a></li><li class="mb-2"><a href="about.php#contact">Contact</a></li></ul></div>
      <div class="col-lg-4"><h6>Contact</h6><p class="small mb-1">Questions? <a href="mailto:hello@Larry J Gadjets.example">ugwuanyinelson46@gmail.com</a></p><p class="small">Support line: <a href="tel:+15551234567">+2349043855373</a></p></div>
    </div>
    <div class="fine-print d-flex flex-wrap justify-content-between"><span>© 2026 Larry J Gadjets. All rights reserved.</span><span>Secure checkout · Visa · Mastercard · PayPal</span></div>
  </div>
</footer>

<script src="bootstrap.min.js"></script>
<script src="cart.js"></script>


<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

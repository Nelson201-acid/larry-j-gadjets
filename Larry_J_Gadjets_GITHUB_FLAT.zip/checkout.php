<?php
require_once __DIR__ . '/dashboard/header.php';

/*
   A customer must be logged in before checkout.
   The login page is in dashboard/login.php.
*/
if (!isset($_SESSION['id'])) {
    $_SESSION['checkout_after_login'] = '../checkout.php';
    header('Location: dashboard/login.php?redirect=checkout.php');
    exit();
}

$userId = (int) $_SESSION['id'];
$username = (string) ($_SESSION['username'] ?? 'Customer');
$email = (string) ($_SESSION['email'] ?? '');

/* Turn the cart into easy text for the orders table. */
function getItemNames(array $cart): string
{
    $names = [];

    foreach ($cart as $item) {
        if (!is_array($item)) {
            continue;
        }

        $name = trim((string) ($item['name'] ?? ''));
        $price = max(0, (float) ($item['price'] ?? 0));
        $quantity = max(1, (int) ($item['quantity'] ?? 1));

        if ($name !== '') {
            $lineTotal = $price * $quantity;
            $names[] = $name . ' | Qty: ' . $quantity . ' | Price: ₦' . number_format($price, 2) . ' | Total: ₦' . number_format($lineTotal, 2);
        }
    }

    return implode(', ', $names);
}

/* Work out the amount that was paid. */
function getTotal(array $cart): float
{
    $subtotal = 0;

    foreach ($cart as $item) {
        if (!is_array($item)) {
            continue;
        }

        $price = max(0, (float) ($item['price'] ?? 0));
        $quantity = max(1, (int) ($item['quantity'] ?? 1));
        $subtotal += $price * $quantity;
    }

    $shipping = ($subtotal > 0 && $subtotal < 99946) ? 9315 : 0;
    $tax = $subtotal * 0.075;

    return $subtotal + $shipping + $tax;
}

/*
   Save the order.
   We check the columns that really exist in the orders table.
   This stops a missing optional column from breaking the order.
*/
function saveOrder(mysqli $conn, int $userId, string $name, string $email, string $address, string $city, string $state, string $zipcode, string $payment, string $reference, array $cart): array
{
    $items = getItemNames($cart);
    $total = getTotal($cart);

    if ($items === '') {
        return [false, 0, 'There are no products in the cart.'];
    }

    /* Read the real columns in the orders table. */
    $columns = [];
    $columnResult = mysqli_query($conn, 'SHOW COLUMNS FROM orders');

    if (!$columnResult) {
        return [false, 0, 'The orders table could not be read.'];
    }

    while ($column = mysqli_fetch_assoc($columnResult)) {
        $columns[] = $column['Field'];
    }

    /* These are the important fields. */
    $needed = ['name', 'email', 'order_items', 'total'];

    foreach ($needed as $field) {
        if (!in_array($field, $columns, true)) {
            return [false, 0, 'The orders table is missing the "' . $field . '" column.'];
        }
    }

    $data = [];

    /* Add only columns that are really in the table. */
    $data['name'] = [$name, 's'];
    $data['email'] = [$email, 's'];
    $data['order_items'] = [$items, 's'];
    $data['total'] = [$total, 'd'];

    if (in_array('status', $columns, true)) {
        $data['status'] = ['pending', 's'];
    }

    $optional = [
        'city' => [$city, 's'],
        'address' => [$address, 's'],
        'payment_method' => [$payment, 's'],
        'reference' => [$reference, 's'],
        'state' => [$state, 's'],
        'zipcode' => [$zipcode, 's'],
        'user_id' => [$userId, 'i']
    ];

    foreach ($optional as $field => $value) {
        if (in_array($field, $columns, true)) {
            $data[$field] = $value;
        }
    }

    $fieldNames = array_keys($data);
    $marks = implode(', ', array_fill(0, count($fieldNames), '?'));
    $sql = 'INSERT INTO orders (' . implode(', ', $fieldNames) . ') VALUES (' . $marks . ')';

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return [false, 0, mysqli_error($conn)];
    }

    $types = '';
    $values = [];

    foreach ($data as $value) {
        $types .= $value[1];
        $values[] = $value[0];
    }

    $bind = [$stmt, $types];

    foreach ($values as $key => $value) {
        $bind[] = &$values[$key];
    }

    call_user_func_array('mysqli_stmt_bind_param', $bind);

    if (!mysqli_stmt_execute($stmt)) {
        $error = mysqli_stmt_error($stmt);
        mysqli_stmt_close($stmt);

        return [false, 0, $error !== '' ? $error : 'The order could not be saved.'];
    }

    $orderId = mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);

    return [true, $orderId, 'Order saved successfully.'];
}

/* Paystack or Cash on Delivery sends the order here. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['save_order'] ?? '') === '1') {

    $name = trim($_POST['name'] ?? '');
    $customerEmail = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $zipcode = trim($_POST['zipcode'] ?? '');
    $payment = ($_POST['payment_method'] ?? 'card') === 'cod' ? 'cod' : 'card';
    $reference = trim($_POST['reference'] ?? '');
    $cart = $_POST['cart'] ?? [];

    if (!is_array($cart)) {
        $cart = [];
    }

    if (
        $name === '' ||
        !filter_var($customerEmail, FILTER_VALIDATE_EMAIL) ||
        $address === '' ||
        $city === '' ||
        $state === '' ||
        $zipcode === '' ||
        empty($cart)
    ) {
        $errorMessage = 'Please fill in all checkout details.';
    } elseif ($payment === 'card' && $reference === '') {
        $errorMessage = 'Paystack payment reference is missing.';
    } else {
        $result = saveOrder(
            $conn,
            $userId,
            $name,
            $customerEmail,
            $address,
            $city,
            $state,
            $zipcode,
            $payment,
            $reference,
            $cart
        );

        if ($result[0]) {
            $orderDashboard = strtolower(trim((string)($_SESSION['role'] ?? 'customer'))) === 'admin'
                ? 'dashboard%201/order.php'
                : 'dashboard/order.php';
            header('Location: ' . $orderDashboard);
            exit();
        }

        $errorMessage = $result[2];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout - Larry J Gadjets</title>
<link href="bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" href="shop-cart.css">
</head>

<body data-user-id="<?php echo (int) $userId; ?>" data-authenticated="1">
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>


<header class="site-header">
<nav class="navbar navbar-expand-lg py-3">
<div class="container">
<a class="brand-mark d-flex align-items-center" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>
<div class="d-flex align-items-center gap-2 ms-auto">
<a href="shop.php" class="btn btn-sm btn-outline-dark">Shop</a>
<a href="cart.php" class="icon-btn"><i class="bi bi-cart3"></i><span class="cart-count">0</span></a>
<a href="dashboard<?php echo ($_SESSION['role'] ?? '') === 'admin' ? '%201/index.php' : '/index.php'; ?>" class="btn btn-sm btn-primary"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
</div>
</div>
</nav>
</header>

<section class="page-banner">
<div class="container">
<div class="eyebrow">Secure checkout</div>
<h1 class="display-5">Checkout</h1>
<p class="mb-0">Hello <?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>. You are logged in.</p>
</div>
</section>

<section class="py-5">
<div class="container">
<div id="message" aria-live="polite">
<?php if (!empty($errorMessage)): ?>
<div class="alert alert-danger d-flex align-items-start gap-3 shadow-sm" role="alert"><i class="bi bi-exclamation-triangle-fill fs-4 mt-1"></i><div><?php echo htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8'); ?></div></div>
<?php endif; ?>
</div>
<div class="row g-4">

<div class="col-lg-7">
<div class="form-card">
<h2 class="h5 fw-bold mb-3">Delivery Details</h2>

<form id="checkoutForm">

<div class="row g-3">

<div class="col-md-6">
<label class="form-label">Full Name</label>
<input id="name" class="form-control" value="<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>" required>
</div>

<div class="col-md-6">
<label class="form-label">Email</label>
<input id="email" type="email" class="form-control" value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>" required>
</div>

<div class="col-12">
<label class="form-label">Address</label>
<input id="address" class="form-control" required>
</div>

<div class="col-md-5">
<label class="form-label">City</label>
<input id="city" class="form-control" required>
</div>

<div class="col-md-4">
<label class="form-label">State</label>
<input id="state" class="form-control" required>
</div>

<div class="col-md-3">
<label class="form-label">Postal Code</label>
<input id="zipcode" class="form-control" required>
</div>

</div>

<div class="mt-4">
<label class="form-label fw-semibold">Payment</label>
<div class="d-flex gap-3">
<label><input type="radio" name="payment" value="card" checked> Card (Paystack)</label>
<label><input type="radio" name="payment" value="cod"> Cash on Delivery</label>
</div>
</div>

<button type="submit" id="payButton" class="btn btn-accent w-100 mt-4">Place Order</button>

</form>
</div>
</div>

<div class="col-lg-5">
<div class="summary-card">
<h2 class="h5 fw-bold">Order Summary</h2>
<div id="items"></div>
<hr>
<div class="summary-row"><span>Subtotal</span><span id="subtotal">₦0.00</span></div>
<div class="summary-row"><span>Shipping</span><span id="shipping">₦0.00</span></div>
<div class="summary-row"><span>Tax</span><span id="tax">₦0.00</span></div>
<div class="summary-row total"><span>Total</span><span id="total">₦0.00</span></div>
</div>
</div>

</div>
</div>
</section>

<script src="bootstrap.min.js"></script>
<script src="https://js.paystack.co/v2/inline.js"></script>
<script src="cart.js"></script>

<script>

const form = document.getElementById('checkoutForm');
const button = document.getElementById('payButton');
const message = document.getElementById('message');

function showMessage(text, type = 'danger', icon = null) {
    const iconClass = icon || (type === 'success' ? 'bi bi-check-circle-fill' : 'bi bi-exclamation-triangle-fill');
    message.innerHTML = '<div class="order-message alert alert-' + type + ' d-flex align-items-start gap-3 shadow-sm" role="alert"><i class="' + iconClass + ' fs-4 mt-1"></i><div>' + text + '</div></div>';
}

function showSummary() {
    const cart = getCart();
    const box = document.getElementById('items');

    box.innerHTML = '';

    cart.forEach(item => {
        const price = Number(item.price) || 0;
        const quantity = Number(item.quantity) || 1;
        const lineTotal = price * quantity;

        box.innerHTML += '<div class="d-flex justify-content-between gap-3 mb-2"><span>' +
            item.name + ' x' + quantity +
            '</span><span>' + formatCurrency(lineTotal) + '</span></div>';
    });

    const subtotal = getCartSubtotal();
    const shipping = getShippingCost(subtotal);
    const tax = getTax(subtotal);
    const total = subtotal + shipping + tax;

    document.getElementById('subtotal').textContent = formatCurrency(subtotal);
    document.getElementById('shipping').textContent = shipping ? formatCurrency(shipping) : 'Free';
    document.getElementById('tax').textContent = formatCurrency(tax);
    document.getElementById('total').textContent = formatCurrency(total);
}

function addCartFields(targetForm, currentCart) {
    currentCart.forEach(function(item, index) {
        const name = document.createElement('input');
        name.type = 'hidden';
        name.name = 'cart[' + index + '][name]';
        name.value = item.name || '';
        targetForm.appendChild(name);

        const price = document.createElement('input');
        price.type = 'hidden';
        price.name = 'cart[' + index + '][price]';
        price.value = Number(item.price) || 0;
        targetForm.appendChild(price);

        const quantity = document.createElement('input');
        quantity.type = 'hidden';
        quantity.name = 'cart[' + index + '][quantity]';
        quantity.value = Number(item.quantity) || 1;
        targetForm.appendChild(quantity);
    });
}

function submitOrder(payment, reference) {
    const currentCart = getCart();

    if (!currentCart.length) {
        showMessage('Your cart is empty.');
        return;
    }

    const orderForm = document.createElement('form');
    orderForm.method = 'POST';
    orderForm.action = './checkout.php';
    orderForm.style.display = 'none';

    const saveOrder = document.createElement('input');
    saveOrder.type = 'hidden';
    saveOrder.name = 'save_order';
    saveOrder.value = '1';
    orderForm.appendChild(saveOrder);

    const referenceInput = document.createElement('input');
    referenceInput.type = 'hidden';
    referenceInput.name = 'reference';
    referenceInput.value = reference || '';
    orderForm.appendChild(referenceInput);

    const paymentInput = document.createElement('input');
    paymentInput.type = 'hidden';
    paymentInput.name = 'payment_method';
    paymentInput.value = payment;
    orderForm.appendChild(paymentInput);

    const fields = {
        name: document.getElementById('name').value.trim(),
        email: document.getElementById('email').value.trim(),
        address: document.getElementById('address').value.trim(),
        city: document.getElementById('city').value.trim(),
        state: document.getElementById('state').value.trim(),
        zipcode: document.getElementById('zipcode').value.trim()
    };

    Object.keys(fields).forEach(function(field) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = field;
        input.value = fields[field];
        orderForm.appendChild(input);
    });

    addCartFields(orderForm, currentCart);

    /* Clear the complete cart for the customer currently logged in. */
    clearCart();

    document.body.appendChild(orderForm);
    orderForm.submit();
}

form.addEventListener('submit', function(event) {
    event.preventDefault();

    const currentCart = getCart();

    if (!currentCart.length) {
        showMessage('Your cart is empty.');
        return;
    }

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const address = document.getElementById('address').value.trim();
    const city = document.getElementById('city').value.trim();
    const state = document.getElementById('state').value.trim();
    const zipcode = document.getElementById('zipcode').value.trim();
    const payment = document.querySelector('input[name="payment"]:checked').value;
    const total = getCartTotal();

    if (name.length < 2 || !email || !address || !city || !state || !zipcode) {
        showMessage('Please fill in all the checkout fields.');
        return;
    }

    /* CASH ON DELIVERY */
    if (payment === 'cod') {
        button.disabled = true;
        button.textContent = 'Placing Order...';
        submitOrder('cod', '');
        return;
    }

    /* PAYSTACK */
    if (typeof PaystackPop === 'undefined') {
        showMessage('Paystack could not load. Check your internet connection.');
        return;
    }

    button.disabled = true;
    button.textContent = 'Opening Paystack...';

    const paystack = new PaystackPop();

    paystack.newTransaction({
        key: 'pk_test_0ce12d3d5969cfbd38f8bfd25b4ade775a4b4752',
        email: email,
        amount: Math.round(total * 100),
        currency: 'NGN',
        firstName: name.split(' ')[0],

        onSuccess: function(transaction) {
            /*
               Paystack has confirmed the payment.
               Submit the order directly to PHP.
               PHP then redirects to the correct role-specific order page.
            */
            button.textContent = 'Payment Successful. Opening Orders...';
            submitOrder('card', transaction.reference);
        },

        onCancel: function() {
            button.disabled = false;
            button.textContent = 'Place Order';
            showMessage('Payment was cancelled.');
        },

        onError: function() {
            button.disabled = false;
            button.textContent = 'Place Order';
            showMessage('Paystack had a problem.');
        }
    });
});

showSummary();
updateCartCount();

</script>


<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

LARRY J GADJETS — FLAT GITHUB ARCHIVE

All original project files are placed at this ZIP's root. Files that originally lived in subfolders have a filename prefix that records their old location (for example, dashboard__login.php). This prevents filename collisions such as the multiple index.php and conn.php files.

IMPORTANT: This is the requested single-folder storage copy. It is NOT the deployable web layout because PHP include paths, image paths, CSS paths, and admin links expect the original folders. Use Larry_J_Gadjets_QSERVERS_CPANEL.zip to deploy the working site. GitHub Pages also does not execute PHP.

The bytes of every original project file are unchanged; nested file names are prefixed only for this flat archive.

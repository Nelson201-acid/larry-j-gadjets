<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["id"], $_SESSION["role"])) {
    header("Location: login.php");
    exit();
}

$role = strtolower(trim((string)$_SESSION["role"]));
$isAdmin = $role === "admin";
$isCustomer = $role === "customer";

if ($isAdmin) {
    header("Location: ../dashboard%201/index.php");
    exit();
}

if (!$isCustomer) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

function pictureName(string $image): string
{
    $image = trim($image);

    if ($image === '') {
        return '';
    }

    // Accept a filename, ../assets/image/name.jpg, or a Windows path.
    $image = str_replace('\\', '/', $image);
    $image = urldecode($image);
    $image = explode('?', $image, 2)[0];
    $image = explode('#', $image, 2)[0];

    return basename($image);
}

function getProfileImage(): string
{
    global $conn;

    $userId = (int)($_SESSION['id'] ?? 0);
    $image = pictureName((string)($_SESSION['image'] ?? ''));

    if ($userId > 0) {
        $stmt = mysqli_prepare($conn, 'SELECT image FROM client WHERE id = ? LIMIT 1');

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $userId);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $databaseImage);
            $found = mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);

            if ($found) {
                $databaseImage = pictureName((string)($databaseImage ?? ''));

                if ($databaseImage !== '') {
                    $image = $databaseImage;
                    $_SESSION['image'] = $image;
                }
            }
        }
    }

    return $image;
}

function profileImageFile(string $image): string
{
    $image = pictureName($image);
    return __DIR__ . '/../assets/image/' . $image;
}

function profileImageUrl(string $image): string
{
    $image = pictureName($image);

    if ($image === '') {
        return '';
    }

    $file = profileImageFile($image);
    $url = '../assets/image/' . rawurlencode($image);

    if (is_file($file)) {
        $url .= '?v=' . filemtime($file);
    }

    return $url;
}

function goToDashboard(): void
{
    global $isAdmin;
    header('Location: index.php');
    exit();
}

function requireAdmin(): void
{
    global $isAdmin;

    if (!$isAdmin) {
        header('Location: index.php');
        exit();
    }
}
?>

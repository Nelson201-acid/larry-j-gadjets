<?php
session_start();

$userId = $_SESSION['id'] ?? 0;
$isAuthenticated = !empty($userId) ? '1' : '0';
$userName = $_SESSION['username'] ?? 'guest';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog — Larry J Gadjets</title>
<meta name="description" content="Guides, buying tips and product news from the Larry J Gadjets team.">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="shop-cart.css">

<style>
  .post-card{
    background:var(--paper-alt); border:1px solid var(--line); border-radius:var(--radius);
    overflow:hidden; height:100%; transition:box-shadow .2s ease, transform .2s ease;
  }
  .post-card:hover{ box-shadow:var(--shadow-lg); transform:translateY(-3px); }
  .post-media{ aspect-ratio:16/10; background:var(--paper); overflow:hidden; }
  .post-media img{ width:100%; height:100%; object-fit:cover; }
  .post-body{ padding:1.1rem 1.25rem 1.3rem; }
  .post-meta{ font-size:.72rem; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); margin-bottom:.4rem; }
  .post-meta .cat{ color:var(--accent); font-weight:600; }
  .post-title{ font-size:1.05rem; font-weight:500; margin-bottom:.6rem; }
  .post-title a{ color:var(--ink); }
  .post-title a:hover{ color:var(--accent); }
  .post-excerpt{ font-size:.88rem; color:var(--muted); margin-bottom:0; }
  .post-card.featured .post-media{ aspect-ratio:16/9; }
  .post-price{ font-size:1rem; font-weight:700; color:var(--ink); margin-top:.9rem; }
  .post-cart-btn{ margin-top:.65rem; padding:.45rem .75rem; font-size:.8rem; border-radius:.35rem; }
</style>

<style id="ljg-preloader-style">
body::before{content:"";position:fixed;inset:0;z-index:2147483647;background:#0b0b0b url("images/main-logo.png") center 45%/min(360px,72vw) auto no-repeat;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:all}body::after{content:"";position:fixed;z-index:2147483647;left:50%;top:60%;width:180px;height:4px;transform:translateX(-50%);border-radius:20px;background:linear-gradient(90deg,transparent,#e10600,transparent);animation:ljgLoad 1.05s ease-in-out infinite;opacity:1;visibility:visible;transition:opacity .35s ease,visibility .35s ease;pointer-events:none}@keyframes ljgLoad{0%{clip-path:inset(0 100% 0 0)}50%{clip-path:inset(0 0 0 0)}100%{clip-path:inset(0 0 0 100%)}}body.ljg-ready::before,body.ljg-ready::after{opacity:0;visibility:hidden;pointer-events:none}
</style>
<!-- loader-script --><script id="ljg-preloader-script">window.addEventListener('load',function(){if(document.body){document.body.classList.add('ljg-ready');}});</script>
</head>
<body
  data-user-id="<?= htmlspecialchars((string)$userId, ENT_QUOTES, 'UTF-8') ?>"
  data-authenticated="<?= $isAuthenticated ?>"
  data-user="<?= htmlspecialchars((string)$userName, ENT_QUOTES, 'UTF-8') ?>"
>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>
"
  data-authenticated="<?= $isAuthenticated ?>"
  data-user="<?= htmlspecialchars((string)$userName, ENT_QUOTES, 'UTF-8') ?>"
>

<!-- ============ HEADER ============ -->
<header class="site-header">
  <nav class="navbar navbar-expand-lg py-3">
    <div class="container">
      <a class="brand-mark d-flex align-items-center" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>

      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
        <i class="bi bi-list fs-2"></i>
      </button>

      <div class="collapse navbar-collapse" id="navMain">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="shop.php">Shop</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="./about.php">About</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="index.php#company-services">Services</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom active" href="blog.php">Blog</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="about.php#contact">Contact</a></li>
        </ul>
      </div>

      <div class="d-flex align-items-center gap-1">
        <a href="#" class="icon-btn d-none d-sm-inline-flex"><i class="bi bi-search fs-5"></i></a>
        <a href="#" class="icon-btn d-none d-sm-inline-flex"><i class="bi bi-person fs-5"></i></a>
        <a href="cart.php" class="icon-btn">
          <i class="bi bi-bag fs-5"></i>
          <span class="cart-count">0</span>
        </a>
      </div>
    </div>
  </nav>
</header>

<!-- ============ PAGE BANNER ============ -->
<section class="page-banner">
  <div class="container">
    <div class="eyebrow mb-2">Larry J Gadjets Blog</div>
    <h1 class="display-5 mb-2">Guides &amp; Product News</h1>
    <div class="breadcrumb-custom small">
      <a href="index.php">Home</a><span class="sep">/</span><span>Blog</span>
    </div>
  </div>
</section>

<!-- ============ CATEGORY CHIPS ============ -->
<section class="py-4 border-bottom bg-white">
  <div class="container">
    <div class="d-flex flex-wrap gap-2" id="categoryChips">
      <button class="chip active" data-cat="all">All Posts</button>
      <button class="chip" data-cat="Phones">Phones</button>
      <button class="chip" data-cat="Smart Watches">Smart Watches</button>
      <button class="chip" data-cat="Gadgets">Gadgets</button>
      <button class="chip" data-cat="Technology">Technology</button>
      <button class="chip" data-cat="Camera">Camera</button>
    </div>
  </div>
</section>

<!-- ============ POST GRID ============ -->
<section class="py-5">
  <div class="container">
    <div class="row g-4" id="postGrid">

      <div class="col-md-6 col-lg-4 post-item" data-cat="Phones">
        <article class="post-card featured h-100">
          <div class="post-media"><img src="images/iphone 13 f.jpg" alt="Iphone 13 vs Iphone 12"></div>
          <div class="post-body">
            <div class="post-meta"><span>Aug 12, 2026</span> <span class="cat">— Phones</span></div>
            <h2 class="post-title"><a href="#">Iphone 13 vs Iphone 12: Which One Should You Buy?</a></h2>
            <p class="post-excerpt">We compare cameras, battery life and price to help you decide which model actually fits your budget.</p>
            <div class="post-price">₦1,500.00</div>
            <button type="button" class="btn btn-dark add-cart post-cart-btn"
              data-id="4" data-name="Iphone 13" data-price="1,500"
              data-image="images/iphone 13 f.jpg" data-category="Mobile Phones">
              <i class="bi bi-bag-plus me-1"></i>Add to Cart
            </button>
          </div>
        </article>
      </div>

      <div class="col-md-6 col-lg-4 post-item" data-cat="Phones">
        <article class="post-card h-100">
          <div class="post-media"><img src="images/product-item2.jpg" alt="5 Reasons to Upgrade to the Iphone 11"></div>
          <div class="post-body">
            <div class="post-meta"><span>Jul 30, 2026</span> <span class="cat">— Phones</span></div>
            <h2 class="post-title"><a href="#">5 Reasons to Upgrade to the Iphone 11</a></h2>
            <p class="post-excerpt">Still on an older phone? Here's what actually changes day-to-day when you make the jump.</p>
            <div class="post-price">₦1,100.00</div>
            <button type="button" class="btn btn-dark add-cart post-cart-btn"
              data-id="2" data-name="Iphone 11" data-price="1,100"
              data-image="images/product-item2.jpg" data-category="Mobile Phones">
              <i class="bi bi-bag-plus me-1"></i>Add to Cart
            </button>
          </div>
        </article>
      </div>

      <div class="col-md-6 col-lg-4 post-item" data-cat="Smart Watches">
        <article class="post-card h-100">
          <div class="post-media"><img src="images/product-item6.jpg" alt="Smartwatch buying guide"></div>
          <div class="post-body">
            <div class="post-meta"><span>Jul 18, 2026</span> <span class="cat">— Smart Watches</span></div>
            <h2 class="post-title"><a href="#">Smartwatch Buying Guide: Finding the Right Fit</a></h2>
            <p class="post-excerpt">From everyday fitness tracking to standout style — how to pick a smartwatch you'll actually wear.</p>
          </div>
        </article>
      </div>

      <div class="col-md-6 col-lg-4 post-item" data-cat="Gadgets">
        <article class="post-card h-100">
          <div class="post-media"><img src="images/post-item1.jpg" alt="Get some cool gadgets in 2023"></div>
          <div class="post-body">
            <div class="post-meta"><span>Feb 22, 2023</span> <span class="cat">— Gadgets</span></div>
            <h2 class="post-title"><a href="#">Get Some Cool Gadgets in 2023</a></h2>
            <p class="post-excerpt">A roundup of the small everyday gadgets worth adding to your setup this year.</p>
          </div>
        </article>
      </div>

      <div class="col-md-6 col-lg-4 post-item" data-cat="Technology">
        <article class="post-card h-100">
          <div class="post-media"><img src="images/post-item2.jpg" alt="Technology Hack You Won't Get"></div>
          <div class="post-body">
            <div class="post-meta"><span>Feb 25, 2023</span> <span class="cat">— Technology</span></div>
            <h2 class="post-title"><a href="#">Technology Hack You Won't Get</a></h2>
            <p class="post-excerpt">A few lesser-known tricks for getting more out of the devices you already own.</p>
          </div>
        </article>
      </div>

      <div class="col-md-6 col-lg-4 post-item" data-cat="Camera">
        <article class="post-card h-100">
          <div class="post-media"><img src="images/post-item3.jpg" alt="Top 10 Small Camera In The World"></div>
          <div class="post-body">
            <div class="post-meta"><span>Feb 22, 2023</span> <span class="cat">— Camera</span></div>
            <h2 class="post-title"><a href="#">Top 10 Small Cameras In The World</a></h2>
            <p class="post-excerpt">Compact doesn't mean compromised — our picks for the best small-form cameras.</p>
          </div>
        </article>
      </div>

    </div>

    <div class="empty-state d-none" id="noPosts">
      <i class="bi bi-journal-text fs-1 text-muted"></i>
      <h4 class="mt-3">No posts in this category yet</h4>
      <p class="text-muted">Check back soon, or browse all posts.</p>
    </div>
  </div>
</section>

<!-- ============ FOOTER ============ -->
<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <a class="brand-mark text-white d-inline-block mb-3" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a>
        <p class="small">Everyday tech, chosen carefully. Phones, wearables, audio and accessories — delivered fast, backed by a real warranty.</p>
      </div>
      <div class="col-lg-2 col-6">
        <h6>Shop</h6>
        <ul class="list-unstyled small">
          <li class="mb-2"><a href="./shop.php">All Products</a></li>
          <li class="mb-2"><a href="cart.php">Cart</a></li>
          <li class="mb-2"><a href="checkout.php">Checkout</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-6">
        <h6>Company</h6>
        <ul class="list-unstyled small">
          <li class="mb-2"><a href="about.php">About Us</a></li>
          <li class="mb-2"><a href="blog.php">Blog</a></li>
          <li class="mb-2"><a href="about.php#contact">Contact</a></li>
        </ul>
      </div>
      <div class="col-lg-4">
        <h6>Contact</h6>
        <p class="small mb-1">Questions? <a href="mailto:hello@Larry J Gadjets.example">ugwuanyinelson46@gmail.com</a></p>
        <p class="small">Support line: <a href="tel:+15551234567">+2349043855373</a></p>
      </div>
    </div>
    <div class="fine-print d-flex flex-wrap justify-content-between">
      <span>© 2026 Larry J Gadjets. All rights reserved.</span>
      <span>Secure checkout · Visa · Mastercard · PayPal</span>
    </div>
  </div>
</footer>


<script src="bootstrap.min.js"></script>
<script src="cart.js"></script>
<script>
document.addEventListener("cart:item-added", function (event) {
  const existing = document.getElementById("blogCartNotice");
  if (existing) existing.remove();

  const notice = document.createElement("div");
  notice.id = "blogCartNotice";
  notice.className = "position-fixed top-0 end-0 m-3 alert alert-success shadow-sm";
  notice.style.zIndex = "1055";
  notice.textContent = event.detail.name + " added to your cart.";
  document.body.appendChild(notice);

  setTimeout(function () {
    notice.remove();
  }, 2500);
});

const chips = document.querySelectorAll("#categoryChips .chip");
const postItems = document.querySelectorAll(".post-item");
const noPosts = document.getElementById("noPosts");

chips.forEach((chip) => {
  chip.addEventListener("click", () => {
    chips.forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");

    const cat = chip.dataset.cat;
    let visibleCount = 0;

    postItems.forEach((item) => {
      const show = cat === "all" || item.dataset.cat === cat;
      item.classList.toggle("d-none", !show);
      if (show) visibleCount++;
    });

    noPosts.classList.toggle("d-none", visibleCount > 0);
  });
});
</script>

<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>

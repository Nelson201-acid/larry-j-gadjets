<?php
require_once "header.php";
require_once "shop_data.php";

if (!isset($_SESSION['id']) || strtolower(trim((string)($_SESSION['role'] ?? ''))) !== 'admin') {
    header("Location: login.php");
    exit();
}

$msg = "";

$check = mysqli_query($conn, "SHOW COLUMNS FROM post LIKE 'description'");
if ($check && mysqli_num_rows($check) === 0) {
    mysqli_query($conn, "ALTER TABLE post ADD description TEXT NULL AFTER title");
}

$check = mysqli_query($conn, "SHOW COLUMNS FROM post LIKE 'images'");
if ($check && mysqli_num_rows($check) === 0) {
    mysqli_query($conn, "ALTER TABLE post ADD images TEXT NULL AFTER image");
}

$check = mysqli_query($conn, "SHOW COLUMNS FROM post LIKE 'front_image'");
if ($check && mysqli_num_rows($check) === 0) {
    mysqli_query($conn, "ALTER TABLE post ADD front_image VARCHAR(255) NULL AFTER image");
}

$check = mysqli_query($conn, "SHOW COLUMNS FROM post LIKE 'back_image'");
if ($check && mysqli_num_rows($check) === 0) {
    mysqli_query($conn, "ALTER TABLE post ADD back_image VARCHAR(255) NULL AFTER front_image");
}

function uploadSingleProductImage($fieldName, $number = 0)
{
    if (!isset($_FILES[$fieldName])) return '';

    $file = $_FILES[$fieldName];
    $error = is_array($file['error']) ? ($file['error'][$number] ?? UPLOAD_ERR_NO_FILE) : $file['error'];
    if ($error !== UPLOAD_ERR_OK) return '';

    $oldName = is_array($file['name']) ? ($file['name'][$number] ?? '') : $file['name'];
    $tempName = is_array($file['tmp_name']) ? ($file['tmp_name'][$number] ?? '') : $file['tmp_name'];
    if ($oldName === '' || $tempName === '' || !is_uploaded_file($tempName)) return '';

    $type = mime_content_type($tempName);
    if ($type === false || strpos($type, 'image/') !== 0) return '';

    $extension = strtolower(pathinfo($oldName, PATHINFO_EXTENSION));
    if (!in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) return '';

    $folder = __DIR__ . "/../assets/image/";
    if (!is_dir($folder)) return '';

    $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($oldName));
    $safeName = $safeName !== '' ? $safeName : ('product.' . $extension);
    $newName = time() . '_' . bin2hex(random_bytes(4)) . '_' . $safeName;

    return move_uploaded_file($tempName, $folder . $newName) ? $newName : '';
}

function uploadProductImages($fieldName)
{
    $savedImages = [];
    if (!isset($_FILES[$fieldName]) || !is_array($_FILES[$fieldName]['name'])) return $savedImages;

    $total = count($_FILES[$fieldName]['name']);
    for ($number = 0; $number < $total; $number++) {
        $image = uploadSingleProductImage($fieldName, $number);
        if ($image !== '') $savedImages[] = $image;
    }
    return $savedImages;
}

function deleteProductImage($imageName)
{
    $imageName = basename(str_replace('\\', '/', (string)$imageName));

    if ($imageName === '') {
        return;
    }

    $filePath = __DIR__ . "/../assets/image/" . $imageName;

    if (is_file($filePath)) {
        @unlink($filePath);
    }
}

$countResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM post");
$countRow = $countResult ? mysqli_fetch_assoc($countResult) : null;
$totalPosts = ((int)($countRow['total'] ?? 0) > 0) ? 1 : 0;

$orderResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders");
$orderRow = $orderResult ? mysqli_fetch_assoc($orderResult) : null;
$totalOrders = (int)($orderRow['total'] ?? 0);

if (isset($_GET['delete'])) {

    $deleteId = (int)$_GET['delete'];

    if ($deleteId > 0) {

        $stmt = mysqli_prepare(
            $conn,
            "SELECT image, front_image, back_image, images FROM post WHERE id = ? LIMIT 1"
        );

        $oldImages = [];

        if ($stmt) {

            mysqli_stmt_bind_param($stmt, "i", $deleteId);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $oldPost = $result ? mysqli_fetch_assoc($result) : null;

            mysqli_stmt_close($stmt);

            if ($oldPost) {

                if (!empty($oldPost['image'])) {
                    $oldImages[] = $oldPost['image'];
                }

                if (!empty($oldPost['front_image'])) {
                    $oldImages[] = $oldPost['front_image'];
                }

                if (!empty($oldPost['back_image'])) {
                    $oldImages[] = $oldPost['back_image'];
                }

                if (!empty($oldPost['images'])) {

                    $decodedImages = json_decode(
                        $oldPost['images'],
                        true
                    );

                    if (is_array($decodedImages)) {
                        $oldImages = array_merge(
                            $oldImages,
                            $decodedImages
                        );
                    }
                }

                $stmt = mysqli_prepare(
                    $conn,
                    "DELETE FROM post WHERE id = ?"
                );

                if ($stmt) {

                    mysqli_stmt_bind_param(
                        $stmt,
                        "i",
                        $deleteId
                    );

                    if (mysqli_stmt_execute($stmt)) {

                        mysqli_stmt_close($stmt);

                        $oldImages = array_unique($oldImages);

                        foreach ($oldImages as $oldImage) {
                            deleteProductImage($oldImage);
                        }

                        $msg = "<div class='alert alert-success'>Product deleted successfully.</div>";
                        $totalPosts--;

                    } else {

                        mysqli_stmt_close($stmt);

                        $msg = "<div class='alert alert-danger'>Product could not be deleted.</div>";
                    }
                }
            } else {
                $msg = "<div class='alert alert-danger'>Product not found.</div>";
            }
        }
    }
}

if (isset($_POST['publish'])) {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $front = uploadSingleProductImage('front_image');
    $backImages = uploadProductImages('back_images');
    $images = array_values(array_unique(array_filter(array_merge([$front], $backImages))));

    if ($name === '') {
        $msg = "<div class='alert alert-danger'>Please enter the product name.</div>";
    } elseif ($description === '') {
        $msg = "<div class='alert alert-danger'>Please enter the product description.</div>";
    } elseif ($price === '' || !is_numeric($price) || (float)$price < 0) {
        $msg = "<div class='alert alert-danger'>Please enter a valid price.</div>";
    } elseif ($front === '') {
        $msg = "<div class='alert alert-danger'>Please choose a front picture.</div>";
    } elseif (!$backImages) {
        $msg = "<div class='alert alert-danger'>Please choose at least one back picture.</div>";
    } else {
        $price = (float)$price;
        $back = $backImages[0];
        $allImages = json_encode($images, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $newPostId = latestCreatePost($conn, [
            'title' => $name,
            'description' => $description,
            'price' => $price,
            'image' => $front,
            'front_image' => $front,
            'back_image' => $back,
            'images' => $allImages
        ]);

        if ($newPostId > 0) {
            $oldRows = mysqli_query($conn, "SELECT id, image, front_image, back_image, images FROM post WHERE id <> " . (int)$newPostId);
            if ($oldRows) {
                while ($oldRow = mysqli_fetch_assoc($oldRows)) {
                    $oldNames = [$oldRow['image'] ?? '', $oldRow['front_image'] ?? '', $oldRow['back_image'] ?? ''];
                    $saved = json_decode((string)($oldRow['images'] ?? ''), true);
                    if (is_array($saved)) $oldNames = array_merge($oldNames, $saved);
                    foreach (array_unique($oldNames) as $oldName) deleteProductImage($oldName);
                }
            }
            mysqli_query($conn, "DELETE FROM post WHERE id <> " . (int)$newPostId);
            $totalPosts = 1;
            $msg = "<div class='alert alert-success'>Latest Product saved successfully.</div>";
        } else {
            foreach ($images as $image) deleteProductImage($image);
            $msg = "<div class='alert alert-danger'>Product could not be saved.</div>";
        }
    }

    if ($msg !== '' && isset($images) && strpos($msg, 'successfully') === false) {
        foreach ($images as $image) deleteProductImage($image);
    }
}

if (isset($_POST['update'])) {
    $editId = (int)($_POST['edit_id'] ?? 0);
    $name = trim($_POST['edit_name'] ?? '');
    $description = trim($_POST['edit_description'] ?? '');
    $price = trim($_POST['edit_price'] ?? '');

    if ($editId <= 0) {
        $msg = "<div class='alert alert-danger'>Invalid product.</div>";
    } elseif ($name === '' || $description === '') {
        $msg = "<div class='alert alert-danger'>Please fill in all product details.</div>";
    } elseif ($price === '' || !is_numeric($price) || (float)$price < 0) {
        $msg = "<div class='alert alert-danger'>Please enter a valid price.</div>";
    } else {
        $stmt = mysqli_prepare($conn, "SELECT image, front_image, back_image, images FROM post WHERE id = ? LIMIT 1");
        $oldPost = null;
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $editId);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $oldPost = $result ? mysqli_fetch_assoc($result) : null;
            mysqli_stmt_close($stmt);
        }

        if (!$oldPost) {
            $msg = "<div class='alert alert-danger'>Product not found.</div>";
        } else {
            $oldImages = [$oldPost['image'] ?? '', $oldPost['front_image'] ?? '', $oldPost['back_image'] ?? ''];
            $saved = json_decode((string)($oldPost['images'] ?? ''), true);
            if (is_array($saved)) $oldImages = array_merge($oldImages, $saved);
            $oldImages = array_values(array_unique(array_filter(array_map(function ($image) {
                return basename(str_replace('\\', '/', (string)$image));
            }, $oldImages))));

            $keepImages = $_POST['keep_images'] ?? $oldImages;
            if (!is_array($keepImages)) $keepImages = [];
            $kept = array_values(array_filter($oldImages, function ($image) use ($keepImages) {
                return in_array($image, $keepImages, true);
            }));

            $newFront = uploadSingleProductImage('edit_front_image');
            $newBack = uploadProductImages('edit_back_images');

            $oldFront = basename(str_replace('\\', '/', (string)($oldPost['front_image'] ?? $oldPost['image'] ?? '')));
            if ($newFront !== '') {
                $kept = array_values(array_filter($kept, function ($image) use ($oldFront) {
                    return $image !== $oldFront;
                }));
                array_unshift($kept, $newFront);
            }

            $finalImages = array_values(array_unique(array_merge($kept, $newBack)));
            $frontImage = $finalImages[0] ?? '';
            $backImage = $finalImages[1] ?? '';

            if ($frontImage === '' || $backImage === '') {
                foreach (array_merge([$newFront], $newBack) as $image) if ($image) deleteProductImage($image);
                $msg = "<div class='alert alert-danger'>Keep or add a front and a back picture.</div>";
            } else {
                $allImages = json_encode($finalImages, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                $priceValue = (float)$price;
                $ok = latestUpdatePost($conn, $editId, [
                    'title' => $name,
                    'description' => $description,
                    'price' => $priceValue,
                    'image' => $frontImage,
                    'front_image' => $frontImage,
                    'back_image' => $backImage,
                    'images' => $allImages
                ]);

                if ($ok) {
                    foreach ($oldImages as $oldImage) if (!in_array($oldImage, $finalImages, true)) deleteProductImage($oldImage);
                    $msg = "<div class='alert alert-success'>Product updated successfully.</div>";
                } else {
                    foreach (array_merge([$newFront], $newBack) as $image) if ($image) deleteProductImage($image);
                    $msg = "<div class='alert alert-danger'>Product could not be updated.</div>";
                }
            }
        }
    }
}

/*
   Get product selected for editing.
*/
$editPost = null;

if (isset($_GET['edit'])) {

    $editId = (int)$_GET['edit'];

    if ($editId > 0) {

        $stmt = mysqli_prepare(
            $conn,
            "SELECT id, title, description, price, image, front_image, back_image, images
             FROM post
             WHERE id = ?
             LIMIT 1"
        );

        if ($stmt) {

            mysqli_stmt_bind_param($stmt, "i", $editId);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $editPost = $result ? mysqli_fetch_assoc($result) : null;

            mysqli_stmt_close($stmt);
        }
    }
}

/*
   Get all products for the table.
*/
$posts = mysqli_query(
    $conn,
    "SELECT id, title, description, price, image, front_image, back_image, images
     FROM post
     ORDER BY id DESC
     LIMIT 1"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Latest Product - Larry J Gadjets</title>

    <link rel="stylesheet" href="style.css">

    <link
        href="../bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <style>
        body {
            background: #f4f7fb;
        }

        .content {
            width: 100%;
        }

        .topbar {
            border-bottom: 1px solid #e8edf3;
        }

        .box {
            border: 0;
            border-radius: 20px;
        }

        .box-head {
            background: linear-gradient(135deg, #0d6efd, #174ea6);
            color: white;
            border-radius: 20px 20px 0 0;
        }

        .form-control {
            min-height: 48px;
        }

        textarea.form-control {
            min-height: 150px;
        }

        .image-help {
            font-size: 13px;
            color: #6b7280;
        }

        .stat-box {
            border: 0;
            border-radius: 18px;
        }

        .product-table {
            vertical-align: middle;
        }

        .product-image {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            background: #f8f9fa;
        }

        .description-cell {
            min-width: 230px;
            max-width: 350px;
            white-space: normal;
            word-break: break-word;
        }

        .action-btn {
            min-width: 90px;
        }
    </style>
</head>

<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>


<div class="d-flex">

    <?php require_once "sidebar.php"; ?>

    <div class="content flex-grow-1">

        <nav class="navbar bg-white px-4 py-3 topbar">

            <div class="d-flex align-items-center gap-3">

                <button
                    type="button"
                    class="btn btn-primary d-md-none"
                    onclick="toggleSidebar()"
                >
                    <i class="bi bi-list"></i>
                </button>

                <div>
                    <h4 class="mb-1">Manage Latest Product</h4>
                    <div class="small text-muted">
                        Add, edit and delete the latest product
                    </div>
                </div>

            </div>

        </nav>

        <main class="container-fluid py-4">

            <!-- STATISTICS -->

            <div class="row g-4 mb-4 justify-content-center">

                <div class="col-md-4">

                    <div class="card stat-box shadow-sm h-100">

                        <div class="card-body p-4">

                            <div class="text-muted small">
                                LATEST PRODUCT
                            </div>

                            <div class="fs-2 fw-bold">
                                <?= $totalPosts ?>
                            </div>

                        </div>

                    </div>

                </div>

                <div class="col-md-4">

                    <div class="card stat-box shadow-sm h-100">

                        <div class="card-body p-4">

                            <div class="text-muted small">
                                TOTAL ORDERS
                            </div>

                            <div class="fs-2 fw-bold">
                                <?= $totalOrders ?>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <?= $msg ?>

            <!-- EDIT PRODUCT -->

            <?php if ($editPost): ?>

                <div class="card box shadow-sm mb-4">

                    <div class="box-head p-4">

                        <h3 class="fw-bold mb-1">
                            Edit Product
                        </h3>

                        <div class="text-white-50">
                            Update the selected product.
                        </div>

                    </div>

                    <div class="card-body p-4">

                        <form
                            method="post"
                            enctype="multipart/form-data"
                        >

                            <input
                                type="hidden"
                                name="edit_id"
                                value="<?= (int)$editPost['id'] ?>"
                            >

                            <div class="row g-4">

                                <div class="col-md-6">

                                    <label class="form-label fw-semibold">
                                        Product Name
                                    </label>

                                    <input
                                        type="text"
                                        name="edit_name"
                                        class="form-control"
                                        maxlength="100"
                                        required
                                        value="<?= htmlspecialchars($editPost['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                    >

                                </div>

                                <div class="col-md-6">

                                    <label class="form-label fw-semibold">
                                        Price (₦)
                                    </label>

                                    <input
                                        type="number"
                                        name="edit_price"
                                        class="form-control"
                                        min="0"
                                        step="0.01"
                                        required
                                        value="<?= htmlspecialchars($editPost['price'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                    >

                                </div>

                                <div class="col-12">

                                    <label class="form-label fw-semibold">
                                        Product Description
                                    </label>

                                    <textarea
                                        name="edit_description"
                                        class="form-control"
                                        required
                                    ><?= htmlspecialchars($editPost['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>

                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">New Front Picture</label>
                                    <input type="file" name="edit_front_image" class="form-control" accept="image/*">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">New Back Pictures</label>
                                    <input id="postEditBackImages" type="file" name="edit_back_images[]" class="form-control" accept="image/*" multiple>
                                    <div id="postEditBackImageList" class="image-help mt-2"></div>
                                </div>

                                <div class="col-12">

                                    <div class="d-flex gap-2 flex-wrap">

                                        <button
                                            type="submit"
                                            name="update"
                                            class="btn btn-primary px-4"
                                        >
                                            <i class="bi bi-save me-1"></i>
                                            Update Product
                                        </button>

                                        <a
                                            href="post.php"
                                            class="btn btn-light border px-4"
                                        >
                                            Cancel
                                        </a>

                                    </div>

                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            <?php endif; ?>

            <!-- CREATE PRODUCT -->

            <div class="card box shadow-sm mb-4">

                <div class="box-head p-4 p-md-5">

                    <h2 class="fw-bold mb-2">
                        Create Product
                    </h2>

                    <p class="mb-0 text-white-50">
                        Fill in the product name, description, price, front view and back view pictures.
                    </p>

                </div>

                <div class="card-body p-4 p-md-5">

                    <form
                        method="post"
                        enctype="multipart/form-data"
                    >

                        <div class="mb-4">

                            <label class="form-label fw-semibold">
                                Product Name
                            </label>

                            <input
                                type="text"
                                name="name"
                                class="form-control"
                                placeholder="Example: iPhone 13"
                                maxlength="100"
                                required
                            >

                        </div>

                        <div class="mb-4">

                            <label class="form-label fw-semibold">
                                Product Description
                            </label>

                            <textarea
                                name="description"
                                class="form-control"
                                placeholder="Tell customers about this product..."
                                required
                            ></textarea>

                        </div>

                        <div class="mb-4">

                            <label class="form-label fw-semibold">
                                Price (₦)
                            </label>

                            <input
                                type="number"
                                name="price"
                                class="form-control"
                                placeholder="Example: 150000"
                                min="0"
                                step="0.01"
                                required
                            >

                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Front Picture</label>
                            <input type="file" name="front_image" class="form-control" accept="image/*" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold">Back Pictures</label>
                            <input id="postBackImages" type="file" name="back_images[]" class="form-control" accept="image/*" multiple required>
                            <div id="postBackImageList" class="image-help mt-2"></div>
                        </div>

                        <div class="d-flex gap-2 flex-wrap">

                            <button
                                type="submit"
                                name="publish"
                                class="btn btn-primary px-4"
                            >
                                <i class="bi bi-check-circle me-1"></i>
                                Save Product
                            </button>

                            <button
                                type="reset"
                                class="btn btn-light border px-4"
                            >
                                Clear Form
                            </button>

                        </div>

                    </form>

                </div>

            </div>

            <!-- POST TABLE -->

            <div class="card box shadow-sm">

                <div class="card-header bg-white p-4 border-0">

                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                        <div>

                            <h3 class="fw-bold mb-1">
                                Latest Product Table
                            </h3>

                            <div class="small text-muted">
                                Only the newest product is shown here with its pictures
                            </div>

                        </div>

                        <span class="badge bg-primary fs-6">
                            <?= $totalPosts ?> Latest Product
                        </span>

                    </div>

                </div>

                <div class="card-body p-0">

                    <div class="table-responsive">

                        <table class="table table-hover mb-0 product-table">

                            <thead class="table-light">

                                <tr>

                                    <th class="px-4">
                                        ID
                                    </th>

                                    <th>
                                        Images
                                    </th>

                                    <th>
                                        Product
                                    </th>

                                    <th>
                                        Description
                                    </th>

                                    <th>
                                        Price
                                    </th>

                                    <th class="text-center">
                                        Actions
                                    </th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php if ($posts && mysqli_num_rows($posts) > 0): ?>

                                    <?php while ($post = mysqli_fetch_assoc($posts)): ?>

                                        <tr>

                                            <td class="px-4 fw-semibold">
                                                <?= (int)$post['id'] ?>
                                            </td>
                                        <?php
                                        $postImages = json_decode((string)($post['images'] ?? ''), true);
                                        if (!is_array($postImages)) $postImages = [];
                                        $firstPostImage = basename(str_replace('\\', '/', (string)($postImages[0] ?? ($post['image'] ?? ''))));
                                        ?>
                                        <td>
                                            <?php if ($firstPostImage !== ''): ?>
                                                <img src="<?= htmlspecialchars('../assets/image/' . $firstPostImage, ENT_QUOTES, 'UTF-8') ?>" alt="Product" class="product-image">
                                            <?php else: ?>
                                                <span class="text-muted small">No image</span>
                                            <?php endif; ?>
                                            <div class="small text-muted mt-1"><?= count($postImages) ?> picture(s)</div>
                                        </td>

                                            <td>

                                                <div class="fw-semibold">
                                                    <?= htmlspecialchars($post['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                                                </div>

                                            </td>

                                            <td class="description-cell">

                                                <?= nl2br(
                                                    htmlspecialchars(
                                                        $post['description'] ?? '',
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    )
                                                ) ?>

                                            </td>

                                            <td class="fw-semibold">

                                                ₦<?= number_format(
                                                    (float)($post['price'] ?? 0),
                                                    2
                                                ) ?>

                                            </td>

                                            <td>

                                                <div class="d-flex justify-content-center gap-2 flex-wrap">

                                                    <a
                                                        href="post.php?edit=<?= (int)$post['id'] ?>"
                                                        class="btn btn-sm btn-primary action-btn"
                                                    >
                                                        <i class="bi bi-pencil-square me-1"></i>
                                                        Edit
                                                    </a>

                                                    <a
                                                        href="post.php?delete=<?= (int)$post['id'] ?>"
                                                        class="btn btn-sm btn-danger action-btn"
                                                        onclick="return confirm('Are you sure you want to delete this product?');"
                                                    >
                                                        <i class="bi bi-trash me-1"></i>
                                                        Delete
                                                    </a>

                                                </div>

                                            </td>

                                        </tr>

                                    <?php endwhile; ?>

                                <?php else: ?>

                                    <tr>

                                        <td
                                            colspan="6"
                                            class="text-center py-5 text-muted"
                                        >
                                            No products have been added yet.
                                        </td>

                                    </tr>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </main>

    </div>

</div>

<script>
const sidebar = document.querySelector('.sidebar');
if (sidebar) {
    window.toggleSidebar = function () {
        sidebar.classList.toggle('show');
    };
}

const imageBox = document.getElementById('postBackImages');
const imageList = document.getElementById('postBackImageList');
let chosenImages = new DataTransfer();

if (imageBox) {
    imageBox.addEventListener('click', function () {
        this.value = '';
    });

    imageBox.addEventListener('change', function () {
        for (const image of this.files) {
            const alreadyAdded = Array.from(chosenImages.files).some(function (oldImage) {
                return oldImage.name === image.name && oldImage.size === image.size && oldImage.lastModified === image.lastModified;
            });

            if (!alreadyAdded) chosenImages.items.add(image);
        }

        this.files = chosenImages.files;

        if (imageList) {
            imageList.textContent = chosenImages.files.length + ' picture(s) selected.';
        }
    });
}
</script>


<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>
<?php
if (!isset($conn) || !($conn instanceof mysqli)) {
    die('The shop database connection is missing.');
}

@mysqli_select_db($conn, 'ecommerce');

function latestCreatePost($conn, $data)
{
    $sql = "INSERT INTO post (title, description, price, image, front_image, back_image, images) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return 0;
    mysqli_stmt_bind_param($stmt, 'ssdssss', $data['title'], $data['description'], $data['price'], $data['image'], $data['front_image'], $data['back_image'], $data['images']);
    $ok = mysqli_stmt_execute($stmt);
    $id = $ok ? mysqli_insert_id($conn) : 0;
    mysqli_stmt_close($stmt);
    return (int)$id;
}

function latestUpdatePost($conn, $id, $data)
{
    $sql = "UPDATE post SET title=?, description=?, price=?, image=?, front_image=?, back_image=?, images=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;
    mysqli_stmt_bind_param($stmt, 'ssdssssi', $data['title'], $data['description'], $data['price'], $data['image'], $data['front_image'], $data['back_image'], $data['images'], $id);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function shopEnsureTable($conn)
{
    $sql = "CREATE TABLE IF NOT EXISTS shop (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(150) NOT NULL,
        category VARCHAR(100) NOT NULL,
        price DECIMAL(14,2) NOT NULL DEFAULT 0.00,
        old_price DECIMAL(14,2) NULL DEFAULT NULL,
        description TEXT NULL,
        badge VARCHAR(30) NULL DEFAULT NULL,
        image VARCHAR(500) NULL,
        front_image VARCHAR(500) NULL,
        back_image VARCHAR(500) NULL,
        right_image VARCHAR(500) NULL,
        left_image VARCHAR(500) NULL,
        images LONGTEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY category_index (category),
        KEY created_index (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    if (!mysqli_query($conn, $sql)) {
        return false;
    }

    $newColumns = [
        'front_image' => "ALTER TABLE shop ADD front_image VARCHAR(500) NULL AFTER image",
        'back_image' => "ALTER TABLE shop ADD back_image VARCHAR(500) NULL AFTER front_image",
        'right_image' => "ALTER TABLE shop ADD right_image VARCHAR(500) NULL AFTER back_image",
        'left_image' => "ALTER TABLE shop ADD left_image VARCHAR(500) NULL AFTER right_image",
        'images' => "ALTER TABLE shop ADD images LONGTEXT NULL AFTER left_image"
    ];
    foreach ($newColumns as $column => $alterSql) {
        $columnCheck = mysqli_query($conn, "SHOW COLUMNS FROM shop LIKE '$column'");
        if ($columnCheck && mysqli_num_rows($columnCheck) === 0) {
            @mysqli_query($conn, $alterSql);
        }
    }

    $seedTable = "CREATE TABLE IF NOT EXISTS shop_seed_status (
        id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        seeded TINYINT(1) NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    mysqli_query($conn, $seedTable);

    shopAddOldProducts($conn);

    return true;
}

function shopAddOldProducts($conn)
{
    $status = mysqli_query($conn, "SELECT seeded FROM shop_seed_status WHERE id = 1 LIMIT 1");
    $statusRow = $status ? mysqli_fetch_assoc($status) : null;
    if ($statusRow && (int)$statusRow['seeded'] === 1) return;

    $countResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM shop");
    $countRow = $countResult ? mysqli_fetch_assoc($countResult) : null;
    $hasProducts = (int)($countRow['total'] ?? 0) > 0;

    if ($hasProducts) {
        mysqli_query($conn, "INSERT INTO shop_seed_status (id, seeded) VALUES (1, 1) ON DUPLICATE KEY UPDATE seeded = 1");
        return;
    }
    $oldProducts = [
        ['Iphone 10','Mobile Phones',980,null,'A dependable everyday smartphone, checked and ready to go — backed by a full manufacturer warranty and fast shipping.','New','images/product-item1.jpg','images/iphone 10 fg.jpg','images/product-item1.jpg','','',[]],
        ['Iphone 11','Mobile Phones',1100,null,'A dependable everyday smartphone, checked and ready to go — backed by a full manufacturer warranty and fast shipping.',null,'images/product-item2.jpg','images/ipone 11 ff.jpg','images/iphone 11 b.jpg','','',[]],
        ['Iphone 8','Mobile Phones',780,null,'A dependable everyday smartphone, checked and ready to go — backed by a full manufacturer warranty and fast shipping.',null,'images/product-item3.jpg','./images/ipone 8 front.jpg','./images/ipone 8 p.jpg','','',[]],
        ['Iphone 13','Mobile Phones',1500,null,'A dependable everyday smartphone, checked and ready to go — backed by a full manufacturer warranty and fast shipping.','New','images/iphone 13 f.jpg','images/ipone 13 a.jpg','images/iphone 13 bb.jpg','','',[]],
        ['Iphone 12','Mobile Phones',1300,null,'A dependable everyday smartphone, checked and ready to go — backed by a full manufacturer warranty and fast shipping.',null,'images/product-item5.jpg','./images/iphone 12 f.jpg','./images/iphone 12 b.jpg','','',[]],
        ['Pulse Watch SE','Smart Watches',199,null,'Track your day, stay connected, and keep your phone in your pocket a little longer with this smart watch.','New','./images/smart watch.jpg','./images/smart watch.jpg','./images/white watch 2.jpeg','','',[]],
        ['Pulse Watch Titanium','Smart Watches',349,399,'Track your day, stay connected, and keep your phone in your pocket a little longer with this smart watch.','Sale','./images/titanium watch.jpg','./images/titanium watch.jpg','./images/white watch back.jpeg','','',[]],
        ['Fit Band 3','Smart Watches',79,null,'Track your day, stay connected, and keep your phone in your pocket a little longer with this smart watch.',null,'./images/band.jpg','./images/band.jpg','./images/band b.jpg','','',[]],
        ['Echo Bass Over-Ear','Headphones',159,null,'Tuned for clear, comfortable listening whether you\'re commuting, working, or just tuning out for a while.',null,'./images/airpods.jpg','./images/jbl b.jpg','./images/buds b.jpg','','',[]],
        ['Premium sound buds','Headphones',129,159,'Tuned for clear, comfortable listening whether you\'re commuting, working, or just tuning out for a while.','Sale','./images/air2.jpg','./images/air2.jpg','./images/jbl n.jpg','','',[]],
        ['Studio One Headphones','Headphones',249,null,'Tuned for clear, comfortable listening whether you\'re commuting, working, or just tuning out for a while.','New','./images/headphonr f.jpg','./images/headphonr f.jpg','./images/head b.jpg','','',[]],
        ['60W GaN Fast Charger','Accessories',29,null,'A small addition that makes a real difference in your everyday setup.',null,'./images/charger front.jpg','./images/charger front.jpg','./images/charger b.jpg','','',[]],
        ['Braided USB-C Cable 2m','Accessories',15,null,'A small addition that makes a real difference in your everyday setup.',null,'./images/usb.jpg','./images/usb.jpg','./images/cord b.jpg','','',[]],
        ['MagSnap Wireless Pad','Accessories',39,49,'A small addition that makes a real difference in your everyday setup.','Sale','./images/wireless.jpg','./images/wire2.jpeg','./images/wire3.jpeg','','',[]],
        ['ViewPro 27" QHD Monitor','Monitors',279,null,'A crisp, spacious display built for work, creative projects, or gaming.',null,'./images/monitor1.jpg','./images/monitor1.jpg','./images/moni 4.jpg','','',[]],
        ['ViewPro 34" Ultrawide','Monitors',549,629,'A crisp, spacious display built for work, creative projects, or gaming.','Sale','./images/monitor2.jpg','./images/monitor2.jpg','./images/moni 2.jpeg','','',[]],
        ['Boom Mini Bluetooth Speaker','Speakers',59,null,'Room-filling sound in a compact footprint, built for wherever the day takes it.','New','./images/mini spk.jpg','./images/mini spk.jpg','./images/mini back.jpeg','','',[]],
        ['Boom Max Party Speaker','Speakers',199,null,'Room-filling sound in a compact footprint, built for wherever the day takes it.',null,'./images/big spk.jpg','./images/big spk.jpg','./images/spk back.jpeg','','',[]]
    ];

    $stmt = mysqli_prepare($conn, "INSERT INTO shop (name, category, price, old_price, description, badge, image, front_image, back_image, right_image, left_image, images) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        return;
    }

    foreach ($oldProducts as $product) {
        $name = $product[0];
        $category = $product[1];

        $find = mysqli_prepare($conn, "SELECT id FROM shop WHERE name = ? LIMIT 1");
        if ($find) {
            mysqli_stmt_bind_param($find, 's', $name);
            mysqli_stmt_execute($find);
            $findResult = mysqli_stmt_get_result($find);
            $alreadyThere = $findResult ? mysqli_fetch_assoc($findResult) : null;
            mysqli_stmt_close($find);
            if ($alreadyThere) continue;
        }
        $price = (float)$product[2];
        $oldPrice = $product[3] === null ? null : (float)$product[3];
        $description = $product[4];
        $badge = $product[5];
        $image = $product[6];
        $front = $product[7];
        $back = $product[8];
        $right = $product[9] ?? '';
        $left = $product[10] ?? '';
        $extra = $product[11] ?? [];
        $all = [];
        foreach (array_merge([$front, $back, $right, $left], $extra) as $one) {
            $one = shopNormalImage($one);
            if ($one !== '' && !in_array($one, $all, true)) $all[] = $one;
        }
        $images = json_encode($all, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        mysqli_stmt_bind_param($stmt, 'ssddssssssss', $name, $category, $price, $oldPrice, $description, $badge, $image, $front, $back, $right, $left, $images);
        mysqli_stmt_execute($stmt);
    }

    mysqli_stmt_close($stmt);
    mysqli_query($conn, "INSERT INTO shop_seed_status (id, seeded) VALUES (1, 1) ON DUPLICATE KEY UPDATE seeded = 1");
}

function shopCreateProduct($conn, $data)
{
    $sql = "INSERT INTO shop (name, category, price, old_price, description, badge, image, front_image, back_image, right_image, left_image, images) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;
    mysqli_stmt_bind_param(
        $stmt,
        'ssddssssssss',
        $data['name'], $data['category'], $data['price'], $data['old_price'],
        $data['description'], $data['badge'], $data['image'], $data['front_image'],
        $data['back_image'], $data['right_image'], $data['left_image'], $data['images']
    );
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function shopUpdateProduct($conn, $id, $data)
{
    $sql = "UPDATE shop SET name=?, category=?, price=?, old_price=?, description=?, badge=?, image=?, front_image=?, back_image=?, right_image=?, left_image=?, images=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;
    mysqli_stmt_bind_param(
        $stmt,
        'ssddssssssssi',
        $data['name'], $data['category'], $data['price'], $data['old_price'],
        $data['description'], $data['badge'], $data['image'], $data['front_image'],
        $data['back_image'], $data['right_image'], $data['left_image'], $data['images'], $id
    );
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function shopDeleteProduct($conn, $id)
{
    $stmt = mysqli_prepare($conn, "DELETE FROM shop WHERE id=?");
    if (!$stmt) return false;
    mysqli_stmt_bind_param($stmt, 'i', $id);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function shopNormalImage($path)
{
    return trim(str_replace('\\', '/', (string)$path));
}

function shopImages($row)
{
    $images = [];
    $saved = json_decode((string)($row['images'] ?? ''), true);

    foreach ([
        $row['front_image'] ?? '',
        $row['back_image'] ?? '',
        $row['right_image'] ?? '',
        $row['left_image'] ?? ''
    ] as $image) {
        $image = shopNormalImage($image);
        if ($image !== '' && !in_array($image, $images, true)) $images[] = $image;
    }

    if (is_array($saved)) {
        foreach ($saved as $image) {
            $image = shopNormalImage($image);
            if ($image !== '' && !in_array($image, $images, true)) $images[] = $image;
        }
    }

    $primary = shopNormalImage($row['image'] ?? '');
    if ($primary !== '' && !in_array($primary, $images, true)) $images[] = $primary;

    return $images;
}

function shopAllImages($row)
{
    return shopImages($row);
}

function shopImageUrl($path)
{
    $path = shopNormalImage($path);
    if ($path === '') return '';
    if (strpos($path, 'assets/image/') === 0) return '../' . $path;
    if (strpos($path, 'images/') === 0) return '../' . $path;
    if ($path[0] !== '/') return '../' . $path;
    return $path;
}

function shopPostImages($row)
{
    $images = shopImages($row);
    $final = [];

    foreach ($images as $image) {
        $image = shopNormalImage($image);
        if ($image === '') continue;

        if (strpos($image, 'assets/image/') !== 0 && strpos($image, 'images/') !== 0 && strpos($image, '/') === false) {
            $image = 'assets/image/' . basename($image);
        }

        if (!in_array($image, $final, true)) $final[] = $image;
    }

    return $final;
}

function shopGetAdminProducts($conn)
{
    $products = [];
    $result = mysqli_query($conn, "SELECT * FROM shop ORDER BY created_at DESC, id DESC");

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $row['all_images'] = shopImages($row);
            $products[] = $row;
        }
    }

    return $products;
}

function shopGetProducts($conn, $category = '', $sort = 'featured')
{
    $order = 'created_at DESC, id DESC';

    if ($sort === 'price-asc') {
        $order = 'price ASC, id ASC';
    } elseif ($sort === 'price-desc') {
        $order = 'price DESC, id ASC';
    } elseif ($sort === 'name-asc') {
        $order = 'name ASC, id ASC';
    }

    $products = [];

    if ($category !== '') {
        $stmt = mysqli_prepare($conn, "SELECT * FROM shop WHERE category = ? ORDER BY $order");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 's', $category);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $row['all_images'] = shopImages($row);
                    $products[] = $row;
                }
            }
            mysqli_stmt_close($stmt);
        }
    } else {
        $result = mysqli_query($conn, "SELECT * FROM shop ORDER BY $order");
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $row['all_images'] = shopImages($row);
                $products[] = $row;
            }
        }
    }

    return $products;
}

function shopGetCategories($conn)
{
    $categories = [];
    $result = mysqli_query($conn, "SELECT DISTINCT category FROM shop WHERE category <> '' ORDER BY category ASC");
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $categories[] = (string)$row['category'];
        }
    }
    return $categories;
}

function shopGetProduct($conn, $id)
{
    $id = (int)$id;
    if ($id < 1) return null;

    $stmt = mysqli_prepare($conn, "SELECT * FROM shop WHERE id = ? LIMIT 1");
    if (!$stmt) return null;

    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $product = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    if ($product) {
        $product['all_images'] = shopImages($product);
    }

    return $product;
}

function shopLatestPost($conn)
{
    $result = mysqli_query($conn, "SELECT * FROM post ORDER BY id DESC LIMIT 1");
    return $result ? (mysqli_fetch_assoc($result) ?: null) : null;
}

shopEnsureTable($conn);

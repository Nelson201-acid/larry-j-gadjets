-- Larry J Gadjets order status
-- New orders start as pending.
-- Admin changes them to approved.

USE ecommerce;

ALTER TABLE orders
ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'pending';

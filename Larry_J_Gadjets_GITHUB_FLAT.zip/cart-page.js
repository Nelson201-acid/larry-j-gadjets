/*
  Larry J Gadjets compatibility file.
  The real cart logic lives in cart.js.
  This small file only supports very old cart markup that used #cart-body.
*/
(function () {
  const body = document.getElementById("cart-body");
  if (!body || typeof window.getCart !== "function") return;

  function draw() {
    const cart = window.getCart();
    const grandTotal = cart.reduce((sum, item) => {
      return sum + (Number(item.price) || 0) * (Number(item.quantity) || 0);
    }, 0);

    body.innerHTML = cart.map((item) => `
      <tr>
        <td><img src="${item.image || ""}" width="80" alt=""></td>
        <td>${item.name || "Product"}</td>
        <td>${window.formatCurrency(item.price)}</td>
        <td>${item.quantity}</td>
        <td>${window.formatCurrency((Number(item.price) || 0) * (Number(item.quantity) || 0))}</td>
      </tr>
    `).join("");

    const total = document.getElementById("grand-total");
    if (total) total.textContent = window.formatCurrency(grandTotal);
  }

  document.addEventListener("DOMContentLoaded", draw);
})();

<?php 

require_once "./header.php";

$msg = "";

if(isset($_POST['register'])){

  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);
  $confirmPwd = mysqli_real_escape_string($conn, $_POST['confirmPwd']);
  $phone = mysqli_real_escape_string($conn, $_POST['phone']);
  $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/';
  $image = time() . '_' . basename($_FILES['image']['name']);
  $imgTmp = $_FILES['image']['tmp_name'];
  $imgFolder = __DIR__ . "/../assets/image/" . $image;

    if (move_uploaded_file($imgTmp, $imgFolder)) {
        $error = "Image uploaded successfully!".mysqli_error($conn);
        $message = "<div class='alert alert-danger'>$error</div>";
        } else {
        $error = "Upload failed!".mysqli_error($conn);
        $message = "<div class='alert alert-danger'>$error</div>";
    }

  if (strlen($username) >= 5) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
      if (preg_match($pattern, $password)) {
        if ($password == $confirmPwd) {
          if (strlen($phone) == 11) {

        //   $uniqe = "SELECT * FROM users WHERE phone = '$phone' ";
        //   $uniqe_exc = mysqli_query($conn, $uniqe);
        //   $row = mysqli_fetch_assoc($uniqe_exc);
        //   $check = $row == 0;
            
            //password hash
            $hash = password_hash($password, PASSWORD_DEFAULT);
            // INSERT INTO TABLE USERS
            $register = "INSERT INTO client (username, email, password, phone, image) VALUES ('$username', '$email', '$hash', '$phone', '$image')";

            $register_exc = mysqli_query($conn, $register);

            if ($register_exc) {
              header("location: login.php");
            } else {
              $msg = "<div class='alert alert-danger'>Account not created</div>";
            }
            

          } else {
            $msg = "<div class='alert alert-danger'>phone must be 11 digit</div>";
          }
          
        } else {
          $msg = "<div class='alert alert-danger'>Password not match</div>";
        }
        
      } else {
        $msg = "<div class='alert alert-danger'>password must contain a num, special chara,</div>";
      }
      
    } else {
      $msg = "<div class='alert alert-danger'>Invalid email</div>";
    }
    
  }else{
      $msg = "<div class='alert alert-danger'>Username must be 5 chara and above</div>";
  }

}
// else{
//     $msg = "<div class='alert alert-danger'>phone is in use</div>";
// }
?>
<body>
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="../images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>


<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-6">

            <div class="card shadow">

                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">
                        <i class="bi bi-person-plus-fill"></i>
                        Register User
                    </h3>
                    <div> <?= $msg ?> </div>
                </div>

                <div class="card-body">

                    <form action="" method="post" enctype="multipart/form-data" >

                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" placeholder="Enter username" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter email" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" placeholder="Enter phone number" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" id="password" class="form-control" placeholder="Enter password"  required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" name="confirmPwd" id="confirmPassword" class="form-control" placeholder="Confirm password" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Profile Photo</label>
                            <input type="file" name="image" id="photo" class="form-control" accept="image/*">
                            <img id="preview" class="img-thumbnail mt-3 d-none" width="120">
                        </div>
  <div class="text-center mt-4 d-flex">
                <div>
                        <button class="btn btn-primary" type="submit" name="register">
                            <i class="bi bi-person-check-fill"></i>
                            Register
                        </button>

                        <button type="reset" class="btn btn-secondary">
                            Reset
                        </button>
                       </div>  
            <p class="text-muted ms-3">
                Already have an account?
                <a href="login.php" class="text-decoration-none">
                    Login
                </a>
            </p>
        </div>
    
                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="script.js"></script>


<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>
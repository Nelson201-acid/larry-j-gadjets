<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
 require_once "dashboard/header.php";


$isLoggedIn = isset($_SESSION['username']);



require_once "shop_data.php";

$latest_posts = shopLatestPost($conn);
$products = shopGetProducts($conn, '', 'featured');

 ?>



<!DOCTYPE html>
<html>
  <head>
    <title>Larry J Gadjets </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
$webDataBase = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php')), '/') . '/';
?>
<base href="<?php echo htmlspecialchars($webDataBase, ENT_QUOTES, 'UTF-8'); ?>">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="shop-cart.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
  <style>
  html, body {
    overflow-x: hidden;
  }

  .site-header {
    width: 100%;
  }
  .home-product-card {
    width: 100%;
    height: 470px;
    margin: 0;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
  }
  .home-product-card .image-holder {
    height: 230px;
    flex-shrink: 0;
    overflow: hidden;
    background: #f6f6f6;
    position: relative;
  }
  .home-product-card .image-holder img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .home-product-card .cart-concern {
    position: static !important;
    width: 100%;
    padding: 12px 14px 0;
    margin: 0;
    opacity: 1 !important;
    visibility: visible !important;
    transform: none !important;
    z-index: 1;
  }
  .home-product-card .cart-concern .cart-button,
  .home-product-card .cart-concern .add-cart {
    width: 100%;
  }
  .home-product-card .cart-concern .add-cart {
    height: 46px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    white-space: nowrap;
  }
  .home-product-card .product-cat {
    min-height: 20px;
    margin-top: 12px !important;
  }
  .home-product-card .card-detail {
    gap: 10px;
    min-height: 70px;
  }
  .home-product-card .card-title {
    min-height: 44px;
    font-size: .98rem;
    line-height: 1.3;
    margin-bottom: 0;
    flex: 1;
  }
  .home-product-card .item-price {
    min-height: 44px;
    font-size: .92rem;
    white-space: nowrap;
    text-align: right;
  }
  .home-product-card > .mt-2 {
    margin-top: auto !important;
    padding-bottom: 14px;
  }
  .home-product-description {
    min-height: 42px;
    max-height: 42px;
    line-height: 1.4;
    overflow: hidden;
  }
  .home-section-title {
    margin-top: 34px;
  }
  .home-shop-products .swiper-slide,
  .home-latest-products .swiper-slide {
    height: auto;
  }
  /* The Latest Products box can grow when the description is long. */
  .home-latest-products {
    width: 100%;
    max-width: 520px;
  }

  .home-latest-products .home-product-card {
    height: auto;
    min-height: 0;
    padding-bottom: 18px;
  }

  .home-latest-products .latest-product-swiper,
  .home-latest-products .swiper-wrapper,
  .home-latest-products .swiper-slide {
    height: auto;
  }

  .home-latest-products .image-holder {
    height: 220px;
  }

  .home-latest-products .cart-concern .add-cart {
    height: 46px;
  }

  /* Never cut the product description. Let the card become taller. */
  .home-latest-products .home-product-description {
    min-height: 0;
    max-height: none;
    height: auto;
    overflow: visible;
    white-space: normal;
    overflow-wrap: anywhere;
    word-break: normal;
  }


  #header-nav .container-fluid,
  #header-nav .offcanvas-body {
    min-width: 0;
  }

  @media (max-width: 991.98px) {
    #header-nav .user-items {
      padding-left: 0 !important;
      margin-top: 15px;
    }

    #header-nav .user-items ul {
      justify-content: flex-start !important;
    }
  }

  @media (max-width: 575.98px) {
    .latest-post-image {
      height: 240px;
    }

  }

  .ljg-search-intro{padding:12px 0 18px;border-bottom:1px solid #eee;margin-bottom:18px}.ljg-search-intro span{display:block;font-size:12px;text-transform:uppercase;letter-spacing:1.5px;color:#dc1927;font-weight:700;margin-bottom:5px}.ljg-search-intro strong{display:block;font-size:18px;line-height:1.35;color:#222}.ljg-home-panel{padding:70px 0}.ljg-section-head{text-align:center;max-width:700px;margin:0 auto 36px}.ljg-section-head .eyebrow{display:inline-block;color:#dc1927;font-size:12px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px}.ljg-section-head h2{font-size:clamp(1.7rem,2.5vw,2.35rem);margin-bottom:10px}.ljg-section-head p{color:#707070;margin-bottom:0}.ljg-value-card{height:100%;padding:26px 22px;background:#fff;border:1px solid #ededed;border-radius:10px;box-shadow:0 8px 25px rgba(0,0,0,.04);transition:transform .2s ease,box-shadow .2s ease}.ljg-value-card:hover{transform:translateY(-4px);box-shadow:0 14px 35px rgba(0,0,0,.08)}.ljg-value-icon{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#fff0f1;color:#dc1927;font-weight:800;font-size:20px;margin-bottom:16px}.ljg-value-card h3{font-size:1rem;text-transform:uppercase;letter-spacing:.4px;margin-bottom:8px}.ljg-value-card p{font-size:.9rem;line-height:1.65;color:#777;margin-bottom:0}.ljg-steps{background:#f8f8f8}.ljg-step{height:100%;padding:24px 20px;background:#fff;border-radius:10px;border:1px solid #eee}.ljg-step-number{font-size:12px;font-weight:800;color:#fff;background:#dc1927;border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;margin-bottom:14px}.ljg-step h3{font-size:1rem;margin-bottom:7px}.ljg-step p{font-size:.88rem;color:#777;line-height:1.6;margin:0}.ljg-cta{background:#171717;color:#fff;border-radius:12px;padding:42px 38px;position:relative;overflow:hidden}.ljg-cta:after{content:"";position:absolute;width:240px;height:240px;border-radius:50%;background:rgba(220,25,39,.22);right:-80px;top:-100px}.ljg-cta h2,.ljg-cta p,.ljg-cta .btn{position:relative;z-index:1}.ljg-cta h2{font-size:clamp(1.5rem,2.5vw,2.2rem);margin-bottom:8px}.ljg-cta p{color:#ddd;max-width:650px;margin-bottom:20px}.ljg-faq .accordion-item{border:1px solid #eee!important;border-radius:8px!important;margin-bottom:10px;overflow:hidden}.ljg-faq .accordion-button{font-weight:600;box-shadow:none!important}.ljg-faq .accordion-button:not(.collapsed){color:#dc1927;background:#fff5f6}.ljg-faq .accordion-button:focus{box-shadow:none}@media(max-width:767px){.ljg-home-panel{padding:50px 0}.ljg-cta{padding:30px 22px}}


  .ljg-customer-carousel{background:#f8f8f8;}
  .ljg-carousel-intro{padding-right:18px;}
  .ljg-carousel-eyebrow{display:inline-block;color:#dc1927;font-size:12px;font-weight:800;letter-spacing:1.6px;margin-bottom:10px;}
  .ljg-carousel-intro h2{font-size:clamp(1.7rem,3vw,2.45rem);line-height:1.1;}
  .ljg-carousel-intro p{color:#6f6f6f;line-height:1.75;}
  .ljg-carousel-points{display:grid;gap:10px;color:#333;font-size:.92rem;}
  .ljg-carousel-points span{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;margin-right:8px;border-radius:50%;background:#dc1927;color:#fff;font-size:12px;font-weight:800;}
  .ljg-carousel-card{padding:34px 62px;border-radius:16px;background:#fff;border:1px solid #ededed;box-shadow:0 14px 40px rgba(0,0,0,.06);}
  .ljg-customer-slide{padding:8px 14px 10px;text-align:left;}
  .ljg-slide-top{display:flex;align-items:center;gap:15px;margin-bottom:20px;}
  .ljg-slide-icon{width:48px;height:48px;flex:0 0 48px;border-radius:12px;background:#dc1927;color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;letter-spacing:.5px;}
  .ljg-slide-label{font-size:11px;line-height:1.2;letter-spacing:1.35px;color:#dc1927;font-weight:800;margin-bottom:5px;}
  .ljg-slide-title{margin:0;color:#1d1d1d;font-size:1.55rem;line-height:1.2;}
  .ljg-slide-text{margin:0;max-width:650px;color:#676767;font-size:1rem;line-height:1.8;}
  .ljg-slide-footer{display:flex;align-items:center;justify-content:space-between;gap:15px;margin-top:24px;padding-top:16px;border-top:1px solid #ececec;font-size:.84rem;color:#444;}
  .ljg-slide-footer span{color:#999;white-space:nowrap;}
  .ljg-carousel-card .swiper-arrow{width:40px;height:40px;border-radius:50%;top:50%;margin-top:-20px;background:#fff;border:1px solid #dedede;box-shadow:0 6px 18px rgba(0,0,0,.08);z-index:5;cursor:pointer;}
  .ljg-carousel-card .swiper-arrow-prev{left:14px;}
  .ljg-carousel-card .swiper-arrow-next{right:14px;}
  .ljg-carousel-card .swiper-arrow svg{width:18px;height:18px;}
  .ljg-carousel-pagination{position:static;margin-top:18px;}
  .ljg-carousel-pagination .swiper-pagination-bullet{width:8px;height:8px;opacity:1;background:#d9d9d9;}
  .ljg-carousel-pagination .swiper-pagination-bullet-active{width:24px;border-radius:10px;background:#dc1927;}
  @media(max-width:991.98px){.ljg-carousel-intro{padding-right:0;}.ljg-carousel-card{padding:28px 52px;}}
  @media(max-width:575.98px){.ljg-carousel-card{padding:22px 42px;}.ljg-slide-title{font-size:1.18rem;}.ljg-slide-text{font-size:.92rem;line-height:1.7;}.ljg-slide-footer{font-size:.76rem;}.ljg-carousel-card .swiper-arrow{width:34px;height:34px;}.ljg-carousel-card .swiper-arrow-prev{left:8px;}.ljg-carousel-card .swiper-arrow-next{right:8px;}}
</style>
</head>
  <body data-user="<?php echo htmlspecialchars($_SESSION['username'] ?? 'guest', ENT_QUOTES, 'UTF-8'); ?>" data-user-id="<?php echo isset($_SESSION['id']) ? (int) $_SESSION['id'] : 0; ?>" data-authenticated="<?php echo isset($_SESSION['id']) ? '1' : '0'; ?>" data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" tabindex="0">
<div id="ljgPreloader" class="ljg-preloader" aria-label="Loading Larry J Gadjets" role="status">
  <div class="ljg-preloader-box">
    <img src="images/main-logo.png" alt="Larry J Gadjets" class="ljg-preloader-logo">
    <div class="ljg-preloader-track"><span></span></div>
    <p class="ljg-preloader-text">Loading Larry J Gadjets...</p>
  </div>
</div>

    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
      <symbol id="search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <title>Search</title>
        <path fill="currentColor" d="M19 3C13.488 3 9 7.488 9 13c0 2.395.84 4.59 2.25 6.313L3.281 27.28l1.439 1.44l7.968-7.969A9.922 9.922 0 0 0 19 23c5.512 0 10-4.488 10-10S24.512 3 19 3zm0 2c4.43 0 8 3.57 8 8s-3.57 8-8 8s-8-3.57-8-8s3.57-8 8-8z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="user" viewBox="0 0 16 16">
        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="cart" viewBox="0 0 16 16">
        <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="chevron-left" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="chevron-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="cart-outline" viewBox="0 0 16 16">
        <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="quality" viewBox="0 0 16 16">
        <path d="M9.669.864 8 0 6.331.864l-1.858.282-.842 1.68-1.337 1.32L2.6 6l-.306 1.854 1.337 1.32.842 1.68 1.858.282L8 12l1.669-.864 1.858-.282.842-1.68 1.337-1.32L13.4 6l.306-1.854-1.337-1.32-.842-1.68L9.669.864zm1.196 1.193.684 1.365 1.086 1.072L12.387 6l.248 1.506-1.086 1.072-.684 1.365-1.51.229L8 10.874l-1.355-.702-1.51-.229-.684-1.365-1.086-1.072L3.614 6l-.25-1.506 1.087-1.072.684-1.365 1.51-.229L8 1.126l1.356.702 1.509.229z" />
        <path d="M4 11.794V16l4-1 4 1v-4.206l-2.018.306L8 13.126 6.018 12.1 4 11.794z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="price-tag" viewBox="0 0 16 16">
        <path d="M6 4.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm-1 0a.5.5 0 1 0-1 0 .5.5 0 0 0 1 0z" />
        <path d="M2 1h4.586a1 1 0 0 1 .707.293l7 7a1 1 0 0 1 0 1.414l-4.586 4.586a1 1 0 0 1-1.414 0l-7-7A1 1 0 0 1 1 6.586V2a1 1 0 0 1 1-1zm0 5.586 7 7L13.586 9l-7-7H2v4.586z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="shield-plus" viewBox="0 0 16 16">
        <path d="M5.338 1.59a61.44 61.44 0 0 0-2.837.856.481.481 0 0 0-.328.39c-.554 4.157.726 7.19 2.253 9.188a10.725 10.725 0 0 0 2.287 2.233c.346.244.652.42.893.533.12.057.218.095.293.118a.55.55 0 0 0 .101.025.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067c-.53 0-1.552.223-2.662.524zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z" />
        <path d="M8 4.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V9a.5.5 0 0 1-1 0V7.5H6a.5.5 0 0 1 0-1h1.5V5a.5.5 0 0 1 .5-.5z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="star-fill" viewBox="0 0 16 16">
        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="star-empty" viewBox="0 0 16 16">
        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="star-half" viewBox="0 0 16 16">
        <path d="M5.354 5.119 7.538.792A.516.516 0 0 1 8 .5c.183 0 .366.097.465.292l2.184 4.327 4.898.696A.537.537 0 0 1 16 6.32a.548.548 0 0 1-.17.445l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256a.52.52 0 0 1-.146.05c-.342.06-.668-.254-.6-.642l.83-4.73L.173 6.765a.55.55 0 0 1-.172-.403.58.58 0 0 1 .085-.302.513.513 0 0 1 .37-.245l4.898-.696zM8 12.027a.5.5 0 0 1 .232.056l3.686 1.894-.694-3.957a.565.565 0 0 1 .162-.505l2.907-2.77-4.052-.576a.525.525 0 0 1-.393-.288L8.001 2.223 8 2.226v9.8z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="quote" viewBox="0 0 24 24">
        <path fill="currentColor" d="m15 17l2-4h-4V6h7v7l-2 4h-3Zm-9 0l2-4H4V6h7v7l-2 4H6Z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="facebook" viewBox="0 0 24 24">
        <path fill="currentColor" d="M9.198 21.5h4v-8.01h3.604l.396-3.98h-4V7.5a1 1 0 0 1 1-1h3v-4h-3a5 5 0 0 0-5 5v2.01h-2l-.396 3.98h2.396v8.01Z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="youtube" viewBox="0 0 32 32">
        <path fill="currentColor" d="M29.41 9.26a3.5 3.5 0 0 0-2.47-2.47C24.76 6.2 16 6.2 16 6.2s-8.76 0-10.94.59a3.5 3.5 0 0 0-2.47 2.47A36.13 36.13 0 0 0 2 16a36.13 36.13 0 0 0 .59 6.74a3.5 3.5 0 0 0 2.47 2.47c2.18.59 10.94.59 10.94.59s8.76 0 10.94-.59a3.5 3.5 0 0 0 2.47-2.47A36.13 36.13 0 0 0 30 16a36.13 36.13 0 0 0-.59-6.74ZM13.2 20.2v-8.4l7.27 4.2Z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="twitter" viewBox="0 0 256 256">
        <path fill="currentColor" d="m245.66 77.66l-29.9 29.9C209.72 177.58 150.67 232 80 232c-14.52 0-26.49-2.3-35.58-6.84c-7.33-3.67-10.33-7.6-11.08-8.72a8 8 0 0 1 3.85-11.93c.26-.1 24.24-9.31 39.47-26.84a110.93 110.93 0 0 1-21.88-24.2c-12.4-18.41-26.28-50.39-22-98.18a8 8 0 0 1 13.65-4.92c.35.35 33.28 33.1 73.54 43.72V88a47.87 47.87 0 0 1 14.36-34.3A46.87 46.87 0 0 1 168.1 40a48.66 48.66 0 0 1 41.47 24H240a8 8 0 0 1 5.66 13.66Z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="instagram" viewBox="0 0 256 256">
        <path fill="currentColor" d="M128 80a48 48 0 1 0 48 48a48.05 48.05 0 0 0-48-48Zm0 80a32 32 0 1 1 32-32a32 32 0 0 1-32 32Zm48-136H80a56.06 56.06 0 0 0-56 56v96a56.06 56.06 0 0 0 56 56h96a56.06 56.06 0 0 0 56-56V80a56.06 56.06 0 0 0-56-56Zm40 152a40 40 0 0 1-40 40H80a40 40 0 0 1-40-40V80a40 40 0 0 1 40-40h96a40 40 0 0 1 40 40ZM192 76a12 12 0 1 1-12-12a12 12 0 0 1 12 12Z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="linkedin" viewBox="0 0 24 24">
        <path fill="currentColor" d="M6.94 5a2 2 0 1 1-4-.002a2 2 0 0 1 4 .002zM7 8.48H3V21h4V8.48zm6.32 0H9.34V21h3.94v-6.57c0-3.66 4.77-4 4.77 0V21H22v-7.93c0-6.17-7.06-5.94-8.72-2.91l.04-1.68z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="nav-icon" viewBox="0 0 16 16">
        <path d="M14 10.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0 0 1h3a.5.5 0 0 0 .5-.5zm0-3a.5.5 0 0 0-.5-.5h-7a.5.5 0 0 0 0 1h7a.5.5 0 0 0 .5-.5zm0-3a.5.5 0 0 0-.5-.5h-11a.5.5 0 0 0 0 1h11a.5.5 0 0 0 .5-.5z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="close" viewBox="0 0 16 16">
        <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z" />
      </symbol>
      <symbol xmlns="http://www.w3.org/2000/svg" id="navbar-icon" viewBox="0 0 16 16">
        <path d="M14 10.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0 0 1h3a.5.5 0 0 0 .5-.5zm0-3a.5.5 0 0 0-.5-.5h-7a.5.5 0 0 0 0 1h7a.5.5 0 0 0 .5-.5zm0-3a.5.5 0 0 0-.5-.5h-11a.5.5 0 0 0 0 1h11a.5.5 0 0 0 .5-.5z" />
      </symbol>
    </svg>  

    <div class="search-popup">
        <div class="search-popup-container">
          <div class="ljg-search-intro"><span>Explore Larry J Gadjets</span><strong>Find the right gadget for your everyday life.</strong></div>

          <h5 class="cat-list-title">Browse Categories</h5>
         
          <ul class="cat-list">
            <li class="cat-list-item">
              <a href="#" title="Mobile Phones">Mobile Phones</a>
            </li>
            <li class="cat-list-item">
              <a href="#" title="Smart Watches">Smart Watches</a>
            </li>
            <li class="cat-list-item">
              <a href="#" title="Headphones">Headphones</a>
            </li>
            <li class="cat-list-item">
              <a href="#" title="Accessories">Accessories</a>
            </li>
            <li class="cat-list-item">
              <a href="#" title="Monitors">Monitors</a>
            </li>
            <li class="cat-list-item">
              <a href="#" title="Speakers">Speakers</a>
            </li>
            <li class="cat-list-item">
              <a href="#" title="Memory Cards">Memory Cards</a>
            </li>
          </ul>

        </div>
    </div>
    
    <header id="header" class="site-header header-scrolled position-fixed text-black bg-light">
      <nav id="header-nav" class="navbar navbar-expand-lg px-3 mb-3">
        <div class="container-fluid">
          <a class="navbar-brand" href="./index.php">
            <img src="images/main-logo.png" class="logo">
          </a>
          <button class="navbar-toggler d-flex d-lg-none order-3 p-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <svg class="navbar-icon">
              <use xlink:href="#navbar-icon"></use>
            </svg>
          </button>
          <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar" aria-labelledby="bdNavbarOffcanvasLabel">
            <div class="offcanvas-header px-4 pb-0">
              <a class="navbar-brand" href="./index.php">
                <img src="images/main-logo.png" class="logo">
              </a>
              <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas" aria-label="Close" data-bs-target="#bdNavbar"></button>
            </div>
            <div class="offcanvas-body">
              <ul id="navbar" class="navbar-nav text-uppercase justify-content-end align-items-center flex-grow-1 pe-3">
                <li class="nav-item">
                  <a class="nav-link me-4 active" href="#billboard">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link me-4" href="#company-services">Services</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link me-4" href="#mobile-products">Products</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link me-4" href="#smart-watches">Watches</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link me-4" href="./shop.php">Shop</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link me-4" href="./blog.php">Blog</a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link me-4 dropdown-toggle link-dark" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Pages</a>
                  <ul class="dropdown-menu">
                    <li>
                      <a href="./about.php" class="dropdown-item">About</a>
                    </li>
                    <li>
                      <a href="./blog.php" class="dropdown-item">Blog</a>
                    </li>
                    <li>
                      <a href="shop.php" class="dropdown-item">Shop</a>
                    </li>
                    <li>
                      <a href="cart.php" class="dropdown-item">Cart</a>
                    </li>
                    <li>
                      <a href="checkout.php" class="dropdown-item">Checkout</a>
                    </li>
                    <li>
                      <a href="blog.php" class="dropdown-item">Single Post</a>
                    </li>
                    <li>
                      <a href="shop.php" class="dropdown-item">Single Product</a>
                    </li>
                    <li>
                      <a href="about.php#contact" class="dropdown-item">Contact</a>
                    </li>
             

                   
                  </ul>
                </li>
                <li class="nav-item">
                  <div class="user-items ps-lg-4">
                    <ul class="d-flex flex-wrap justify-content-end align-items-center gap-2 list-unstyled mb-0">
                      <?php
                        $dashboardLink = "dashboard/login.php";
                        if (isset($_SESSION['role'])) {
                            $role = strtolower(trim((string) $_SESSION['role']));
                            if ($role === 'admin') {
                                $dashboardLink = "dashboard%201/index.php";
                            } elseif ($role === 'customer') {
                                $dashboardLink = "dashboard/index.php";
                            }
                        }
                      ?>
                      <li>
                        <a href="<?php echo $dashboardLink; ?>" class="btn btn-primary btn-sm fw-bold text-white">
                          <i class="bi bi-speedometer2 me-1"></i>DASHBOARD
                        </a>
                      </li>
                      <?php if (!isset($_SESSION['username'])): ?>
                        <li>
                          <a href="dashboard/login.php" class="btn btn-success btn-sm fw-bold text-white">REGISTER/LOGIN</a>
                        </li>
                      <?php endif; ?>
                      <li class="search-item">
                        <a href="#" class="search-button">
                          <svg class="search">
                            <use xlink:href="#search"></use>
                          </svg>
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <svg class="user">
                            <use xlink:href="#user"></use>
                          </svg>
                        </a>
                      </li>
                      <li>
                        <a href="./cart.php" class="position-relative">
                          <svg class="cart">
                            <use xlink:href="#cart"></use>
                          </svg>
                          <span id="cart-count" class="badge bg-danger">0</span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </header>
    <section id="billboard" class="position-relative overflow-hidden bg-light-blue">
      <div class="swiper main-swiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="container">
              <div class="row d-flex align-items-center">
                <div class="col-md-6">
                  <div class="banner-content">
                    <h1 class="display-2 text-uppercase text-dark pb-5">Your Products Are Great.</h1>
                    <a href="shop.php" class="btn btn-medium btn-dark text-uppercase btn-rounded-none">Shop Product</a>
                  </div>
                </div>
                <div class="col-md-5">
                  <div class="image-holder">
                    <img src="images/banner-image.png" alt="banner">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="container">
              <div class="row d-flex flex-wrap align-items-center">
                <div class="col-md-6">
                  <div class="banner-content">
                    <h1 class="display-2 text-uppercase text-dark pb-5">Technology Hack You Won't Get</h1>
                    <a href="shop.php" class="btn btn-medium btn-dark text-uppercase btn-rounded-none">Shop Product</a>
                  </div>
                </div>
                <div class="col-md-5">
                  <div class="image-holder">
                    <img src="images/banner-image.png" alt="banner">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-icon swiper-arrow swiper-arrow-prev">
        <svg class="chevron-left">
          <use xlink:href="#chevron-left" />
        </svg>
      </div>
      <div class="swiper-icon swiper-arrow swiper-arrow-next">
        <svg class="chevron-right">
          <use xlink:href="#chevron-right" />
        </svg>
      </div>
    </section>
    <section id="company-services" class="padding-large">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 pb-3">
            <div class="icon-box d-flex">
              <div class="icon-box-icon pe-3 pb-3">
                <svg class="cart-outline">
                  <use xlink:href="#cart-outline" />
                </svg>
              </div>
              <div class="icon-box-content">
                <h3 class="card-title text-uppercase text-dark">Free delivery</h3>
                <p>Consectetur adipi elit lorem ipsum dolor sit amet.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 pb-3">
            <div class="icon-box d-flex">
              <div class="icon-box-icon pe-3 pb-3">
                <svg class="quality">
                  <use xlink:href="#quality" />
                </svg>
              </div>
              <div class="icon-box-content">
                <h3 class="card-title text-uppercase text-dark">Quality guarantee</h3>
                <p>Shop useful technology selected for everyday work, entertainment and communication.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 pb-3">
            <div class="icon-box d-flex">
              <div class="icon-box-icon pe-3 pb-3">
                <svg class="price-tag">
                  <use xlink:href="#price-tag" />
                </svg>
              </div>
              <div class="icon-box-content">
                <h3 class="card-title text-uppercase text-dark">Daily offers</h3>
                <p>Enjoy practical deals on products you actually need.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 pb-3">
            <div class="icon-box d-flex">
              <div class="icon-box-icon pe-3 pb-3">
                <svg class="shield-plus">
                  <use xlink:href="#shield-plus" />
                </svg>
              </div>
              <div class="icon-box-content">
                <h3 class="card-title text-uppercase text-dark">100% secure payment</h3>
                <p>Checkout is designed with security and clarity in mind.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section id="mobile-products" class="product-store position-relative padding-large no-padding-top">
      <div class="container">
        <div class="row">
          <?php if ($latest_posts): ?>
            <?php
              $latestId = (int)($latest_posts['id'] ?? 0);
              $latestName = (string)($latest_posts['title'] ?? 'Latest Product');
              $latestPrice = (float)($latest_posts['price'] ?? 0);
              $latestImages = shopPostImages($latest_posts);
              $latestImage = shopImageUrl($latestImages[0] ?? '');
            ?>
            <div class="home-latest-products">
              <div class="display-header d-flex justify-content-between align-items-center pb-3">
                <h2 class="display-7 text-dark text-uppercase mb-0">Latest Products</h2>
              </div>
              <div class="swiper latest-product-swiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="product-card position-relative home-product-card">
                      <div class="image-holder">
                        <?php if ($latestImage !== ''): ?>
                          <img src="<?php echo htmlspecialchars($latestImage, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($latestName, ENT_QUOTES, 'UTF-8'); ?>" class="img-fluid">
                        <?php else: ?>
                          <div class="d-flex align-items-center justify-content-center w-100 h-100 bg-light text-muted">No image</div>
                        <?php endif; ?>
                      </div>
                      <div class="cart-concern">
                        <div class="cart-button d-flex">
                          <button type="button" class="btn btn-medium btn-black add-cart" data-id="post-<?php echo $latestId; ?>" data-name="<?php echo htmlspecialchars($latestName, ENT_QUOTES, 'UTF-8'); ?>" data-price="<?php echo $latestPrice; ?>" data-image="<?php echo htmlspecialchars($latestImage, ENT_QUOTES, 'UTF-8'); ?>" data-category="Latest Product">Add to Cart <svg class="cart-outline"><use xlink:href="#cart-outline"></use></svg></button>
                        </div>
                      </div>
                      <div class="product-cat"><?php echo htmlspecialchars((string)($latest_posts['category'] ?? 'Latest Product'), ENT_QUOTES, 'UTF-8'); ?></div>
                      <div class="card-detail d-flex justify-content-between align-items-baseline pt-1">
                        <h3 class="card-title text-uppercase"><a href="product.php?source=post&amp;id=<?php echo $latestId; ?>"><?php echo htmlspecialchars($latestName, ENT_QUOTES, 'UTF-8'); ?></a></h3>
                        <span class="item-price text-primary">₦<?php echo number_format($latestPrice, 2); ?></span>
                      </div>
                      <p class="home-product-description small text-muted mb-0 mt-2"><?php echo htmlspecialchars((string)($latest_posts['description'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></p>
                      <div class="mt-2"><a href="product.php?source=post&amp;id=<?php echo $latestId; ?>" class="btn btn-sm btn-outline-dark">Read More</a></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php endif; ?>

          <div class="home-shop-products home-section-title">
            <div class="display-header d-flex justify-content-between align-items-center pb-3">
              <h2 class="display-7 text-dark text-uppercase mb-0">Shop Products</h2>
              <div class="btn-right"><a href="shop.php" class="btn btn-medium btn-normal text-uppercase">Go to Shop</a></div>
            </div>
            <div class="swiper shop-product-swiper">
              <div class="swiper-wrapper">
                <?php foreach ($products as $p): ?>
                  <?php
                    $homeId = (int)$p['id'];
                    $homeName = (string)$p['name'];
                    $homeCategory = (string)$p['category'];
                    $homeImages = $p['all_images'] ?? shopImages($p);
                    $homeImage = shopImageUrl($homeImages[0] ?? (string)$p['image']);
                    $homeDescription = (string)($p['description'] ?? '');
                  ?>
                  <div class="swiper-slide">
                    <div class="product-card position-relative home-product-card">
                      <div class="image-holder">
                        <?php if (!empty($p['badge'])): ?><span class="product-badge <?php echo $p['badge'] === 'Sale' ? 'sale' : ''; ?>"><?php echo htmlspecialchars($p['badge'], ENT_QUOTES, 'UTF-8'); ?></span><?php endif; ?>
                        <img src="<?php echo htmlspecialchars($homeImage, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($homeName, ENT_QUOTES, 'UTF-8'); ?>" class="img-fluid">
                      </div>
                      <div class="cart-concern">
                        <div class="cart-button d-flex">
                          <button type="button" class="btn btn-medium btn-black add-cart" data-id="shop-<?php echo $homeId; ?>" data-name="<?php echo htmlspecialchars($homeName, ENT_QUOTES, 'UTF-8'); ?>" data-price="<?php echo (float)$p['price']; ?>" data-image="<?php echo htmlspecialchars($homeImage, ENT_QUOTES, 'UTF-8'); ?>" data-category="<?php echo htmlspecialchars($homeCategory, ENT_QUOTES, 'UTF-8'); ?>">Add to Cart <svg class="cart-outline"><use xlink:href="#cart-outline"></use></svg></button>
                        </div>
                      </div>
                      <div class="product-cat"><?php echo htmlspecialchars($homeCategory, ENT_QUOTES, 'UTF-8'); ?></div>
                      <div class="card-detail d-flex justify-content-between align-items-baseline pt-1">
                        <h3 class="card-title text-uppercase"><a href="product.php?source=shop&amp;id=<?php echo $homeId; ?>"><?php echo htmlspecialchars($homeName, ENT_QUOTES, 'UTF-8'); ?></a></h3>
                        <span class="item-price text-primary">₦<?php echo number_format((float)$p['price'], 2); ?><?php if ($p['old_price'] !== null && $p['old_price'] !== ''): ?><small class="text-muted text-decoration-line-through ms-1">₦<?php echo number_format((float)$p['old_price'], 2); ?></small><?php endif; ?></span>
                      </div>
                      <p class="home-product-description small text-muted mb-0 mt-2"><?php echo htmlspecialchars($homeDescription, ENT_QUOTES, 'UTF-8'); ?></p>
                      <div class="mt-2"><a href="product.php?source=shop&amp;id=<?php echo $homeId; ?>" class="btn btn-sm btn-outline-dark">Read More</a></div>
                    </div>
                  </div>
                <?php endforeach; ?>
                <?php if (!$products): ?>
                  <div class="swiper-slide"><div class="alert alert-light border text-center">No shop products available yet.</div></div>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<section id="yearly-sale" class="bg-light-blue overflow-hidden mt-5 padding-xlarge" style="background-image: url('images/single-image1.png');background-position: right; background-repeat: no-repeat;">
      <div class="row d-flex flex-wrap align-items-center">
        <div class="col-md-6 col-sm-12">
          <div class="text-content offset-4 padding-medium">
            <h3>10% off</h3>
            <h2 class="display-2 pb-5 text-uppercase text-dark">New year sale</h2>
            <a href="shop.php" class="btn btn-medium btn-dark text-uppercase btn-rounded-none">Shop Sale</a>
          </div>
        </div>
        <div class="col-md-6 col-sm-12">
          
        </div>
      </div>
    </section>
    <section id="latest-blog" class="padding-large">
      <div class="container">
        <div class="row">
          <div class="display-header d-flex justify-content-between pb-3">
            <!-- <h2 class="display-7 text-dark text-uppercase">Latest Posts</h2> -->
            <div class="btn-right">
              <a href="blog.php" class="btn btn-medium btn-normal text-uppercase">Read Blog</a>
            </div>
          </div>
          <div class="row g-4 latest-post-grid"></div>
        </div>
      </div>
    </section>

    <section id="why-larry" class="ljg-home-panel"><div class="container"><div class="ljg-section-head"><span class="eyebrow">Why shop with us</span><h2>Good gadgets should come with a good experience.</h2><p>We make it simple to choose useful technology, buy with confidence and get help when you need it.</p></div><div class="row g-4"><div class="col-lg-3 col-md-6"><div class="ljg-value-card"><div class="ljg-value-icon">✓</div><h3>Quality Checked</h3><p>Practical products selected for everyday work, communication and entertainment.</p></div></div><div class="col-lg-3 col-md-6"><div class="ljg-value-card"><div class="ljg-value-icon">₦</div><h3>Fair Prices</h3><p>Clear Nigerian naira pricing and useful offers without confusing hidden costs.</p></div></div><div class="col-lg-3 col-md-6"><div class="ljg-value-card"><div class="ljg-value-icon">↗</div><h3>Fast Delivery</h3><p>Choose your product, place your order and get straightforward delivery support.</p></div></div><div class="col-lg-3 col-md-6"><div class="ljg-value-card"><div class="ljg-value-icon">?</div><h3>Real Support</h3><p>Need help choosing? Our contact and support options are always close by.</p></div></div></div></div></section>

    <section id="shopping-guide" class="ljg-home-panel ljg-steps"><div class="container"><div class="ljg-section-head"><span class="eyebrow">Simple shopping</span><h2>From browsing to your doorstep.</h2><p>No complicated process. Pick a product, add it to your cart and continue when you are ready.</p></div><div class="row g-4"><div class="col-md-4"><div class="ljg-step"><div class="ljg-step-number">01</div><h3>Explore</h3><p>Browse latest products or open the full shop to compare categories, prices and details.</p></div></div><div class="col-md-4"><div class="ljg-step"><div class="ljg-step-number">02</div><h3>Add to Cart</h3><p>Save the gadgets you want and review your items before you decide to checkout.</p></div></div><div class="col-md-4"><div class="ljg-step"><div class="ljg-step-number">03</div><h3>Checkout</h3><p>When ready, continue to checkout and follow the available order instructions.</p></div></div></div></div></section>

    <section class="ljg-home-panel"><div class="container"><div class="ljg-cta d-flex flex-wrap align-items-center justify-content-between gap-4"><div><h2>Looking for something specific?</h2><p>Visit the shop to see the full range of phones, watches, audio products, accessories, speakers and monitors.</p></div><a href="shop.php" class="btn btn-light btn-medium text-uppercase">Explore All Products</a></div></div></section>

    <section id="faq" class="ljg-home-panel ljg-faq"><div class="container"><div class="ljg-section-head"><span class="eyebrow">Quick answers</span><h2>Questions before you buy?</h2><p>Here are a few simple answers to help you shop with confidence.</p></div><div class="accordion mx-auto" id="ljgFaq" style="max-width:850px;"><div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#ljgFaqOne">Can I add products to my cart before logging in?</button></h2><div id="ljgFaqOne" class="accordion-collapse collapse show" data-bs-parent="#ljgFaq"><div class="accordion-body text-muted">Yes. You can browse and add products to your cart first. Login is required when you proceed to checkout.</div></div></div><div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ljgFaqTwo">Where can I see the full product details?</button></h2><div id="ljgFaqTwo" class="accordion-collapse collapse" data-bs-parent="#ljgFaq"><div class="accordion-body text-muted">Open a product's Read More page to view its details and available product images.</div></div></div><div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ljgFaqThree">How do I contact Larry J Gadjets?</button></h2><div id="ljgFaqThree" class="accordion-collapse collapse" data-bs-parent="#ljgFaq"><div class="accordion-body text-muted">Use the Contact link in the navigation or footer, or use the support details shown below.</div></div></div></div></div></section>

    <section id="testimonials" class="position-relative ljg-customer-carousel py-5">
      <div class="container">
        <div class="row align-items-center g-4">
          <div class="col-lg-4">
            <div class="ljg-carousel-intro">
              <span class="ljg-carousel-eyebrow">WHY SHOP WITH US</span>
              <h2 class="text-dark mb-3">Smart gadgets. Simple shopping.</h2>
              <p class="mb-0">Everything is arranged to help you find useful technology faster, understand what you are buying, and shop with confidence.</p>
              <div class="ljg-carousel-points mt-4">
                <div><span>✓</span> Clear product information</div>
                <div><span>✓</span> Easy cart and checkout</div>
                <div><span>✓</span> Helpful customer support</div>
              </div>
            </div>
          </div>

          <div class="col-lg-8">
            <div class="review-content position-relative ljg-carousel-card">
              <div class="swiper-icon swiper-arrow swiper-arrow-prev position-absolute d-flex align-items-center justify-content-center" aria-label="Previous slide">
                <svg class="chevron-left"><use xlink:href="#chevron-left" /></svg>
              </div>

              <div class="swiper testimonial-swiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="review-item ljg-customer-slide">
                      <div class="ljg-slide-top">
                        <div class="ljg-slide-icon">01</div>
                        <div>
                          <div class="ljg-slide-label">SHOP WITH CLARITY</div>
                          <h3 class="ljg-slide-title">Know what you are buying</h3>
                        </div>
                      </div>
                      <p class="ljg-slide-text">Browse useful gadgets with clear names, prices and product details so you can make a quicker, better choice.</p>
                      <div class="ljg-slide-footer"><strong>Better choices start with clear information.</strong><span>01 / 03</span></div>
                    </div>
                  </div>

                  <div class="swiper-slide">
                    <div class="review-item ljg-customer-slide">
                      <div class="ljg-slide-top">
                        <div class="ljg-slide-icon">02</div>
                        <div>
                          <div class="ljg-slide-label">SHOP WITH EASE</div>
                          <h3 class="ljg-slide-title">From product to cart, smoothly</h3>
                        </div>
                      </div>
                      <p class="ljg-slide-text">Pick your product, add it to your cart and move through the shopping process without unnecessary steps or confusing screens.</p>
                      <div class="ljg-slide-footer"><strong>Less stress. More convenient shopping.</strong><span>02 / 03</span></div>
                    </div>
                  </div>

                  <div class="swiper-slide">
                    <div class="review-item ljg-customer-slide">
                      <div class="ljg-slide-top">
                        <div class="ljg-slide-icon">03</div>
                        <div>
                          <div class="ljg-slide-label">SHOP WITH CONFIDENCE</div>
                          <h3 class="ljg-slide-title">Technology that fits your everyday life</h3>
                        </div>
                      </div>
                      <p class="ljg-slide-text">Whether you need a phone, wearable, audio accessory or everyday gadget, the goal is simple: help you find tech that makes life easier.</p>
                      <div class="ljg-slide-footer"><strong>Useful tech, chosen for real life.</strong><span>03 / 03</span></div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="swiper-icon swiper-arrow swiper-arrow-next position-absolute d-flex align-items-center justify-content-center" aria-label="Next slide">
                <svg class="chevron-right"><use xlink:href="#chevron-right" /></svg>
              </div>
            </div>
            <div class="swiper-pagination ljg-carousel-pagination"></div>
          </div>
        </div>
      </div>
    </section>
   
<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4"><a class="brand-mark text-white d-inline-block mb-3" href="index.php"><img src="images/main-logo.png" alt="Larry J Gadjets" style="height:40px;width:auto;max-width:205px;object-fit:contain;"></a><p class="small">Everyday tech, chosen carefully. Phones, wearables, audio and accessories — delivered fast, backed by a real warranty.</p></div>
      <div class="col-lg-2 col-6"><h6>Shop</h6><ul class="list-unstyled small"><li class="mb-2"><a href="shop.php">All Products</a></li><li class="mb-2"><a href="cart.php">Cart</a></li><li class="mb-2"><a href="<?php echo $isLoggedIn ? 'checkout.php' : 'dashboard/login.php?redirect=checkout.php'; ?>">Checkout</a></li></ul></div>
      <div class="col-lg-2 col-6"><h6>Company</h6><ul class="list-unstyled small"><li class="mb-2"><a href="about.php">About Us</a></li><li class="mb-2"><a href="blog.php">Blog</a></li><li class="mb-2"><a href="about.php#contact">Contact</a></li></ul></div>
      <div class="col-lg-4"><h6>Contact</h6><p class="small mb-1">Questions? <a href="mailto:hello@Larry J Gadjets.example">ugwuanyinelson46@gmail.com</a></p><p class="small">Support line: <a href="tel:+15551234567">+2349043855373</a></p></div>
    </div>
    <div class="fine-print d-flex flex-wrap justify-content-between"><span>© 2026 Larry J Gadjets. All rights reserved.</span><span>Secure checkout · Visa · Mastercard · PayPal</span></div>
  </div>
</footer>
    <script src="jquery-1.11.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="bootstrap.min.js"></script>
    <script type="text/javascript" src="plugins.js"></script>
    <script type="text/javascript" src="script.js"></script>
<script src="cart.js"></script>
    


<script>
document.addEventListener("DOMContentLoaded", function () {

  new Swiper(".main-swiper", {
    loop: true,
    navigation: {
      nextEl: ".swiper-arrow-next",
      prevEl: ".swiper-arrow-prev",
    },
  });

  new Swiper(".shop-product-swiper", {
    loop: false,
    slidesPerView: 1,
    spaceBetween: 20,
    breakpoints: {
      576: { slidesPerView: 2 },
      768: { slidesPerView: 3 },
      992: { slidesPerView: 4 },
      1200: { slidesPerView: 5 }
    }
  });

  new Swiper(".product-watch-swiper", {
    loop: true,
    pagination: {
      el: ".product-watch-swiper + .swiper-pagination",
      clickable: true,
    },
    breakpoints: {
      0: {
        slidesPerView: 1,
        spaceBetween: 20
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 20
      },
      992: {
        slidesPerView: 5,
        spaceBetween: 16
      }
    }
  });

  new Swiper(".testimonial-swiper", {
    loop: true,
    navigation: {
      nextEl: "#testimonials .swiper-arrow-next",
      prevEl: "#testimonials .swiper-arrow-prev",
    },
    pagination: {
      el: "#testimonials .swiper-pagination",
      clickable: true,
    },
  });

});
</script>
 
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index:1100;">
      <div id="cartToast" class="toast align-items-center text-white bg-dark border-0" role="alert">
        <div class="d-flex">
          <div class="toast-body"><span id="toastMsg">Added to cart</span></div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    </div>

  
<script>
(function(){
  function hideLarryLoader(){var el=document.getElementById('ljgPreloader');if(!el)return;el.classList.add('is-hidden');window.setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},380);}
  if(document.readyState==='complete'){hideLarryLoader();}else{window.addEventListener('load',hideLarryLoader,{once:true});}
})();
</script>
</body>
</html>